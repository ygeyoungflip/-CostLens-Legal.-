# CostLens Legal — Notification Templates (Email + SMS)

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Purpose:** Production-ready copy templates for core platform events.

---

## Template Variables
Use placeholders:
`{{recipient_name}}`, `{{firm_name}}`, `{{action_url}}`, `{{event_time}}`, `{{case_or_request_id}}`, `{{invoice_id}}`, `{{amount}}`, `{{payment_method}}`, `{{alert_level}}`, `{{alert_summary}}`, `{{due_date}}`, `{{support_email}}`, `{{inviter_name}}`, `{{team_name}}`

---

## 1) Welcome Email

**Email Subject:** Welcome to CostLens Legal — Start Your Setup

**Email Body:**
Hi {{recipient_name}},

Welcome to CostLens Legal. We’re excited to onboard {{firm_name}}.

To get started, please complete your setup and verification steps:
1) Verify identity
2) Confirm firm details
3) Upload required documents

Start here: {{action_url}}

Need help? Contact us at {{support_email}}.

Best,  
CostLens Legal Team

**SMS:**
CostLens: Welcome {{firm_name}}! Start setup here: {{action_url}}. Help: {{support_email}}

---

## 2) Verification Approved

**Email Subject:** Verification Approved — {{firm_name}} Is Active

**Email Body:**
Hi {{recipient_name}},

Great news — {{firm_name}} has been verified and is now active on CostLens Legal.

You can now access full features and begin onboarding workflows.

Open dashboard: {{action_url}}

Best,  
CostLens Legal Team

**SMS:**
CostLens: {{firm_name}} verification approved ✅ Access your dashboard: {{action_url}}

---

## 3) Verification Flagged

**Email Subject:** Action Required — Verification Flagged for {{firm_name}}

**Email Body:**
Hi {{recipient_name}},

Your verification submission for {{firm_name}} has been flagged for review.

Flag summary:
- Request ID: {{case_or_request_id}}
- Time: {{event_time}}
- Details: {{alert_summary}}

Please review and respond here: {{action_url}}

If you need help, contact {{support_email}}.

Best,  
CostLens Legal Verification Team

**SMS:**
CostLens: Verification flagged for {{firm_name}} ({{case_or_request_id}}). Action needed: {{action_url}}

---

## 4) Document Uploaded (Confirmation)

**Email Subject:** Document Received — {{firm_name}}

**Email Body:**
Hi {{recipient_name}},

We received your document upload.

Details:
- Request ID: {{case_or_request_id}}
- Uploaded at: {{event_time}}

Track verification progress: {{action_url}}

Best,  
CostLens Legal Team

**SMS:**
CostLens: Document received for {{firm_name}} ({{case_or_request_id}}). Status: {{action_url}}

---

## 5) Billing Receipt

**Email Subject:** Payment Receipt — Invoice {{invoice_id}}

**Email Body:**
Hi {{recipient_name}},

Your payment has been processed successfully.

Receipt details:
- Invoice: {{invoice_id}}
- Amount: {{amount}}
- Method: {{payment_method}}
- Time: {{event_time}}

View billing history: {{action_url}}

Questions? {{support_email}}

Best,  
CostLens Legal Billing

**SMS:**
CostLens receipt: {{amount}} paid for invoice {{invoice_id}}. Details: {{action_url}}

---

## 6) Compliance Alert

**Email Subject:** [{{alert_level}}] Compliance Alert — Action Required

**Email Body:**
Hi {{recipient_name}},

A compliance alert has been triggered for {{firm_name}}.

Alert details:
- Severity: {{alert_level}}
- Summary: {{alert_summary}}
- Triggered: {{event_time}}
- Response due: {{due_date}}

Review and respond immediately: {{action_url}}

If you believe this is an error, contact {{support_email}}.

Best,  
CostLens Legal Compliance

**SMS:**
CostLens {{alert_level}} compliance alert for {{firm_name}}: {{alert_summary}}. Due {{due_date}}: {{action_url}}

---

## 7) Team Invite

**Email Subject:** You’ve Been Invited to Join {{team_name}} on CostLens Legal

**Email Body:**
Hi {{recipient_name}},

{{inviter_name}} invited you to join {{team_name}} on CostLens Legal.

Accept invite and set up your account: {{action_url}}

This invite helps your team collaborate on verification, billing, and compliance workflows.

If this wasn’t expected, contact {{support_email}}.

Best,  
CostLens Legal Team

**SMS:**
You’re invited to join {{team_name}} on CostLens Legal by {{inviter_name}}. Accept: {{action_url}}

---

## Sending Rules
- Welcome, verification approved, document uploaded, billing receipt, team invite: send email immediately; SMS optional by preference.
- Verification flagged + compliance alerts: send email + SMS immediately.
- Critical alerts should escalate if unacknowledged within SLA.

