# CostLens Legal — Automated Notifications Design

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Spec:** `/home/team/shared/platform_expansion_v2.md` (Automated Notifications)

---

## 1) Scope
Design event-driven notifications for:
1. Verification updates
2. Billing/payment confirmations
3. Document upload confirmations
4. Compliance alerts

Channels:
- Email (required)
- SMS (critical/urgent paths)
- In-app notifications (status center)

---

## 2) Notification Architecture

1. Product events + Stripe webhook events enter event bus/queue
2. Notification service validates event, deduplicates by idempotency key
3. Routing engine selects recipient(s), channel(s), and template
4. Delivery providers execute (email/SMS/in-app)
5. Delivery outcomes logged for audit and retry handling

### Reliability rules
- Idempotency key: `<event_type>:<entity_id>:<event_timestamp_bucket>`
- Retry policy: exponential backoff (3 attempts email, 2 SMS)
- Dead-letter queue for failed events requiring ops review

---

## 3) Event Matrix

## 3.1 Verification events
| Event | Recipients | Channel | SLA |
|---|---|---|---|
| verification.started | Firm admin, submitting user | email + in-app | <1 min |
| verification.pending_documents | submitting user | email + in-app | <1 min |
| verification.approved | firm admin + onboarding owner | email + in-app | <1 min |
| verification.rejected | firm admin + support | email + in-app | <1 min |
| verification.expiring_insurance | firm admin + compliance lead | email + SMS | same day |

## 3.2 Billing events
| Event | Recipients | Channel | SLA |
|---|---|---|---|
| invoice.paid | billing contact + firm admin | email + in-app | <1 min |
| invoice.payment_failed | billing contact + internal finance | email + SMS + in-app | <1 min |
| subscription.updated | firm admin | email + in-app | <2 min |
| payout.swept_to_cto | internal finance | email + in-app | <5 min |

## 3.3 Document events
| Event | Recipients | Channel | SLA |
|---|---|---|---|
| document.uploaded | uploader + reviewer queue | in-app + email | <1 min |
| document.virus_scan_failed | uploader + internal ops | email + in-app | <1 min |
| document.review_requested | firm admin | email + in-app | <5 min |

## 3.4 Compliance events
| Event | Recipients | Channel | SLA |
|---|---|---|---|
| compliance.flag.high_risk | compliance ops + security | email + SMS + in-app | <1 min |
| compliance.report.generated | ops/compliance team | email + in-app | <5 min |
| compliance.breach_suspected | incident responders + leadership | SMS + email + in-app | immediate |

---

## 4) Templates (Minimum Set)

- verification_started
- verification_docs_needed
- verification_approved
- verification_rejected
- billing_payment_success
- billing_payment_failed
- document_upload_confirmed
- document_action_required
- compliance_alert_high
- compliance_report_ready

Each template supports:
- plain text + HTML email
- SMS condensed variant
- in-app short title + body + action URL

---

## 5) User Notification Preferences

- Firm admins: can opt into SMS for critical alerts only
- Billing contacts: cannot disable payment failure alerts
- Compliance officers: mandatory alerts for high-risk events
- Digest options: daily summary for non-critical updates

---

## 6) Notification UI Handoff (Coordinate with web-dev)

Web-dev deliverables:
1. **Notification Center UI**
   - unread/read state
   - filters: verification, billing, documents, compliance
   - severity badges (info/warn/critical)
2. **Settings UI**
   - channel preferences per category
   - quiet hours for non-critical alerts
3. **Alert detail drawer**
   - event metadata
   - deep links to relevant workflow screens

Data contract fields for UI:
- notification_id
- event_type
- category
- severity
- message
- action_url
- created_at
- read_at

---

## 7) Operational Metrics

- Delivery success rate by channel
- Median delivery latency by event type
- Failure/retry rate
- Open/click rate for email alerts
- Acknowledgment time for critical compliance alerts

Targets:
- >=99% delivery success for email
- >=95% delivery success for SMS
- <60s p95 latency for critical alerts

---

## 8) Security & Compliance

- No sensitive PII in SMS bodies
- Signed links with expiration for notification actions
- Full audit logs for critical alerts and acknowledgments
- Access controls to ensure firm data isolation

