# Sales Outreach Templates (Aligned with Product Vision & Trust Network)

## 1. Email Sequence

### Option A: The Mission Focus (ROI & Tier-Specific)
**Subject:** Helping [Firm Name] operate smarter and maximize profitability

Hi [Partner Name],

I'm reaching out from CostLens Legal. Our mission is simple: **Help law firms spend less money, operate smarter, and maximize profitability.**

We've developed an AI-powered Cost Intelligence platform tailored to your firm's scale:
*   **For our Global/Ultra-Premium partners:** We project multi-million dollar annual savings through strategic partnership and priority support.
*   **For Enterprise-scale firms:** Our models show a **990%+ ROI** in Year 1 with verified compliance and enterprise-grade security.
*   **For Growth-focused mid-size firms:** We identify **$200K+ in annual savings** and reclaim **20% of your billable capacity**.

Beyond the data, we are building a **Trusted Verified Network**. Every firm on CostLens is insured, screened, and verified, allowing you to join an elite group of high-efficiency, low-risk partners.

Would you be open to a 10-minute demo next week? I'll show you how we turn your legal operations into measurable business intelligence.

Best,

[My Name]
Growth & Sales Lead, CostLens Legal

---

### Option B: The "Triple Threat" Focus (Pricing & Value Angle)
**Subject:** Stopping the Margin Leak: [Firm Name]'s Data-Driven Profitability Plan

Hi [Partner Name],

Law firms today are facing a "triple threat" to their profitability:
1. **The Billable Gap:** Attorneys spend only 2.5–3 hours/day on billable work.
2. **Discovery Bloat:** Discovery now consumes up to 50% of litigation spend.
3. **Software Overlap:** Most firms are overpaying for underutilized licenses by 10-15%.

At CostLens Legal, we provide the Cost Intelligence needed to attack all three. Our new tiered pricing ensures you get exactly the depth you need, from **Solo/Starter at $1,000/mo** to our **Enterprise suite at $10,000/mo**.

Furthermore, we've integrated a **Verification & Trust System** into our platform. Firms that pass our screening receive the **"CostLens Verified" badge**, signalling to corporate clients and partners that your operations are insured, screened, and benchmark-validated.

Our typical partner firm achieves:
- **15-35% reduction** in case processing costs.
- **20% recovery** of billable capacity by slashing admin overhead.
- **10% savings** through targeted software consolidation.

Would you be open to a 10-minute demo to see our **Early Alert Framework**, **Industry Benchmarks**, and our new **Verification Onboarding**?

Best,

[My Name]
Growth & Sales Lead, CostLens Legal

---

## 2. LinkedIn Messaging

### Connection Request (Mission & Trust)
Hi [Name], I've been following [Firm Name]'s growth. We're helping mid-size and AmLaw firms spend less and operate smarter via "Cost Intelligence." We've just rolled out our new tiered pricing and **Verified Network**. Would love to connect and share our ROI framework—ranging from $200K in savings for mid-size firms to multi-million dollar returns for global enterprises.

### Follow-up (Value & Security)
Thanks for connecting! We just released our "Cost Intelligence" playbook. It turns legal operations into business intelligence by identifying drivers of margin erosion. We also just launched our **Verification System**—every firm on the platform is now screened and insured for maximum trust. We're running 30-day "proof of ROI" pilots—would you be open to a 10-minute walkthrough?

---

## 3. Referral Scripts

### Referral (Existing Client)
Hi [Referrer Name], hope all is well! We're expanding our "Cost Intelligence" network to firms like [Target Firm]. Since we've helped you identify [X]% in case savings and get your **"CostLens Verified" status**, I was wondering if you could introduce me to [Target Partner Name]? I'd love to show them how we help firms operate smarter and build trust through verification.

### Referral (Industry Contact)
Hi [Name], I'm working with CostLens Legal to help firms solve the 'triple threat' to profitability: case inefficiency, admin drag, and software bloat. Our latest model shows a 990% ROI for enterprises, and we've just added a mandatory **screening and insurance verification** layer for all partner firms. I know you're connected with [Target Partner Name] at [Target Firm]. Would you be comfortable making a brief introduction?

---

## 4. Retention & Expansion Messaging (New)

### Quarterly Value Review (Pre-Renewal)
**Subject: [Firm Name] — Year 1 ROI Recap & Expansion Opportunities**

Hi [Partner Name],

As we approach our quarterly review, I wanted to highlight the impact CostLens has had at [Firm Name] over the last 90 days. 

To date, we've identified **$[X] in case-level savings** and recovered **[Y]% in billable capacity** across your litigation teams. 

We're excited to continue this partnership. Based on your success, we're ready to discuss expanding CostLens to your [Practice Area B] group, which our models suggest could yield an additional **$[Z] in annual savings**.

Are you available next Tuesday for a brief "Success Audit"?

### Referral Program Invite (After Signing)
**Subject: Welcome to the CostLens Network — Earn Monthly Credits**

Hi [Partner Name],

Welcome aboard! We're thrilled to have [Firm Name] join our Trusted Verified Network.

As a strategic partner, you now have access to our **Referral Program**. For every firm you refer that signs up for a 30-day pilot, we will apply a **full month's credit** to your subscription. 

It’s our way of thanking you for help us build the most efficient network in the legal industry.

Best,

[My Name]
Growth & Sales Lead, CostLens Legal
