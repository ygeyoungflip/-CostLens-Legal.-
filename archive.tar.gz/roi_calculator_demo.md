# CostLens Legal — Live Demo ROI Calculator

**Purpose:** Use this template during live demo calls to provide potential clients with an immediate financial benefit projection.

---

## 1. Firm Inputs (Client Data)
*Fill these during the discovery phase of the call.*

| Input Field | Value | Notes |
| :--- | :--- | :--- |
| **Firm Size** (# of Attorneys) | [X] | Total billable headcount |
| **Annual Case Volume** | [X] | Number of matters per year |
| **Total Annual Direct Costs** | $[X] | (Average cost/case * volume) |
| **Current Admin Ratio** | [X]% | % of attorney time on non-billable admin |
| **Annual Admin Spend (Labor)** | $[X] | (Total Billable Revenue * Admin Ratio) |

---

## 2. Projected Value by Tier
*Show how the savings scale as they move up the tiers.*

### TIER 1: Solo/Starter ($1,000/mo)
*Focus: Direct Case Cost Reduction*
*   **Target Savings:** 15% reduction in direct case costs.
*   **Projected Annual Savings:** $[Direct Costs * 0.15]
*   **Net Annual Benefit:** $[Savings - 12,000]
*   **ROI (%):** [Net Benefit / 12,000] * 100
*   **Payback Period:** [12,000 / (Savings/12)] months

### TIER 2: Growth/Mid-Size ($7,000/mo)
*Focus: Billable Capacity Recapture + Profitability*
*   **Target Savings:** 15% Case Reduction + 20% Admin Drag Reduction.
*   **Projected Annual Savings:** $[(Direct Costs * 0.15) + (Admin Spend * 0.20)]
*   **Net Annual Benefit:** $[Savings - 84,000]
*   **ROI (%):** [Net Benefit / 84,000] * 100
*   **Payback Period:** [84,000 / (Savings/12)] months

### TIER 3: Enterprise/Large ($10,000/mo)
*Focus: Firm-wide Cost Intelligence + Compliance*
*   **Target Savings:** Tier 2 + 10% Software Spend Reduction.
*   **Projected Annual Savings:** $[Tier 2 Savings + (Software Spend * 0.10)]
*   **Net Annual Benefit:** $[Savings - 120,000]
*   **ROI (%):** [Net Benefit / 120,000] * 100
*   **Payback Period:** [120,000 / (Savings/12)] months

---

## 3. The "Cost of Inaction" (The 90-Day Warning)
*Closing talking point.*

"If you don't implement CostLens today, the firm is effectively choosing to spend **$[Projected Monthly Savings]** more than necessary every month. Over the next quarter, that equals **$[Projected Monthly Savings * 3]** in lost profit."

---
### Calculation Helper (Standard Benchmarks)
If the firm doesn't know their numbers, use these industry averages:
*   **Avg Direct Cost per Case:** $15,000 (Mid-market)
*   **Avg Admin Ratio:** 43% (Industry average for non-automated firms)
*   **Avg Software Spend:** $3,000/attorney/year
