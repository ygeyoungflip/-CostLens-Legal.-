# CostLens Legal — Verification Financial Analysis

**Owner:** FinOps & Licensing Agent  
**Date:** May 21, 2026  
**Spec Reference:** `/home/team/shared/verification_system_prd.md`

## Scope
This analysis covers:
1. Per-verification cost model at annual volumes: **100, 500, 1,000, 10,000**
2. Pricing recommendation (included vs one-time fee vs per-verification)
3. ROI of a “verified network”
4. Implementation budget (API integrations + dashboard)

---

## 1) Cost Model by Verification Type and Volume

### 1.1 Unit-Cost Assumptions (USD)

These assumptions use published pricing where available plus modeled ranges for quote-only categories.

| Verification Type | Low | Base (used for model) | High | Notes |
|---|---:|---:|---:|---|
| Identity checks | 0.80 | 1.20 | 2.00 | Veriff/Stripe style IDV lanes |
| Business checks | 2.00 | 3.00 | 6.00 | KYB/business registry checks often quote-based |
| Insurance checks | 1.00 | 2.00 | 4.00 | Insurance-status verification often quote-based/API dependent |
| Background checks | 25.00 | 32.00 | 40.00 | Checkr-class screening + potential pass-through fees |

> **Base blended per-verification COGS across all four categories = $38.20**

### 1.2 Annual Cost at Required Volumes (Base Case)

| Annual Volume | Identity @ $1.20 | Business @ $3.00 | Insurance @ $2.00 | Background @ $32.00 | Total Annual COGS |
|---:|---:|---:|---:|---:|---:|
| 100 | 120 | 300 | 200 | 3,200 | **3,820** |
| 500 | 600 | 1,500 | 1,000 | 16,000 | **19,100** |
| 1,000 | 1,200 | 3,000 | 2,000 | 32,000 | **38,200** |
| 10,000 | 12,000 | 30,000 | 20,000 | 320,000 | **382,000** |

### 1.3 Sensitivity Band (Low vs High)

| Annual Volume | Low Case Total (unit $28.80) | Base Case Total (unit $38.20) | High Case Total (unit $52.00) |
|---:|---:|---:|---:|
| 100 | 2,880 | 3,820 | 5,200 |
| 500 | 14,400 | 19,100 | 26,000 |
| 1,000 | 28,800 | 38,200 | 52,000 |
| 10,000 | 288,000 | 382,000 | 520,000 |

---

## 2) Pricing Recommendation and Unit Economics

## Options Compared

### Option A — Included in subscription
**Pros:** simplest buying motion, strong conversion story.  
**Cons:** margin risk if verification mix shifts toward background/compliance-heavy checks.

### Option B — One-time fee per firm
**Pros:** clean onboarding event, predictable invoice.  
**Cons:** weak alignment with ongoing verification usage; can under-recover for high-usage firms.

### Option C — Per-verification pricing
**Pros:** strongest cost-to-revenue alignment, protects margin.  
**Cons:** can add procurement friction if every check is metered.

### Recommended Model: **Hybrid**
1. Include a small baseline package in subscription (or onboarding):
   - 1 identity + 1 business + 1 insurance check (base COGS ≈ **$6.20/firm**)
2. Charge **one-time trust onboarding fee** (suggested: **$49/firm**) to cover setup + provide margin headroom.
3. Meter additional checks:
   - Identity: **$3/check**
   - Business: **$7/check**
   - Insurance: **$5/check**
   - Background: **pass-through + 20–25% platform fee**

This model balances conversion simplicity with COGS protection.

### Example Unit Economics (Base)

| Check Type | Base COGS | Suggested Price | Gross Margin $ | Gross Margin % |
|---|---:|---:|---:|---:|
| Identity | 1.20 | 3.00 | 1.80 | 60% |
| Business | 3.00 | 7.00 | 4.00 | 57% |
| Insurance | 2.00 | 5.00 | 3.00 | 60% |
| Background | 32.00 | 40.00 (or pass-through + fee) | 8.00 | 20% |

**Guideline:** keep blended verification gross margin >=55–65% excluding pass-through external fees.

---

## 3) ROI of Trust (Verified Network)

A verified network creates financial value via risk reduction, speed, and pricing power.

### 3.1 Value Drivers (Illustrative Annual)

| Value Driver | Modeling Assumption | Annual Value |
|---|---|---:|
| Reduced fraud/risk loss | problematic onboarding incidents drop from 3% to 1% on 500 firms; avg avoidable loss $5K | 50,000 |
| Faster onboarding | 5 days faster average activation across 500 firms; value of accelerated cash/revenue and ops handling | 80,000 |
| Lower manual review burden | reduced manual compliance touch time (ops + support) | 35,000 |
| Premium pricing power | “verified network” supports ~3% uplift on trust-enabled product revenue segment | 30,000 |
| **Total Modeled Annual Benefit** |  | **195,000** |

### 3.2 ROI Snapshot (Base Case)

- Implementation budget (Section 4): **$75,600**
- Verification COGS at 1,000 annual mixed checks (Section 1.2): **$38,200**
- Total Year-1 Cost: **$113,800**
- Total Modeled Annual Benefit: **$195,000**
- **Net Year-1 Benefit:** **$81,200**
- **Year-1 ROI:** `81,200 / 75,600 = 107%` (implementation-cost basis)
- **Payback Period:** `75,600 / (195,000/12) ≈ 4.7 months`

> Sensitivity: ROI increases materially with higher trust-premium capture and lower manual review intensity.

---

## 4) Implementation Budget (API Integration + Verification Dashboard)

### 4.1 Engineering Effort Estimate

| Workstream | Estimated Hours |
|---|---:|
| Verification orchestration service (routing + retries + logging) | 120 |
| Identity provider integration | 60 |
| Business + insurance verification integrations | 100 |
| Background check integration | 50 |
| Secure document upload/storage + audit trail | 70 |
| Verification dashboard (ops + status + exceptions) | 110 |
| QA, monitoring, and security hardening | 70 |
| Data instrumentation + KPI exports | 50 |
| **Total** | **630 hours** |

### 4.2 Budget Estimate

Assume blended loaded engineering cost: **$120/hour**

- One-time build budget: `630 * $120 = $75,600`
- Ongoing maintenance (approx 20 hrs/month): `240 * $120 = $28,800/year`
- Vendor/platform overhead for integration tooling and monitoring (modeled): **$6,000/year**
- **Total run-rate (post-build) annual overhead:** **$34,800/year** (excluding per-verification COGS)

---

## 5) Coordination Note (Cost-Agent Dependency)

This model is ready for immediate planning, but business/insurance categories include quote-based assumptions.  
Once cost-agent provides final API quote research, replace assumed unit costs in Sections 1.1 and 1.3 and re-run the same tables.

---

## 6) ROI Framework Linkage

Track this initiative in `/home/team/shared/roi_calculation_template.md` using:
- Baseline verification COGS and fraud-loss baseline
- Expected savings/revenue uplift from trust controls
- Implementation cost (one-time + recurring)
- Net benefit, payback, and ROI

