# CostLens Legal — Financial Analysis of Verification Providers

**Owner:** FinOps & Licensing Agent  
**Date:** May 21, 2026  
**Task:** Analyze verification API provider costs and quantify pricing implications for our product model.

---

## 1) Executive Summary

For our verification stack, providers split into two pricing patterns:

1. **Transparent per-verification pricing** (Stripe, Veriff, Checkr, Persona Essential)  
2. **Quote-based enterprise pricing** (Middesk, Alloy, CLEAR1)

Financial takeaway:
- **Identity checks** can be cost-controlled in roughly **$0.80–$1.50** per verification bands (Veriff/Stripe), with higher costs if we route to premium/hybrid/manual review paths.
- **Background screening** (Checkr) is significantly more expensive and should generally be handled as **pass-through or premium add-on**, not bundled broadly.
- **Business verification/KYB** (Middesk/Alloy/CLEAR1) should be treated as quote-dependent COGS until contracted rates are secured.

---

## 2) Provider Cost Snapshot (Public Pricing Signals)

| Provider | Verification Focus | Public Pricing Signal (US-facing pages) | Cost Visibility | Notes for Modeling |
|---|---|---|---|---|
| Stripe Identity | ID doc + selfie, ID lookup | ID doc/selfie: **$1.50 per verification**; ID number lookup: **$0.50 per lookup** | High | Good baseline for predictable identity COGS |
| Veriff (Self-Serve) | IDV/KYC | Essential **$0.80/verification** ($49 min), Plus **$1.39** ($99 min), Premium **$1.89** ($209 min) | High | Add-ons priced separately (e.g., sanctions/monitoring) |
| Persona | Identity + orchestration | Essential starts **$250/month**, includes **500 services**, then **$1.50/service**; Growth/Enterprise custom | Medium-High | Effective unit cost depends strongly on utilization of included services |
| Checkr | Identity + background checks | Identity verification **$4.99/check**; Basic background starts **$29.99/report** | High | Third-party pass-through access fees can apply |
| Middesk | KYB/business verification | Pricing not published on docs page; directs users to contact sales | Low | Must use quoted pricing before committing bundle economics |
| Alloy | Identity/KYB orchestration | No public per-check pricing visible; demo/contact motion | Low | Enterprise orchestration; assume custom contract |
| CLEAR1 | Identity verification for businesses | No public per-check pricing visible; demo/contact motion | Low | Enterprise deal flow; quote required |

---

## 3) Unit Economics Benchmarks (Illustrative)

### Identity-only verification (no background checks)

| Route | Estimated Unit COGS (from published prices) |
|---|---:|
| Veriff Essential | ~$0.80 each (subject to minimum) |
| Stripe ID doc + selfie | ~$1.50 each |
| Stripe ID doc + lookup | ~$2.00 each |
| Persona Essential (at 500 services used) | ~$0.50 effective each |
| Persona Essential (at 1,000 services used) | ~$1.00 effective each |

### Background-inclusive verification

| Route | Estimated Unit COGS |
|---|---:|
| Checkr identity only | ~$4.99 |
| Checkr Basic background package | ~$29.99+ per report |
| Checkr Basic + identity | ~$34.98+ |

> Interpretation: background and deep screening can be **10x–40x** the cost of basic identity checks.

---

## 4) Volume Sensitivity (Monthly)

### Example cost at 1,000 identity verifications/month

| Provider/Plan | Approx Monthly Cost |
|---|---:|
| Veriff Essential | ~$800 |
| Stripe Identity (ID doc/selfie) | ~$1,500 |
| Persona Essential | ~$1,000 |
| Checkr identity only | ~$4,990 |

This creates substantial margin differences depending on default routing logic.

---

## 5) Financial Risks & Controls

1. **Quoted-provider risk** (Middesk/Alloy/CLEAR1): unknown unit economics until contract signed.  
   - Control: require pricing schedule + volume tiers before go-live.
2. **Background screening cost spikes** (Checkr usage expansion).  
   - Control: policy-gate background checks behind premium workflow rules.
3. **Low utilization penalty** (minimum monthly commitments).  
   - Control: commit to plans only after forecasted throughput supports minimums.
4. **Pass-through fee variability** (court/data access fees).  
   - Control: maintain pass-through ledger and separate these from platform margin metrics.

---

## 6) Recommendation to Product + Finance

- Use a **low-cost identity provider route** (Veriff Essential or Stripe Identity) as default onboarding lane.
- Treat **background checks** and **advanced KYB/compliance checks** as premium, metered services.
- Keep quote-based providers in pricing models as variable inputs until commercial quotes are received.

---

## 7) Sources (retrieved May 21, 2026)

- Stripe Pricing (Identity section): https://stripe.com/pricing  
- Veriff Self-Serve Plans: https://www.veriff.com/pricing  
- Persona Plans Overview: https://help.withpersona.com/articles/6oZbzp7jb7AWGClF5vpY3K/  
- Checkr Pricing: https://checkr.com/pricing  
- Middesk Verify Business docs (contact sales access model): https://docs.middesk.com/verify-business  
- Middesk contact/pricing flow: https://www.middesk.com/contact  
- Alloy onboarding page (demo/contact model): https://www.alloy.com/onboarding  
- CLEAR1 business identity platform (contact/demo model): https://identity.clearme.com/

