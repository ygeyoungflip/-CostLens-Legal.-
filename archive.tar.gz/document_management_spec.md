# Document Management System — Implementation Specification

## Developer-Ready Build Spec: API Endpoints, Data Models, Encryption & Backup

**Prepared by:** Operations Optimization Agent  
**Date:** May 22, 2026  
**Status:** Approved design → Developer implementation spec  
**Target Stack:** Node.js/TypeScript backend, AWS S3, PostgreSQL, Elasticsearch, Redis

---

## 1. Data Models (PostgreSQL)

### 1.1 Core Tables

#### `firms`
```sql
CREATE TABLE firms (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            VARCHAR(255) NOT NULL,
  slug            VARCHAR(100) UNIQUE NOT NULL,
  color           VARCHAR(7) NOT NULL DEFAULT '#4F46E5',
  verification_status VARCHAR(20) DEFAULT 'unverified',
    -- enum: unverified, pending, verified, badged, revoked
  tier            VARCHAR(20) DEFAULT 'standard',
    -- enum: standard, enterprise
  storage_bucket  VARCHAR(255),
  settings        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_firms_slug ON firms(slug);
CREATE INDEX idx_firms_status ON firms(verification_status);
```

#### `users`
```sql
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  email           VARCHAR(255) UNIQUE NOT NULL,
  name            VARCHAR(255) NOT NULL,
  role            VARCHAR(20) NOT NULL DEFAULT 'associate',
    -- enum: firm_admin, partner, associate, paralegal, client_read, costlens_admin
  bar_number      VARCHAR(50),
  avatar_url      VARCHAR(500),
  mfa_enabled     BOOLEAN DEFAULT FALSE,
  is_active       BOOLEAN DEFAULT TRUE,
  settings        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_users_firm ON users(firm_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

#### `cases`
```sql
CREATE TABLE cases (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  practice_area   VARCHAR(100),
  case_number     VARCHAR(100) NOT NULL,
  title           VARCHAR(500) NOT NULL,
  status          VARCHAR(20) DEFAULT 'active',
    -- enum: active, closed, archived
  court_name      VARCHAR(255),
  plaintiff       VARCHAR(500),
  defendant       VARCHAR(500),
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_cases_firm ON cases(firm_id);
CREATE INDEX idx_cases_status ON cases(status);
CREATE UNIQUE INDEX idx_cases_number_firm ON cases(firm_id, case_number);
```

#### `documents`
```sql
CREATE TABLE documents (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         UUID NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  uploaded_by     UUID NOT NULL REFERENCES users(id),
  filename        VARCHAR(500) NOT NULL,
  s3_key          VARCHAR(1000) NOT NULL,
  s3_bucket       VARCHAR(255) NOT NULL,
  s3_region       VARCHAR(50) DEFAULT 'us-east-1',
  file_size       BIGINT NOT NULL,
  mime_type       VARCHAR(100) NOT NULL,
  file_hash       VARCHAR(64) NOT NULL,
  category        VARCHAR(50) DEFAULT 'general',
    -- enum: pleading, discovery, correspondence, draft, final, exhibit, general
  doc_type        VARCHAR(100),
  status          VARCHAR(20) DEFAULT 'active',
    -- enum: active, archived, deleted, quarantined
  version_number  INTEGER NOT NULL DEFAULT 1,
  version_group   UUID NOT NULL,
  is_latest       BOOLEAN DEFAULT TRUE,
  sensitivity     VARCHAR(20) DEFAULT 'internal',
    -- enum: public, internal, confidential, highly_confidential
  encryption_key_id VARCHAR(255),
  legal_hold      BOOLEAN DEFAULT FALSE,
  virus_scan_status VARCHAR(20) DEFAULT 'pending',
    -- enum: pending, clean, infected, skipped
  ocr_status      VARCHAR(20) DEFAULT 'pending',
    -- enum: pending, completed, failed, skipped
  ocr_text        TEXT,
  search_indexed  BOOLEAN DEFAULT FALSE,
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);
CREATE INDEX idx_documents_case ON documents(case_id);
CREATE INDEX idx_documents_firm ON documents(firm_id);
CREATE INDEX idx_documents_category ON documents(category);
CREATE INDEX idx_documents_version_group ON documents(version_group);
CREATE INDEX idx_documents_legal_hold ON documents(legal_hold) WHERE legal_hold = TRUE;
```

#### `document_versions`
```sql
CREATE TABLE document_versions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version_group   UUID NOT NULL,
  version_number  INTEGER NOT NULL,
  document_id     UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  s3_key          VARCHAR(1000) NOT NULL,
  file_size       BIGINT NOT NULL,
  file_hash       VARCHAR(64) NOT NULL,
  label           VARCHAR(255),
  change_summary  TEXT,
  created_by      UUID NOT NULL REFERENCES users(id),
  is_auto_save    BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_versions_group ON document_versions(version_group);
CREATE UNIQUE INDEX idx_versions_number ON document_versions(version_group, version_number);
```

#### `document_access_log`
```sql
CREATE TABLE document_access_log (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id     UUID NOT NULL REFERENCES documents(id),
  user_id         UUID REFERENCES users(id),
  action          VARCHAR(50) NOT NULL,
    -- enum: view, download, edit, upload, delete, restore, share, print
  ip_address      INET,
  user_agent      TEXT,
  success         BOOLEAN DEFAULT TRUE,
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_access_log_doc ON document_access_log(document_id);
CREATE INDEX idx_access_log_date ON document_access_log(created_at);
```

---

## 2. API Endpoints (REST)

**Base URL:** `https://api.costlens.legal/v1`  
**Auth:** All endpoints require `Authorization: Bearer <JWT>` header.  
JWT payload: `{ user_id, firm_id, role, exp, iat }`

### 2.1 Document CRUD

#### `POST /firms/{firm_id}/cases/{case_id}/documents/upload-url`
Generate a pre-signed S3 URL for direct client-side upload.

**Request:**
```json
{
  "filename": "Complaint.pdf",
  "file_size": 2450000,
  "mime_type": "application/pdf",
  "category": "pleading",
  "sensitivity": "confidential"
}
```
**Response (200):**
```json
{
  "upload_url": "https://costlens-uploads.s3.amazonaws.com/...?X-Amz-Signature=...",
  "document_id": "uuid",
  "s3_key": "firms/{firm_id}/cases/{case_id}/{document_id}/Complaint.pdf",
  "expires_in": 900
}
```
**Errors:** `401` (unauthorized), `403` (permissions), `413` (size >50MB), `415` (unsupported type)

---

#### `POST /firms/{firm_id}/cases/{case_id}/documents/confirm`
Confirm upload completed and trigger processing pipeline.

**Request:**
```json
{
  "document_id": "uuid",
  "s3_key": "firms/.../Complaint.pdf",
  "file_hash": "sha256hexhash"
}
```
**Response (200):**
```json
{
  "document_id": "uuid",
  "status": "processing",
  "processing_steps": ["virus_scan", "ocr", "index"]
}
```

---

#### `GET /firms/{firm_id}/cases/{case_id}/documents`
List all documents in a case.

**Query params:** `?category=pleading&status=active&page=1&per_page=50&sort=created_at:desc`

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "filename": "Complaint.pdf",
      "category": "pleading",
      "file_size": 2450000,
      "version_number": 3,
      "status": "active",
      "uploaded_by": { "id": "uuid", "name": "Jane Smith" },
      "created_at": "2026-05-20T14:00:00Z",
      "url": "https://app.costlens.legal/d/{firm_id}/{doc_id}?token={jwt}"
    }
  ],
  "pagination": {
    "page": 1, "per_page": 50, "total": 24, "total_pages": 1
  }
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}`
Get document metadata and access token.

**Response (200):**
```json
{
  "id": "uuid",
  "filename": "Complaint.pdf",
  "case": { "id": "uuid", "title": "Acme Corp v. State", "case_number": "2026-001" },
  "category": "pleading",
  "status": "active",
  "version_number": 3,
  "version_group": "uuid",
  "file_size": 2450000,
  "mime_type": "application/pdf",
  "sensitivity": "confidential",
  "virus_scan_status": "clean",
  "ocr_status": "completed",
  "uploaded_by": { "id": "uuid", "name": "Jane Smith" },
  "legal_hold": false,
  "created_at": "2026-05-20T14:00:00Z",
  "versions": [
    { "version_number": 3, "label": "Partner review complete", "created_by": "Bob Wilson", "created_at": "..." },
    { "version_number": 1, "label": "Uploaded from template", "created_by": "Jane Smith", "created_at": "..." }
  ],
  "access_url": "https://app.costlens.legal/d/{firm_id}/{doc_id}?token={jwt}"
}
```

---

#### `DELETE /firms/{firm_id}/documents/{document_id}`
Soft delete a document.

**Response (200):**
```json
{
  "status": "deleted",
  "document_id": "uuid",
  "deleted_at": "2026-05-22T10:00:00Z"
}
```
**Errors:** `409` (legal hold), `403` (permissions)

---

### 2.2 Version Management

#### `POST /firms/{firm_id}/documents/{document_id}/versions`
Create a new manual version.

**Request:**
```json
{
  "label": "Partner review complete",
  "change_summary": "Updated citation format per court rules"
}
```
**Response (200):**
```json
{
  "version_id": "uuid",
  "version_number": 4,
  "document_id": "uuid"
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}/versions`
List all versions.

**Response (200):**
```json
{
  "versions": [
    { "version_number": 3, "label": "Partner review complete", "created_by": "Bob Wilson", "created_at": "...",
      "file_size": 2500000, "file_hash": "sha256..." }
  ]
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}/versions/{v1}/diff?compare_to={v2}`
Get diff between two versions.

**Response (200):**
```json
{
  "version_a": 3, "version_b": 5,
  "diff": [
    { "type": "insertion", "text": "new paragraph text", "position": 1240 },
    { "type": "deletion", "text": "old text removed", "position": 560 }
  ],
  "stats": { "insertions": 45, "deletions": 12, "net_change": "+33 words" }
}
```

---

### 2.3 Notifications

#### `POST /firms/{firm_id}/documents/{document_id}/send`
Trigger auto-send for a document.

**Request:**
```json
{
  "action": "uploaded",
  "recipient_role": "case_attorneys",
  "priority": "normal"
}
```
**Response (200):**
```json
{
  "notification_id": "uuid",
  "recipients_count": 5,
  "queued": true
}
```

---

#### `GET /firms/{firm_id}/notifications?page=1&per_page=20`
List in-app notifications.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid", "event_type": "doc_uploaded",
      "title": "New document uploaded",
      "body": "Complaint.pdf uploaded to Acme Corp v. State",
      "document_id": "uuid", "case_id": "uuid",
      "read": false, "created_at": "2026-05-22T09:00:00Z"
    }
  ],
  "unread_count": 3
}
```

---

### 2.4 Search

#### `GET /firms/{firm_id}/search?q=complaint&category=pleading&page=1`
Full-text search across firm documents.

**Response (200):**
```json
{
  "data": [
    {
      "document_id": "uuid",
      "filename": "Complaint.pdf",
      "case_title": "Acme Corp v. State",
      "snippet": "... IN THE UNITED STATES DISTRICT COURT ... <mark>complaint</mark> ...",
      "score": 0.95
    }
  ],
  "total": 12, "page": 1
}
```

---

### 2.5 Admin Audit

#### `GET /admin/firms/{firm_id}/audit-log?page=1&per_page=100`
Full access audit log (CostLens Admin only).

**Response (200):**
```json
{
  "data": [
    {
      "timestamp": "2026-05-22T09:00:00Z",
      "user": { "name": "Jane Smith", "role": "associate" },
      "action": "view",
      "document": "Complaint.pdf",
      "case": "Acme Corp v. State",
      "ip_address": "203.0.113.42",
      "success": true
    }
  ]
}
```

---

## 3. Encryption Approach

### 3.1 Encryption Architecture

```
                  ┌─────────────────────────┐
                  │   AWS KMS Customer       │
                  │   Master Key (CMK)       │
                  │   (1 per environment)    │
                  └────────────┬────────────┘
                               │
              ┌────────────────▼────────────────┐
              │  Generate Data Key (DK)          │
              │  per document upload             │
              │  DK = Encrypted(CMK) + Plaintext │
              └────────────────┬────────────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
         ▼                     ▼                     ▼
┌──────────────┐     ┌──────────────────┐  ┌──────────────┐
│ S3 SSE-KMS   │     │ MediaFiles       │  │ Thumbnails   │
│ (documents)  │     │ (images, audio)  │  │ (previews)   │
│ AES-256-GCM  │     │ AES-256-GCM      │  │ Derived Key  │
└──────────────┘     └──────────────────┘  └──────────────┘
```

### 3.2 Encryption Specifications

| Aspect | Specification |
|--------|--------------|
| **Algorithm** | AES-256-GCM (authenticated encryption) |
| **Key management** | AWS KMS — 1 CMK per environment (dev/staging/prod) |
| **Key rotation** | Automatic annual rotation via KMS |
| **Per-document keys** | Unique Data Key (DK) per document upload |
| **DK storage** | Encrypted DK in `documents.encryption_key_id`; plaintext never persisted |
| **S3 encryption** | SSE-KMS with bucket-level default |
| **In-transit** | TLS 1.3 minimum; HSTS header |
| **Database encryption** | PostgreSQL TDE for PII fields |
| **Backup encryption** | S3 CRR with cross-region KMS key grant |

### 3.3 Upload Encryption Flow
```
1. User uploads file via pre-signed URL (TLS 1.3)
2. S3 receives file, applies SSE-KMS automatically
3. File stored encrypted at rest on S3
4. Document record created with encryption_key_id reference
5. Processing pipeline reads via S3 (KMS decrypts transparently to Lambda)
6. OCR text extracted, stored separately (also encrypted)
7. Encrypted file replicated to backup region via S3 CRR
```

### 3.4 Key Rotation Policy

| Schedule | Action |
|----------|--------|
| **Annual** | Auto KMS key rotation (AWS managed) |
| **On security event** | Manual rotation + re-encryption of affected documents |
| **On firm offboarding** | Export + delete firm-specific keys |
| **Audit** | All key access logged in CloudTrail |

---

## 4. Backup Schedule

### 4.1 Architecture
```
PRIMARY (us-east-1)
  ├── S3 Standard (hot) ── CRR ──▶ BACKUP (us-west-2)
  │   └── 90 days              │   └── 7 years
  ├── S3 Glacier (cold)        ├── S3 Glacier (cold)
  │   └── 90d → Glacier        │   └── Year 1 → Glacier Deep
  ├── PostgreSQL (RDS)         ├── RDS cross-region replica
  │   └── Daily snapshot       │   └── 7 year retention
  └── Elasticsearch            └── Cross-region snapshot
      └── Daily snapshot            └── 90 day retention
```

### 4.2 Backup Schedule (Cron)

| Component | Schedule | Retention | Method |
|-----------|----------|-----------|--------|
| **S3 documents** | Real-time (CRR) | 7 years | S3 Cross-Region Replication |
| **S3 lifecycle** | Daily evaluation | 90d Standard → Glacier; 7yr deletion | S3 Lifecycle Policy |
| **PostgreSQL** | Daily at 02:00 UTC | 7 years | RDS automated snapshots |
| **PostgreSQL (WAL)** | Continuous | 35 days (PITR) | RDS automated backup |
| **Elasticsearch** | Daily at 03:00 UTC | 90 days | Snapshot to S3 |
| **Backup region DB** | Continuous replication | 7 years | RDS cross-region replica |
| **Restore test** | Weekly (Sat 04:00 UTC) | — | Automated 5-file restore |
| **Full DR drill** | Quarterly | — | Full region failover test |

### 4.3 RPO / RTO Objectives

| Scenario | RPO | RTO |
|----------|-----|-----|
| Single document loss | <5 min (real-time CRR) | <1 hour |
| Primary region outage | <5 min (CRR lag) | <4 hours |
| Database corruption | <1 hour (PITR) | <2 hours |
| Full disaster | <1 hour | <8 hours |
| Accidental deletion | Point-in-time (35 days) | <1 hour |

### 4.4 Restore Procedures

**Document Restore:**
1. User/Admin requests restore via API or dashboard
2. System checks legal hold status
3. S3 Copy from backup region (us-west-2) to primary (us-east-1)
4. New version created with label: "Restored from backup"
5. Notification sent to case attorneys

**Database PITR:**
1. Identify target timestamp
2. RDS restore to new instance at target time
3. Validate data integrity
4. DNS switch to restored instance

**Full DR Failover:**
1. Route53 DNS switch to backup region
2. Promote RDS read replica to primary
3. Validate S3 CRR lag <5 minutes
4. Re-index Elasticsearch from S3 snapshot

---

## 5. Document Processing Pipeline

### 5.1 Workflow
```
S3 Upload Event → SQS Queue → Lambda Processor
                                  │
                        ┌─────────▼──────────┐
                        │ 1. ClamAV Virus    │
                        │    Scan            │
                        ├──────┬──────────────┤
                        │ CLEAN│   INFECTED   │
                        └──┬───┴──────┬───────┘
                           │          └──→ Quarantine + Notify
                           ▼
                    ┌──────────────┐
                    │ 2. MIME      │
                    │    Validation│
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ 3. OCR       │
                    │    (Textract)│
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ 4. Metadata  │
                    │    Extraction│
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ 5. Elastic-  │
                    │    search    │
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ 6. Auto-Send │
                    │    Trigger   │
                    └──────────────┘
```

### 5.2 Lambda Configuration

| Function | Trigger | Memory | Timeout | Runtime |
|----------|---------|--------|---------|---------|
| `virus-scan` | S3 Event → SQS | 512 MB | 120s | Node.js 20 |
| `ocr-process` | SQS (after virus scan) | 2 GB | 300s | Node.js 20 |
| `metadata-extract` | SQS (after OCR) | 512 MB | 60s | Node.js 20 |
| `search-index` | SQS (after metadata) | 1 GB | 120s | Node.js 20 |
| `auto-send` | SQS (after index) | 256 MB | 30s | Node.js 20 |

---

## 6. S3 Bucket Configuration

### 6.1 Bucket Layout
```
Bucket: costlens-{env}-documents (us-east-1)
├── firms/{firm_id}/cases/{case_id}/{document_id}/{filename}
├── firms/{firm_id}/cases/{case_id}/{document_id}/versions/v{number}/
├── firms/{firm_id}/cases/{case_id}/{document_id}/thumbnails/
└── processing/quarantine/{document_id}/

Bucket: costlens-{env}-documents-backup (us-west-2)
└── (exact replica via CRR)

Bucket: costlens-{env}-reports (us-east-1)
└── firms/{firm_id}/reports/{report_type}/{date}_{report_id}.pdf
```

### 6.2 Lifecycle Policy (Primary)
```json
{
  "rules": [
    { "id": "standard-to-glacier", "status": "Enabled",
      "transitions": [{ "days": 90, "storage_class": "GLACIER" }] },
    { "id": "expire-deleted", "status": "Enabled",
      "filter": { "prefix": "firms/" },
      "expiration": { "days": 2555 } },
    { "id": "expire-quarantine", "status": "Enabled",
      "filter": { "prefix": "processing/quarantine/" },
      "expiration": { "days": 90 } },
    { "id": "abort-incomplete-multipart", "status": "Enabled",
      "abort_incomplete_multipart_upload": { "days_after_initiation": 7 } }
  ]
}
```

### 6.3 Lifecycle Policy (Backup)
```json
{
  "rules": [
    { "id": "standard-to-glacier-deep", "status": "Enabled",
      "transitions": [{ "days": 365, "storage_class": "DEEP_ARCHIVE" }] },
    { "id": "expire-after-7-years", "status": "Enabled",
      "expiration": { "days": 2555 } }
  ]
}
```

---

## 7. Implementation Checklist

### Week 1: Foundation
- [ ] Set up S3 buckets (primary + backup) with versioning + encryption
- [ ] Configure KMS keys and IAM roles
- [ ] Create PostgreSQL tables (run migration scripts)
- [ ] Set up Elasticsearch domain
- [ ] Implement JWT auth middleware

### Week 2: Upload Pipeline
- [ ] Build pre-signed URL generation endpoint
- [ ] Implement S3 upload confirmation + SQS event
- [ ] Build ClamAV Lambda function
- [ ] Implement file validation (MIME, magic bytes, size check)
- [ ] Build OCR processing Lambda (Textract)

### Week 3: Document Management
- [ ] Build document CRUD endpoints
- [ ] Implement folder/organization structure
- [ ] Build search indexing pipeline
- [ ] Implement RBAC authorization middleware
- [ ] Build document list UI with pagination + filters

### Week 4: Backup & Versioning
- [ ] Configure S3 CRR between regions
- [ ] Set up lifecycle policies
- [ ] Implement version management endpoints
- [ ] Build version history UI
- [ ] Implement diff engine
- [ ] Set up RDS cross-region replica

### Week 5: Auto-Send & Notifications
- [ ] Build notification trigger pipeline
- [ ] Implement secure link generation (JWT)
- [ ] Build email template system
- [ ] Build in-app notification UI
- [ ] Implement notification preferences per user

### Week 6: Audit & Reports
- [ ] Build document access logging
- [ ] Implement admin audit log endpoint
- [ ] Build compliance report generation engine
- [ ] Set up weekly restore testing automation

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Ready for developer implementation*