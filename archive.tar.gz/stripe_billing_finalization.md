# CostLens Legal — Stripe Billing Finalization Plan

**Owner:** FinOps & Licensing Agent  
**Date:** May 27, 2026  
**Task:** Finalize automated billing, invoice generation, dunning, and renewal/expansion tracking in Stripe.

---

## 1) Finalization Scope

This plan closes four production billing requirements:
1. Automated recurring billing with invoice generation
2. Dunning/recovery for failed payments
3. 10% platform fee routing and CTO sweep operations
4. Renewal and expansion tracking tied to revenue KPIs

Builds on prior artifacts:
- `/home/team/shared/stripe_billing_flow_design.md`
- `/home/team/shared/billing_stripe_integration.md`
- `/home/team/shared/retention_expansion_dashboard.md`

---

## 2) Stripe Configuration Baseline

## 2.1 Billing setup
- Product catalog with tier plans (Solo/Growth/Enterprise/Ultra)
- Subscription billing cycles (monthly default)
- Auto-invoice finalization enabled
- Hosted invoice + PDF receipts enabled
- Tax behavior configured per jurisdiction as needed

## 2.2 Connect fee logic (confirmed)
- Destination charges enabled
- `application_fee_amount = round(invoice_total * 0.10)`
- Application fees held in platform balance
- Daily CTO sweep with reserve holdback

## 2.3 Required webhooks
- `invoice.created`
- `invoice.finalized`
- `invoice.paid`
- `invoice.payment_failed`
- `invoice.payment_action_required`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `checkout.session.completed`
- `charge.refunded`
- `charge.dispute.created`

---

## 3) Automated Invoice Generation Flow

1. Subscription cycle opens -> Stripe drafts invoice
2. Invoice finalized -> record `invoice_id`, `firm_id`, `tier`, gross amount
3. Payment attempt executes
4. On success:
   - apply 10% fee routing logic
   - mark invoice paid
   - trigger billing receipt notification
5. On failure:
   - trigger dunning workflow
   - open AR risk flag for renewal health scoring

### Invoice ledger fields (minimum)
- invoice_id
- firm_id
- subscription_id
- tier
- invoice_total
- platform_fee_10pct
- firm_share
- payment_status
- due_date
- paid_at

---

## 4) Dunning & Recovery Design

## 4.1 Dunning states
- `current`
- `past_due`
- `retrying`
- `action_required`
- `unpaid`
- `canceled` (policy-driven)

## 4.2 Recovery sequence (recommended)

| Day | Action |
|---|---|
| Day 0 (failure) | Trigger failure email + in-app + optional SMS |
| Day 2 | Smart retry #1 + payment method update prompt |
| Day 5 | Smart retry #2 + escalate to firm billing contact |
| Day 8 | Smart retry #3 + internal CS alert |
| Day 12 | Final notice + service-risk warning |
| Day 15 | If unpaid, suspend features or cancel per policy |

## 4.3 Dunning KPIs
- Recovery rate (`recovered_failed_invoices / failed_invoices`)
- Average recovery days
- Failed-payment churn risk rate
- Dunning-generated churn MRR

Target guardrails:
- Recovery rate >=70%
- Avg recovery time <=7 days

---

## 5) Renewal & Expansion Tracking Model

## 5.1 Renewal pipeline fields
- firm_id
- subscription_id
- renewal_date
- current_tier
- mrr
- auto_renew_enabled
- renewal_risk_score (0-100)
- owner (CS/AM)
- status (on_track/at_risk/renewed/churned)

## 5.2 Expansion signals
- tier_upgrade_opportunity_flag
- add_on_attach_opportunity
- overage_usage_trend
- unused_feature_recovery_signal
- verified_network_feature_adoption

## 5.3 Revenue linkage
Renewal and expansion updates must map into monthly revenue metrics:
- Expansion MRR
- Contraction MRR
- Churn MRR
- NRR / GRR

---

## 6) Dashboard Views (Billing + Renewal)

### View A: Billing Health
- Invoices due/paid/failed this month
- Dunning pipeline by stage
- Recovery rate and aging buckets

### View B: Renewal Forecast (next 90 days)
- Renewal value by month
- At-risk renewal MRR
- Renewal confidence (weighted forecast)

### View C: Expansion Tracker
- Upgrade opportunities by tier
- Realized expansion MRR vs target
- Expansion conversion rate by account owner

---

## 7) Test & Validation Checklist

## 7.1 Invoice automation tests
- New subscription creates invoice correctly
- Fee math and ledger entries match Stripe records
- Successful invoice sends receipt notification

## 7.2 Dunning tests
- Simulated payment failure enters past_due state
- Retry schedule executes in order
- Recovery from updated payment method closes risk

## 7.3 Renewal tracking tests
- Renewal date ingestion accurate
- At-risk flags triggered by failed payment/low usage
- Upgrade event creates expansion MRR entry

---

## 8) Implementation Estimate (Finalization)

| Workstream | Hours |
|---|---:|
| Invoice automation hardening | 14 |
| Dunning workflow + notifications | 18 |
| Renewal/expansion tracking tables + jobs | 20 |
| Dashboard wiring + QA | 16 |
| **Total** | **68 hrs** |

At $120/hr blended rate: **$8,160** one-time finalization effort.

---

## 9) Acceptance Criteria

- 100% of active subscriptions generate auditable invoices
- Failed payments enter deterministic dunning sequence
- Recovery and dunning metrics available at month-end
- Renewal pipeline reflects next 90-day MRR exposure
- Expansion events flow into NRR/GRR reporting without manual correction

