# CostLens Legal — Regulatory Compliance Framework

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Spec:** `/home/team/shared/platform_expansion_v2.md` (Regulatory Compliance + Compliance Reporting)

> This is an operational framework for product build/readiness, not legal advice.

---

## 1) Compliance Scope

This framework covers:
1. **SOC 2 readiness** (security + operational controls)
2. **GDPR compliance framework** for EU data handling
3. **ABA model-rule mapping** for law-firm ethical obligations
4. **Encryption requirements** for data at rest/in transit
5. Compliance reporting operations (with Ops team)

---

## 2) SOC 2 Readiness Checklist

Align controls to Trust Services Criteria (Security, Availability, Processing Integrity, Confidentiality, Privacy).

### Governance & access
- [ ] Security policy approved and version-controlled
- [ ] RBAC/least-privilege enforced for all production systems
- [ ] MFA for admin and privileged users
- [ ] Quarterly access recertification

### Change and deployment controls
- [ ] Ticket-linked code changes and review approvals
- [ ] CI/CD separation of duties and protected branches
- [ ] Production change logging + rollback procedures

### Monitoring & incident response
- [ ] Centralized logging and alerting
- [ ] Incident runbooks with severity matrix
- [ ] Evidence retention for incidents and postmortems

### Vendor and data controls
- [ ] Third-party risk assessments for Stripe, storage, verification vendors
- [ ] DPA/contract controls in place where needed
- [ ] Data retention and deletion schedules documented

### Audit evidence pack
- [ ] Control owner matrix
- [ ] Control test frequency and evidence locations
- [ ] Monthly compliance summary for audit trail

---

## 3) GDPR Framework (Operational)

## Core obligations mapped to operations
- **Lawful basis and transparency** (Articles 5, 6, 13/14)
- **Security of processing** (Article 32)
- **Breach notification workflow** (Articles 33/34)
- **Data subject rights handling** (access/erasure/rectification)
- **Data minimization + retention controls**

### Required implementation controls
1. Data inventory by category (identity, billing, verification docs, audit logs)
2. Purpose limitation tags on each data class
3. DSAR process with SLA and ticket tracking
4. Breach triage playbook with 72-hour regulatory notification timer
5. Regional data handling strategy for EU-origin data

---

## 4) ABA Rules Mapping (Legal-Industry Fit)

| ABA Model Rule | Product/Process Mapping | Control Requirement |
|---|---|---|
| Rule 1.6 (Confidentiality) | Protect client/firm data across verification, billing, docs | Encryption, access controls, confidential-notice workflows |
| Rule 1.1 (Competence, tech competence commentary) | Operate systems with reasonable technical safeguards | Security training, documented controls, vendor due diligence |
| Rule 5.3 (Nonlawyer assistance) | Oversight of third-party vendors processing legal data | Vendor reviews, contractual safeguards, monitoring/audit rights |
| Rule 1.15 (Safekeeping property, where applicable to funds handling) | Clarity in transaction routing and fee disclosures | Segregated ledger, transparent billing lines, reconciliation evidence |

Implementation note: provide customer-facing disclosure language for fee handling and data processing responsibilities.

---

## 5) Encryption Requirements

### Data in transit
- TLS 1.2+ minimum (prefer TLS 1.3 where available)
- HSTS and secure-cipher policies at edge

### Data at rest
- AES-256 encryption for databases/object storage/backups
- Key management with rotation policy and access logging

### Secrets/key operations
- Centralized secrets manager (no plaintext secrets in repos)
- Dual-control access for production key material
- Quarterly key rotation and emergency revocation procedure

### File/document controls
- Pre-signed upload URLs with expiry
- Malware scanning before document status = “accepted”
- Immutable audit trail for upload/download events

---

## 6) Compliance Reporting Design (Coordinate with ops-agent)

## Monthly compliance report sections
1. Control status dashboard (SOC2/GDPR/ABA mapped controls)
2. Open risks and remediation deadlines
3. Incident summary + SLA adherence
4. DSAR and privacy request metrics
5. Vendor compliance exceptions and action plan

## Minimum reporting fields
- control_id
- framework (SOC2/GDPR/ABA)
- owner
- status (pass/fail/partial)
- evidence_link
- last_test_date
- next_due_date
- risk_rating
- remediation_eta

### Ops handoff requirements
- Ops-agent owns monthly compliance report generation pipeline
- FinOps provides vendor-risk and billing-control evidence
- Joint review cadence: monthly close + quarterly deep-dive

---

## 7) 90-Day Compliance Plan

- **By May 31, 2026:** finalize control inventory + ownership matrix
- **By June 15, 2026:** implement core encryption and webhook security checks
- **By June 30, 2026:** first monthly compliance report (SOC2/GDPR/ABA mapping)
- **By July 31, 2026:** complete vendor risk assessments and remediation wave 1
- **By August 31, 2026:** readiness review for external compliance assessment

---

## 8) Reference Sources

- Stripe webhooks and security: https://docs.stripe.com/webhooks  
- GDPR official text (EU 2016/679): https://eur-lex.europa.eu/eli/reg/2016/679/oj  
- ABA Model Rule 1.6: https://www.americanbar.org/groups/professional_responsibility/publications/model_rules_of_professional_conduct/rule_1_6_confidentiality_of_information/  
- ABA Model Rule 1.1: https://www.americanbar.org/groups/professional_responsibility/publications/model_rules_of_professional_conduct/rule_1_1_competence/  
- ABA Model Rule 5.3: https://www.americanbar.org/groups/professional_responsibility/publications/model_rules_of_professional_conduct/rule_5_3_responsibilities_regarding_nonlawyer_assistance/  
- NIST AES (FIPS 197): https://csrc.nist.gov/pubs/fips/197/final  
- NIST TLS guidance (SP 800-52r2): https://csrc.nist.gov/pubs/sp/800/52/r2/final

