# Profitability Analysis Framework

This framework provides the methodology for calculating and comparing profit margins across different case types and departments within the law firm.

## 1. The Profitability Formula
For each case type (e.g., Litigation, M&A), we calculate the **Gross Margin**:

**Gross Margin (%) = [(Total Billable Revenue - Direct Costs) / Total Billable Revenue] * 100**

### A. Total Billable Revenue
*   Fees invoiced and collected for the matter.
*   Exclude pass-through expenses (reimbursables) to avoid inflating revenue.

### B. Direct Costs (The "True Cost")
*   **Labor Cost:** (Hours Logged by Role) * (Internal Hourly Cost Rate). 
    *   *Note: Cost rate = (Salary + Benefits + Direct Support) / 2,000 hours.*
*   **Case Expenses:** Filing fees, expert witnesses, travel, and specialized software (E-Discovery).
*   **Allocated Tech:** Per-case share of research and practice management tools.

## 2. Comparison Metrics
To identify the "Best" and "Worst" performing practice areas:

| Metric | High Profit (Target) | Low Profit (Audit Needed) |
| :--- | :--- | :--- |
| **Gross Margin** | >50% | <30% |
| **Effective Hourly Rate (EHR)** | >$500/hr | <$250/hr |
| **Leverage Ratio** | 4:1 (Assoc/Paralegal to Partner) | 1:1 (Partner Heavy) |

## 3. Profitability Tiers by Case Type (Strategic Analysis)
*   **Tier 1: High Margin/High Complexity (e.g., M&A, Specialized IP)**
    *   Goal: Maximize volume and speed.
*   **Tier 2: Steady State (e.g., General Litigation)**
    *   Goal: Optimize via automation and delegation (move work to lower-cost roles).
*   **Tier 3: Volume/Fixed Fee (e.g., Real Estate, Basic Intake)**
    *   Goal: Heavy automation (Class A tasks) to protect slim margins.

## 4. Bottleneck Impact on Profit
A 10% delay in workflow velocity (e.g., stage completion) typically correlates to a 5-8% decrease in Gross Margin due to increased "Admin Drag" and opportunity cost.
