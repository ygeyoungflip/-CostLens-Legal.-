# CostLens Legal — ROI Calculation Template (Standard)

**Version:** 1.0  
**Date:** May 20, 2026  
**Purpose:** Standardize how all cost-reduction initiatives quantify financial impact.

---

## 1) Required Inputs

For every initiative, capture the following:

1. **Initiative Name**
2. **Owner**
3. **Objective** (e.g., reduce billing cycle by 20%)
4. **Baseline Cost (Annual)**
5. **Expected % Reduction**
6. **Expected Annual Gross Savings**
7. **Implementation Cost (One-time)**
8. **Ongoing Incremental Cost (Annual)**
9. **Net Annual Savings**
10. **Payback Period (months)**
11. **Net ROI (%)**
12. **Confidence Level** (High / Medium / Low)
13. **Measurement Window** (e.g., 90 days, 2 quarters)
14. **Dependencies/Risks**

---

## 2) Core Formulas

Let:
- **B** = baseline annual cost
- **R** = expected reduction percentage (as decimal)
- **I** = one-time implementation cost
- **O** = ongoing incremental annual cost

Then:

1. **Gross Annual Savings** = `B * R`
2. **Net Annual Savings** = `(B * R) - O`
3. **Year-1 Net Benefit** = `Net Annual Savings - I`
4. **Payback Period (months)** = `I / (Net Annual Savings / 12)`
5. **Net ROI (%)** = `((Year-1 Net Benefit) / I) * 100`

> If `I = 0`, report ROI as “Immediate” and payback as `0 months`.

---

## 3) Standard Initiative Scorecard (Copy/Paste)

## Initiative
- **Name:**
- **Owner:**
- **Start Date:**
- **Measurement Window:**

## Financial Baseline
- **Baseline Annual Cost (B):** $
- **Expected Reduction % (R):**
- **Gross Annual Savings (B*R):** $

## Cost to Implement
- **One-time Implementation Cost (I):** $
- **Ongoing Annual Incremental Cost (O):** $

## ROI Outputs
- **Net Annual Savings ((B*R)-O):** $
- **Year-1 Net Benefit (Net Savings - I):** $
- **Payback Period (months):**
- **Net ROI (%):**

## Quality & Risk
- **Confidence Level:** High / Medium / Low
- **Top 3 Assumptions:**
  1.
  2.
  3.
- **Top 3 Risks:**
  1.
  2.
  3.

## Validation
- **Data Source(s):** invoices, usage logs, finance GL, vendor quotes
- **Reviewed By:**
- **Review Date:**

---

## 4) Example (Licensing Consolidation)

- Baseline Annual Licensing Cost (B): **$310,200**
- Expected Reduction (R): **15.0%**
- Gross Annual Savings: **$46,560**
- One-time Implementation Cost (I): **$12,000**
- Ongoing Incremental Cost (O): **$0**

Calculated:
- Net Annual Savings: **$46,560**
- Year-1 Net Benefit: **$34,560**
- Payback Period: **3.1 months**
- Net ROI: **288.0%**

---

## 5) Cross-Team KPI Normalization Rules

To compare initiatives across operations, cost, sales, and FinOps:
- Use annualized baseline whenever possible.
- Show both **gross savings** and **net savings**.
- Separate one-time from recurring impacts.
- Provide confidence rating with assumptions.
- Recalculate at 30/60/90 days using realized data.

