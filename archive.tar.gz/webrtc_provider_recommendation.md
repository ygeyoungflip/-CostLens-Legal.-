# WebRTC Video Provider Recommendation

CostLens Legal requires a secure, HIPAA-compliant, and easy-to-integrate video collaboration tool. This document compares three major providers and recommends the best fit for our platform.

## 1. Provider Comparison

| Feature | Daily.co | LiveKit | Twilio Video |
| :--- | :--- | :--- | :--- |
| **Ease of Integration** | **Excellent** (Prebuilt UI) | Good (Highly customizable) | N/A (Sunsetted) |
| **HIPAA/SOC2** | Yes (BAA provided) | Yes (Cloud version) | Yes |
| **Pricing Model** | $0.004/min (10k free mins) | $0.004/min (Cloud) | N/A |
| **Security** | End-to-End Encryption | End-to-End Encryption | N/A |
| **Status** | Active & Growing | Active & Growing | **EOL (Dec 5, 2024)** |

### Twilio Video (Disqualified)
Twilio sunsetted its Programmable Video product on **December 5, 2024**. It is no longer an option for new implementations.

### LiveKit
LiveKit is a powerful, open-source-based stack. It is excellent for developers who want deep control over the video experience. However, it requires significant front-end development to build a polished user interface.

### Daily.co (Recommended)
Daily.co is the best fit for CostLens Legal because of **Daily Prebuilt**. This component provides a fully functional, professional video interface that can be embedded into our platform with just a few lines of code. This drastically reduces our "time-to-market."

## 2. Recommendation Rationale

**Winner: Daily.co**

*   **Speed to Market:** The "Daily Prebuilt" UI saves approximately 2-4 weeks of engineering effort compared to building a custom video layout.
*   **Legal Compliance:** Daily.co is specifically geared toward regulated industries, offering the necessary **Business Associate Agreement (BAA)** for HIPAA compliance.
*   **Cost Efficiency:** The first 10,000 minutes per month are free, which covers the initial onboarding phase for our first 10-15 firms.
*   **Scalability:** It handles the global infrastructure (TURN/STUN servers) automatically, ensuring high-quality calls for firms regardless of location.

## 3. Pricing Estimate (50 Law Firms)

*   **Assumptions:** 50 firms, 10 calls/month each, 3 participants per call, 30 mins/call.
*   **Total Participant Minutes:** 45,000 minutes/month.
*   **Daily.co Free Tier:** -10,000 minutes.
*   **Billable Minutes:** 35,000 minutes.
*   **Usage Cost:** 35,000 * $0.004 = **$140/mo**.
*   **Security/HIPAA Add-on:** ~$250/mo (Platform fee).
*   **Estimated Total:** **$390/month** (approx. $7.80 per firm).

## 4. Integration Steps

### Step 1: Backend (Room Management)
Create a unique, temporary room for each Matter using the Daily API.
```bash
curl -X POST https://api.daily.co/v1/rooms \
     -H "Authorization: Bearer $DAILY_API_KEY" \
     -d '{"properties":{"exp": 1716412800}}'
```

### Step 2: Security (Meeting Tokens)
Generate a meeting token to ensure only authorized users (Attorneys/Clients) can enter.
```bash
curl -X POST https://api.daily.co/v1/meeting-tokens \
     -H "Authorization: Bearer $DAILY_API_KEY" \
     -d '{"properties":{"room_name":"matter-xyz-room", "is_owner":true}}'
```

### Step 3: Frontend (Embedding)
Use the `@daily-co/daily-js` SDK to embed the video call into the Case view.
```javascript
import DailyIframe from '@daily-co/daily-js';

const callFrame = DailyIframe.createFrame({
  url: 'https://costlens.daily.co/matter-xyz?token=M_TOKEN',
  showLeaveButton: true
});
callFrame.join();
```

---
*Authored by: CostLens Agent | May 2026*
