# CostLens Legal — Referral Incentive Economics Model

**Owner:** FinOps & Licensing Agent  
**Date:** May 27, 2026  
**Task:** Model referral incentive economics and integration into expansion revenue reporting.

---

## 1) Program Objective

Use referrals to:
1. Lower acquisition cost vs outbound/paid channels
2. Increase high-intent conversion quality
3. Support expansion revenue flywheel (trusted network effects)

---

## 2) Recommended Referral Incentive Structure

### Incentive payout (by referred firm tier)
- **Solo/Starter referral:** $400 reward
- **Growth referral:** $1,500 reward
- **Enterprise referral:** $2,500 reward
- **Ultra referral:** custom negotiated (default 0.5–1.0% of first-month ACV equivalent cap)

### Payout protection rules
- Payout only after referred firm completes **2 successful paid months**
- One payout per net-new referred firm
- Fraud controls: no self-referrals, shared domain checks, duplicate entity checks

### Additional ops cost assumption
- Program administration + processing cost: **$300 per converted referral**

---

## 3) Unit Economics by Tier (Referral CAC vs Direct CAC)

Assumptions:
- Baseline direct blended CAC = **$7,500 per new firm** (from current CAC framework)
- Monthly contribution after 10% Stripe routing + included verification COGS:
  - Solo: **$886**
  - Growth: **$6,198**
  - Enterprise: **$8,702**

| Tier | Referral Reward | Ops Cost | Total Referral CAC | Savings vs $7,500 Direct CAC | Payback Months (`ref_cac / monthly_contribution`) |
|---|---:|---:|---:|---:|---:|
| Solo | 400 | 300 | **700** | **6,800** | **0.8** |
| Growth | 1,500 | 300 | **1,800** | **5,700** | **0.3** |
| Enterprise | 2,500 | 300 | **2,800** | **4,700** | **0.3** |

Interpretation: referral CAC is materially below direct CAC across target tiers.

---

## 4) Scenario Analysis (15 Referred Firms)

Illustrative mix: 3 Solo, 5 Growth, 7 Enterprise

- Direct-CAC spend avoided: `15 * 7,500 = $112,500`
- Referral program spend:
  - Rewards + ops = **$30,700**
- CAC savings vs direct acquisition = **$81,800**

Year-1 contribution from these 15 referred firms (modeled): **$1,134,744**

Referral program ROI (contribution basis):
- `((1,134,744 - 30,700) / 30,700) * 100 = 3,596%`

---

## 5) Dashboard KPIs for Referral Economics

Add these KPIs to retention/expansion dashboard:

| KPI | Formula | Target |
|---|---|---|
| Referral-Sourced MRR | `sum(mrr where acquisition_channel='referral')` | Upward trend |
| Referral CAC | `(rewards_paid + referral_ops_cost) / referred_firms_converted` | <=$2,500 blended |
| Referral Conversion Rate | `referred_firms_converted / referred_leads` | >=20% |
| Referral Payback Months | `referral_cac / monthly_contribution_per_referral` | <=3 months |
| Referral Share of New MRR | `new_mrr_from_referrals / total_new_mrr` | >=20% medium-term |
| Referral Fraud/Invalid Rate | `invalid_referrals / total_referrals` | <5% |

---

## 6) Data Capture Model

### `referral_events`
- referral_id
- referrer_firm_id
- referred_firm_name
- referred_tier
- referral_source
- referral_status (lead/qualified/converted/invalid)
- created_at
- converted_at

### `referral_payouts`
- payout_id
- referral_id
- reward_amount_usd
- ops_cost_usd
- payout_eligibility_date
- payout_status
- payout_date

### `referral_attribution`
- month
- referred_firm_id
- mrr_usd
- contribution_usd
- payback_months

---

## 7) Governance Rules

- All referral payouts require finance approval batch weekly
- Payouts blocked for disputed invoices or chargebacks during first 60 days
- Quarterly recalibration of reward amounts by tier performance and CAC delta

---

## 8) Next Steps

1. Add `Referral Source` and `Referral Status` discipline to CRM/pipeline workflow (field already present in tracker).
2. Launch pilot with 20 referred prospects and review conversion quality after 30 days.
3. Add referral KPI tiles to the retention/expansion dashboard pack.

