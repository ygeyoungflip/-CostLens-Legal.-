# CostLens Legal — Underused Resource Detection Framework (FinOps Expansion)

**Owner:** FinOps & Licensing Agent  
**Date:** May 20, 2026  
**Purpose:** Extend FinOps beyond license consolidation to systematically detect underused resources and convert waste into measurable savings.

---

## 1) Scope: What Counts as an Underused Resource

This framework tracks four resource classes:

1. **Software licenses** (SaaS seats, add-ons, premium modules)
2. **Vendor service capacity** (retainers, support hours, managed service blocks)
3. **Operational tooling capacity** (automation tasks, BI workspace capacity, storage tiers)
4. **Revenue-support capacity** (onboarding/support allocations not matched to active pipeline or signed clients)

---

## 2) Detection Rules (Standardized)

### A) License Utilization Tiers (trailing 30 days)
- **Healthy:** >=80% activity
- **Watchlist:** 60–79%
- **Underused:** 40–59%
- **Idle/Candidate for removal:** <40%

### B) Vendor Retainer Utilization
- **Utilization %** = `consumed_hours / contracted_hours`
- Flag underused when utilization is **<65%** for 2 consecutive months.

### C) Automation/Platform Capacity
- **Capacity utilization %** = `actual_usage / committed_capacity`
- Flag underused when **<55%** sustained for 6+ weeks.

### D) Exception Policy Drift
- Flag when approved exceptions exceed threshold or expire without closure:
  - Exception count > target
  - Exception age > 60 days

---

## 3) KPI Set (New + Existing Integration)

| KPI | Formula | Baseline (modeled) | Target | Cadence |
|---|---|---:|---:|---|
| Underused License Cost | `sum(tool_cost * underused_seat_ratio)` | $32,000 | <$10,000 | Weekly |
| Idle Seat Count | `sum(seats with <40% activity)` | 22 | <=5 | Weekly |
| Retainer Waste | `contracted_value - consumed_value` | $14,000 | <$4,000 | Monthly |
| Exception Aging | `avg(days_open_exceptions)` | 47 days | <=21 days | Weekly |
| Reclaimed Capacity Value | `removed_or_reassigned_cost` | $0 | $20,000+ annualized | Monthly |

---

## 4) Detection Workflow (Operational)

1. **Collect telemetry** (vendor admin exports + contract cost mapping)
2. **Score utilization** by resource class and owner
3. **Generate watchlist** with dollar impact
4. **Trigger actions** (remove, downgrade, reassign, renegotiate)
5. **Verify realized savings** at month-end finance close

Output artifacts each cycle:
- Underused resource watchlist (ranked by savings potential)
- Action register (owner, due date, status)
- Realized savings reconciliation log

---

## 5) Alert Thresholds (for early cost alerts)

- Any tool with utilization drop >15pp month-over-month
- Any tool with idle-seat cost >$1,000/month
- Any retainer with <50% consumption for 2 months
- Any exception inventory growth >20% in a month

Escalation path:
- Week 1 alert: team owner
- Week 2 unresolved: Ops + FinOps joint review
- Week 3 unresolved: leadership escalation

---

## 6) 90-Day Rollout Plan

- **By May 27, 2026:** finalize utilization extract template for top 10 spend tools
- **By June 10, 2026:** publish first underused-resource watchlist
- **By June 30, 2026:** complete first finance-reconciled realized-savings report
- **By July 31, 2026:** enforce quarterly true-down on flagged tools
- **By August 20, 2026:** lock recurring savings from reclaimed capacity

---

## 7) ROI Tie-In (Required)

For every underused-resource action:
- Baseline annual cost
- Expected reclaim %
- Implementation effort cost
- Net annual savings
- Payback months
- Confidence level

Use `/home/team/shared/roi_calculation_template.md` for all entries.

