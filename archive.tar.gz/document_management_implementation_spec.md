# Document Management System — Implementation Specification

## Developer-Ready Build Spec: API Endpoints, Data Models, Encryption & Backup

**Prepared by:** Operations Optimization Agent  
**Date:** May 22, 2026  
**Status:** Approved design → Developer implementation spec  
**Target Stack:** Node.js/TypeScript backend, AWS S3, PostgreSQL, Elasticsearch, Redis

---

## 1. Data Models (PostgreSQL)

### 1.1 Core Tables

#### `firms`
```sql
CREATE TABLE firms (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            VARCHAR(255) NOT NULL,
  slug            VARCHAR(100) UNIQUE NOT NULL,  -- URL-friendly
  color           VARCHAR(7) NOT NULL DEFAULT '#4F46E5',  -- hex color
  verification_status VARCHAR(20) DEFAULT 'unverified',
    -- enum: unverified, pending, verified, badged, revoked
  tier            VARCHAR(20) DEFAULT 'standard',
    -- enum: standard, enterprise
  storage_bucket  VARCHAR(255),                    -- S3 bucket name
  settings        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_firms_slug ON firms(slug);
CREATE INDEX idx_firms_status ON firms(verification_status);
```

#### `users`
```sql
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  email           VARCHAR(255) UNIQUE NOT NULL,
  name            VARCHAR(255) NOT NULL,
  role            VARCHAR(20) NOT NULL DEFAULT 'associate',
    -- enum: firm_admin, partner, associate, paralegal, client_read, costlens_admin
  bar_number      VARCHAR(50),                     -- state bar number
  avatar_url      VARCHAR(500),
  mfa_enabled     BOOLEAN DEFAULT FALSE,
  is_active       BOOLEAN DEFAULT TRUE,
  settings        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_firm ON users(firm_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

#### `cases`
```sql
CREATE TABLE cases (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  practice_area   VARCHAR(100),                    -- e.g., M&A, Litigation, IP
  case_number     VARCHAR(100) NOT NULL,
  title           VARCHAR(500) NOT NULL,
  status          VARCHAR(20) DEFAULT 'active',
    -- enum: active, closed, archived
  court_name      VARCHAR(255),
  plaintiff       VARCHAR(500),
  defendant       VARCHAR(500),
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_cases_firm ON cases(firm_id);
CREATE INDEX idx_cases_status ON cases(status);
CREATE UNIQUE INDEX idx_cases_number_firm ON cases(firm_id, case_number);
```

#### `case_assignments`
```sql
CREATE TABLE case_assignments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         UUID NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_on_case    VARCHAR(50),                     -- lead, associate, support
  assigned_at     TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(case_id, user_id)
);

CREATE INDEX idx_assignments_case ON case_assignments(case_id);
CREATE INDEX idx_assignments_user ON case_assignments(user_id);
```

#### `documents`
```sql
CREATE TABLE documents (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id         UUID NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  firm_id         UUID NOT NULL REFERENCES firms(id) ON DELETE CASCADE,
  uploaded_by     UUID NOT NULL REFERENCES users(id),
  
  -- Identity
  filename        VARCHAR(500) NOT NULL,           -- original filename
  s3_key          VARCHAR(1000) NOT NULL,           -- S3 object key
  s3_bucket       VARCHAR(255) NOT NULL,
  s3_region       VARCHAR(50) DEFAULT 'us-east-1',
  file_size       BIGINT NOT NULL,                  -- bytes
  mime_type       VARCHAR(100) NOT NULL,
  file_hash       VARCHAR(64) NOT NULL,             -- SHA-256
  
  -- Classification
  category        VARCHAR(50) DEFAULT 'general',
    -- enum: pleading, discovery, correspondence, draft, final, exhibit, general
  doc_type        VARCHAR(100),                    -- specific: complaint, motion, contract
  status          VARCHAR(20) DEFAULT 'active',
    -- enum: active, archived, deleted, quarantined
  
  -- Version info
  version_number  INTEGER NOT NULL DEFAULT 1,
  version_group   UUID NOT NULL,                   -- groups all versions of same doc
  is_latest       BOOLEAN DEFAULT TRUE,
  
  -- Security
  sensitivity     VARCHAR(20) DEFAULT 'internal',
    -- enum: public, internal, confidential, highly_confidential
  encryption_key_id VARCHAR(255),                  -- KMS key ID used for encryption
  legal_hold      BOOLEAN DEFAULT FALSE,
  
  -- Processing
  virus_scan_status VARCHAR(20) DEFAULT 'pending',
    -- enum: pending, clean, infected, skipped
  ocr_status      VARCHAR(20) DEFAULT 'pending',
    -- enum: pending, completed, failed, skipped
  ocr_text        TEXT,                             -- extracted text
  search_indexed  BOOLEAN DEFAULT FALSE,
  
  -- Metadata
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ                       -- soft delete
);

CREATE INDEX idx_documents_case ON documents(case_id);
CREATE INDEX idx_documents_firm ON documents(firm_id);
CREATE INDEX idx_documents_category ON documents(category);
CREATE INDEX idx_documents_version_group ON documents(version_group);
CREATE INDEX idx_documents_status ON documents(status);
CREATE INDEX idx_documents_legal_hold ON documents(legal_hold) WHERE legal_hold = TRUE;
```

#### `document_versions`
```sql
CREATE TABLE document_versions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version_group   UUID NOT NULL,                   -- matches documents.version_group
  version_number  INTEGER NOT NULL,
  document_id     UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  s3_key          VARCHAR(1000) NOT NULL,           -- version-specific S3 key
  file_size       BIGINT NOT NULL,
  file_hash       VARCHAR(64) NOT NULL,
  label           VARCHAR(255),                    -- "Partner review draft"
  change_summary  TEXT,
  created_by      UUID NOT NULL REFERENCES users(id),
  is_auto_save    BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_versions_group ON document_versions(version_group);
CREATE INDEX idx_versions_document ON document_versions(document_id);
CREATE UNIQUE INDEX idx_versions_number ON document_versions(version_group, version_number);
```

#### `document_access_log`
```sql
CREATE TABLE document_access_log (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id     UUID NOT NULL REFERENCES documents(id),
  user_id         UUID REFERENCES users(id),
  action          VARCHAR(50) NOT NULL,
    -- enum: view, download, edit, upload, delete, restore, share, print
  ip_address      INET,
  user_agent      TEXT,
  success         BOOLEAN DEFAULT TRUE,
  metadata        JSONB DEFAULT '{}',
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_access_log_doc ON document_access_log(document_id);
CREATE INDEX idx_access_log_user ON document_access_log(user_id);
CREATE INDEX idx_access_log_action ON document_access_log(action);
CREATE INDEX idx_access_log_date ON document_access_log(created_at);
```

#### `notifications_queue`
```sql
CREATE TABLE notifications_queue (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type      VARCHAR(50) NOT NULL,
    -- enum: doc_uploaded, doc_finalized, doc_updated, doc_shared, doc_expiring
  document_id     UUID REFERENCES documents(id),
  case_id         UUID REFERENCES cases(id),
  firm_id         UUID NOT NULL REFERENCES firms(id),
  recipient_ids   UUID[] NOT NULL,                  -- array of user IDs
  email_sent      BOOLEAN DEFAULT FALSE,
  inapp_sent      BOOLEAN DEFAULT FALSE,
  sent_at         TIMESTAMPTZ,
  error_log       TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notif_type ON notifications_queue(event_type);
CREATE INDEX idx_notif_sent ON notifications_queue(email_sent, inapp_sent);
```

---

## 2. API Endpoints (REST)

### Base URL: `https://api.costlens.legal/v1`

#### Authentication
All endpoints require `Authorization: Bearer <JWT>` header.
JWT payload: `{ user_id, firm_id, role, exp, iat }`

---

### 2.1 Document CRUD

#### `POST /firms/{firm_id}/cases/{case_id}/documents/upload-url`

**Purpose:** Generate a pre-signed S3 URL for direct client-side upload.

**Request:**
```json
{
  "filename": "Complaint.pdf",
  "file_size": 2450000,
  "mime_type": "application/pdf",
  "category": "pleading",
  "sensitivity": "confidential"
}
```

**Response (200):**
```json
{
  "upload_url": "https://costlens-uploads.s3.amazonaws.com/...?X-Amz-Signature=...",
  "document_id": "uuid",
  "s3_key": "firms/{firm_id}/cases/{case_id}/{document_id}/Complaint.pdf",
  "expires_in": 900
}
```

**Error codes:**
- `401` — Unauthorized / invalid JWT
- `403` — Insufficient role permissions
- `413` — File exceeds 50MB limit
- `415` — Unsupported file type

---

#### `POST /firms/{firm_id}/cases/{case_id}/documents/confirm`

**Purpose:** Confirm upload completed and trigger processing pipeline.

**Request:**
```json
{
  "document_id": "uuid",
  "s3_key": "firms/.../Complaint.pdf",
  "file_hash": "sha256hexhash"
}
```

**Response (200):**
```json
{
  "document_id": "uuid",
  "status": "processing",
  "processing_steps": ["virus_scan", "ocr", "index"]
}
```

---

#### `GET /firms/{firm_id}/cases/{case_id}/documents`

**Purpose:** List all documents in a case.

**Query params:** `?category=pleading&status=active&page=1&per_page=50&sort=created_at:desc`

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "filename": "Complaint.pdf",
      "category": "pleading",
      "file_size": 2450000,
      "version_number": 3,
      "status": "active",
      "uploaded_by": { "id": "uuid", "name": "Jane Smith" },
      "created_at": "2026-05-20T14:00:00Z",
      "url": "https://app.costlens.legal/d/{firm_id}/{doc_id}?token={jwt}"
    }
  ],
  "pagination": {
    "page": 1,
    "per_page": 50,
    "total": 24,
    "total_pages": 1
  }
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}`

**Purpose:** Get document metadata and access token.

**Response (200):**
```json
{
  "id": "uuid",
  "filename": "Complaint.pdf",
  "case": { "id": "uuid", "title": "Acme Corp v. State", "case_number": "2026-001" },
  "category": "pleading",
  "status": "active",
  "version_number": 3,
  "version_group": "uuid",
  "file_size": 2450000,
  "mime_type": "application/pdf",
  "sensitivity": "confidential",
  "virus_scan_status": "clean",
  "ocr_status": "completed",
  "uploaded_by": { "id": "uuid", "name": "Jane Smith" },
  "legal_hold": false,
  "created_at": "2026-05-20T14:00:00Z",
  "versions": [
    { "version_number": 3, "label": "Partner review complete", "created_by": "Bob Wilson", "created_at": "..." },
    { "version_number": 2, "label": null, "is_auto_save": true, "created_at": "..." },
    { "version_number": 1, "label": "Uploaded from template", "created_by": "Jane Smith", "created_at": "..." }
  ],
  "access_url": "https://app.costlens.legal/d/{firm_id}/{doc_id}?token={jwt}"
}
```

---

#### `DELETE /firms/{firm_id}/documents/{document_id}`

**Purpose:** Soft delete a document.

**Response (200):**
```json
{
  "status": "deleted",
  "document_id": "uuid",
  "deleted_at": "2026-05-22T10:00:00Z"
}
```

**Error codes:**
- `409` — Document is on legal hold (cannot delete)
- `403` — Insufficient permissions

---

### 2.2 Version Management

#### `POST /firms/{firm_id}/documents/{document_id}/versions`

**Purpose:** Create a new manual version.

**Request:**
```json
{
  "label": "Partner review complete",
  "change_summary": "Updated citation format per court rules"
}
```

**Response (200):**
```json
{
  "version_id": "uuid",
  "version_number": 4,
  "document_id": "uuid"
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}/versions`

**Purpose:** List all versions of a document.

**Response (200):**
```json
{
  "versions": [
    { "version_number": 3, "label": "Partner review complete", "created_by": "Bob Wilson", "created_at": "...",
      "file_size": 2500000, "file_hash": "sha256..." },
    ...
  ]
}
```

---

#### `GET /firms/{firm_id}/documents/{document_id}/versions/{version_number}/diff?compare_to={version_number}`

**Purpose:** Get diff between two document versions.

**Response (200):**
```json
{
  "version_a": 3,
  "version_b": 5,
  "diff": [
    { "type": "insertion", "text": "new paragraph text", "position": 1240 },
    { "type": "deletion", "text": "old text removed", "position": 560 },
    { "type": "modification", "original": "...", "updated": "...", "position": 890 }
  ],
  "stats": {
    "insertions": 45,
    "deletions": 12,
    "net_change": "+33 words"
  }
}
```

---

### 2.3 Auto-Send / Notifications

#### `POST /firms/{firm_id}/documents/{document_id}/send`

**Purpose:** Trigger auto-send for a document.

**Request:**
```json
{
  "action": "uploaded",
  "recipient_role": "case_attorneys",
  "priority": "normal"
}
```

**Response (200):**
```json
{
  "notification_id": "uuid",
  "recipients_count": 5,
  "queued": true
}
```

---

#### `GET /firms/{firm_id}/notifications?page=1&per_page=20`

**Purpose:** List in-app notifications for current user.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "event_type": "doc_uploaded",
      "title": "New document uploaded",
      "body": "Complaint.pdf uploaded to Acme Corp v. State",
      "document_id": "uuid",
      "case_id": "uuid",
      "read": false,
      "created_at": "2026-05-22T09:00:00Z"
    }
  ],
  "unread_count": 3
}
```

---

### 2.4 Search

#### `GET /firms/{firm_id}/search?q=complaint&category=pleading&page=1`

**Purpose:** Full-text search across firm documents.

**Response (200):**
```json
{
  "data": [
    {
      "document_id": "uuid",
      "filename": "Complaint.pdf",
      "case_title": "Acme Corp v. State",
      "snippet": "... IN THE UNITED STATES DISTRICT COURT ... <mark>complaint</mark> ...",
      "score": 0.95
    }
  ],
  "total": 12,
  "page": 1
}
```

---

### 2.5 Admin

#### `GET /admin/firms/{firm_id}/audit-log?page=1&per_page=100`

**Purpose:** Full access audit log (CostLens Admin only).

**Response (200):**
```json
{
  "data": [
    {
      "timestamp": "2026-05-22T09:00:00Z",
      "user": { "name": "Jane Smith", "role": "associate" },
      "action": "view",
      "document": "Complaint.pdf",
      "case": "Acme Corp v. State",
      "ip_address": "203.0.113.42",
      "success": true
    }
  ]
}
```

---

## 3. Encryption Approach

### 3.1 Encryption Strategy

```
                        ┌─────────────────────────┐
                        │   AWS KMS Customer       │
                        │   Master Key (CMK)       │
                        │   (1 per environment)    │
                        └────────────┬────────────┘
                                     │
                    ┌────────────────▼────────────────┐
                    │  Generate Data Key (DK)          │
                    │  per document upload             │
                    │  DK = Encrypted(CMK) + Plaintext │
                    └────────────────┬────────────────┘
                                     │
              ┌──────────────────────┼──────────────────────┐
              │                      │                      │
              ▼                      ▼                      ▼
     ┌──────────────┐     ┌──────────────────┐   ┌──────────────┐
     │ S3 SSE-KMS   │     │ MediaFiles       │   │ Thumbnails   │
     │ (documents)  │     │ (images, audio)  │   │ (previews)   │
     │ AES-256      │     │ AES-256          │   │ AES-256      │
     │ KMS Key      │     │ KMS Key          │   │ Derived Key  │
     └──────────────┘     └──────────────────┘   └──────────────┘
```

### 3.2 Implementation

| Aspect | Specification |
|--------|--------------|
| **Algorithm** | AES-256-GCM (authenticated encryption) |
| **Key management** | AWS KMS — 1 Customer Master Key per environment (dev/staging/prod) |
| **Key rotation** | Automatic annual rotation via KMS |
| **Per-document keys** | Each document encrypted with a unique Data Key (DK) |
| **DK storage** | Encrypted DK stored in `documents.encryption_key_id`; plaintext DK never persisted |
| **S3 encryption** | SSE-KMS with bucket-level default |
| **In-transit** | TLS 1.3 minimum; HSTS header |
| **Database encryption** | PostgreSQL TDE or application-level encryption for PII fields |
| **Backup encryption** | S3 cross-region replication with same KMS (cross-region key grant) |

### 3.3 Encryption Flow (Upload)

```
1. User uploads file via pre-signed URL (TLS 1.3)
2. S3 receives file, applies SSE-KMS automatically
3. File stored encrypted at rest on S3
4. Document record created with encryption_key_id reference
5. Processing pipeline reads via S3 (KMS decrypts transparently to Lambda)
6. OCR text extracted, stored separately (also encrypted)
7. Encrypted file replicated to backup region via S3 CRR
```

### 3.4 Key Rotation Policy

| Schedule | Action |
|----------|--------|
| **Annual** | Auto KMS key rotation (AWS managed) |
| **On security event** | Manual rotation + re-encryption of affected documents |
| **On firm offboarding** | Export + delete firm-specific keys |
| **Audit** | All key access logged in CloudTrail |

---

## 4. Backup Schedule

### 4.1 Backup Architecture

```
PRIMARY (us-east-1)
  ├── S3 Standard (hot) ── CRR ──▶ BACKUP (us-west-2)
  │   └── 90 days              │   └── 7 years
  │                             │
  ├── S3 Glacier (cold)         ├── S3 Glacier (cold)
  │   └── 90 days → Glacier     │   └── Year 1 → Glacier Deep
  │                             │
  ├── PostgreSQL (RDS)          ├── RDS cross-region replica
  │   └── Daily snapshot        │   └── 7 year retention
  │                             │
  └── Elasticsearch             └── Cross-region snapshot
      └── Daily snapshot             └── 90 day retention
```

### 4.2 Backup Schedule (Cron)

| Component | Schedule | Retention | Method |
|-----------|----------|-----------|--------|
| **S3 documents** | Real-time (CRR) | 7 years | S3 Cross-Region Replication |
| **S3 lifecycle** | Daily evaluation | 90d Standard → Glacier; 7yr deletion | S3 Lifecycle Policy |
| **PostgreSQL** | Daily at 02:00 UTC | 7 years (daily snapshots) | RDS automated snapshots |
| **PostgreSQL (WAL)** | Continuous | 35 days (PITR) | RDS automated backup |
| **Elasticsearch** | Daily at 03:00 UTC | 90 days | Snapshot to S3 |
| **Database (backup region)** | Continuous replication | 7 years | RDS cross-region replica |
| **Restore test** | Weekly (Saturday 04:00 UTC) | — | Automated 5-file restore test |
| **Full DR drill** | Quarterly | — | Full region failover test |

### 4.3 RPO / RTO Objectives

| Scenario | RPO (Recovery Point Objective) | RTO (Recovery Time Objective) |
|----------|-------------------------------|------------------------------|
| **Single document loss** | <5 min (real-time CRR) | <1 hour |
| **Primary region outage** | <5 min (CRR lag) | <4 hours (DNS switch + region failover) |
| **Database corruption** | <1 hour (PITR) | <2 hours |
| **Full disaster** | <1 hour | <8 hours |
| **Accidental deletion** | Point-in-time to any point in last 35 days | <1 hour |

### 4.4 Restore Procedure

```
DOCUMENT RESTORE:
  1. User/Admin requests restore via API or dashboard
  2. System checks: legal hold status (if on hold, prevent deletion, allow restore)
  3. S3 Copy from backup region (us-west-2) to primary (us-east-1)
  4. New version created in version history with label: "Restored from backup"
  5. Notification sent to case attorneys

DATABASE PITR:
  1. Identify target timestamp
  2. RDS restore to new instance at target time
  3. Validate data integrity
  4. DNS switch to restored instance
  5. Log in audit trail

FULL DR FAILOVER:
  1. Route53 DNS switch to backup region
  2. Promote RDS read replica to primary
  3. Validate S3 CRR lag <5 minutes
  4. Re-index Elasticsearch from S3 snapshot
  5. Monitor for 30 minutes before declaring success
```

---

## 5. Processing Pipeline

### 5.1 Document Processing Workflow

```
S3 Upload Event → SQS Queue → Lambda Processor
                                  │
                        ┌─────────▼──────────┐
                        │ 1. Virus Scan      │
                        │    (ClamAV Lambda)  │
                        ├──────┬──────────────┤
                        │ CLEAN│   INFECTED   │
                        └──┬───┴──────┬───────┘
                           │          └──→ Quarantine bucket
                           │              + Notify admin
                           ▼
                    ┌──────────────┐
                    │ 2. MIME      │
                    │    Validation│
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ 3. File Type │
                    │    Check     │
                    ├──────┬───────┤
                    │IMAGE/│ OTHER │
                    │PDF   │       │
                    └──┬───┘       │
                       │           │
                    ┌──▼──┐        │
                    │ 4.  │        │
                    │ OCR │        │
                    └──┬──┘        │
                       │           │
                    ┌──▼───────────▼──┐
                    │ 5. Metadata     │
                    │    Extraction   │
                    └──────┬─────────┘
                           │
                    ┌──────▼─────────┐
                    │ 6. Elastic-    │
                    │    search Index│
                    └──────┬─────────┘
                           │
                    ┌──────▼─────────┐
                    │ 7. Mark        │
                    │    Processing  │
                    │    Complete    │
                    └──────┬─────────┘
                           │
                    ┌──────▼─────────┐
                    │ 8. Trigger     │
                    │    Auto-Send   │
                    │    Notification│
                    └───────────────┘
```

### 5.2 Lambda Configuration

| Function | Trigger | Memory | Timeout | Runtime |
|----------|---------|--------|---------|---------|
| `virus-scan` | S3 Event → SQS | 512 MB | 120s | Node.js 20 |
| `ocr-process` | SQS (after virus scan) | 2 GB | 300s | Node.js 20 |
| `metadata-extract` | SQS (after OCR) | 512 MB | 60s | Node.js 20 |
| `search-index` | SQS (after metadata) | 1 GB | 120s | Node.js 20 |
| `auto-send-trigger` | SQS (after index) | 256 MB | 30s | Node.js 20 |

---

## 6. S3 Bucket Configuration

### 6.1 Bucket Layout

```
Bucket: costlens-{env}-documents (us-east-1)
├── firms/{firm_id}/cases/{case_id}/{document_id}/{filename}
├── firms/{firm_id}/cases/{case_id}/{document_id}/versions/v{number}/
├── firms/{firm_id}/cases/{case_id}/{document_id}/thumbnails/
└── processing/quarantine/{document_id}/

Bucket: costlens-{env}-documents-backup (us-west-2)
└── (exact replica via CRR)

Bucket: costlens-{env}-reports (us-east-1)
└── firms/{firm_id}/reports/{report_type}/{date}_{report_id}.pdf
```

### 6.2 Lifecycle Policy (Primary Bucket)

```json
{
  "rules": [
    {
      "id": "standard-to-glacier",
      "status": "Enabled",
      "filter": {},
      "transitions": [
        { "days": 90, "storage_class": "GLACIER" }
      ]
    },
    {
      "id": "expire-deleted-documents",
      "status": "Enabled",
      "filter": { "prefix": "firms/" },
      "expiration": {
        "days": 2555,
        "expired_object_delete_marker": true
      }
    },
    {
      "id": "expire-quarantine",
      "status": "Enabled",
      "filter": { "prefix": "processing/quarantine/" },
      "expiration": { "days": 90 }
    },
    {
      "id": "abort-incomplete-multipart",
      "status": "Enabled",
      "filter": {},
      "abort_incomplete_multipart_upload": { "days_after_initiation": 7 }
    }
  ]
}
```

### 6.3 Lifecycle Policy (Backup Bucket)

```json
{
  "rules": [
    {
      "id": "standard-to-glacier-deep",
      "status": "Enabled",
      "transitions": [
        { "days": 365, "storage_class": "DEEP_ARCHIVE" }
      ]
    },
    {
      "id": "expire-after-7-years",
      "status": "Enabled",
      "expiration": { "days": 2555 }
    }
  ]
}
```

---

## 7. Compliance Report Template (Markdown)

### 7.1 Firm Verification Summary Template

The following is a fillable markdown template. Placeholder variables are denoted by `{{double_curly_braces}}`.

```markdown
# CostLens Legal — Firm Verification Summary

**Report ID:** `VS-{{report_date}}-{{sequential_id}}`
**Generated:** {{generated_date}}
**Status:** Auto-generated | Digitally Signed

---

## Firm Overview

| Field | Value |
|-------|-------|
| **Firm Name** | {{firm_name}} |
| **Verification Status** | {{verification_status}} |
| **Verified Since** | {{verified_since_date}} |
| **Badge ID** | {{badge_id}} |

---

## Verification Checks Summary

| Check | Status | Date | Details |
|-------|--------|------|---------|
| **Identity Verification** | {{identity_status}} | {{identity_date}} | Provider: {{identity_provider}} |
| | | | Method: {{identity_method}} |
| | | | Reference: {{identity_reference}} |
| **Business Registration** | {{business_status}} | {{business_date}} | EIN: {{business_ein}} |
| | | | Registration: {{business_registration_status}} |
| | | | Watchlist: {{business_watchlist_result}} |
| **Insurance** | {{insurance_status}} | {{insurance_date}} | Carrier: {{insurance_carrier}} |
| | | | Policy: {{insurance_policy_number}} |
| | | | Coverage: ${{insurance_coverage_amount}} |
| | | | **Expires: {{insurance_expiry_date}}** |
| **AML / Compliance** | {{aml_status}} | {{aml_date}} | Sanctions: {{aml_sanctions_result}} |
| | | | PEP: {{aml_pep_result}} |
| | | | Adverse Media: {{aml_adverse_media_result}} |
| **Documents Received** | {{docs_status}} | {{docs_date}} | Engagement Letter: {{doc_engagement}} |
| | | | Business Registration: {{doc_registration}} |
| | | | Insurance Certificate: {{doc_insurance}} |
| | | | Data Agreement: {{doc_data_agreement}} |

---

## Decision

| Field | Value |
|-------|-------|
| **Final Decision** | {{final_decision}} |
| **Decision Date** | {{decision_date}} |
| **Approved By** | {{approved_by}} |
| **Risk Level** | {{risk_level}} |
| **Notes** | {{decision_notes}} |

---

## Activity Log (Last 30 Days)

| Date | Action | Details |
|------|--------|---------|
| {{log_date_1}} | {{log_action_1}} | {{log_detail_1}} |
| {{log_date_2}} | {{log_action_2}} | {{log_detail_2}} |
| {{log_date_3}} | {{log_action_3}} | {{log_detail_3}} |
| {{log_date_4}} | {{log_action_4}} | {{log_detail_4}} |
| {{log_date_5}} | {{log_action_5}} | {{log_detail_5}} |

---

## Alerts & Flags

{{#if has_alerts}}
| Severity | Alert | Action Required | Deadline |
|----------|-------|----------------|----------|
| {{alert_severity_1}} | {{alert_message_1}} | {{alert_action_1}} | {{alert_deadline_1}} |
| {{alert_severity_2}} | {{alert_message_2}} | {{alert_action_2}} | {{alert_deadline_2}} |
{{else}}
No active alerts. All checks current.
{{/if}}

---

## Digital Signature

```
Signed: CostLens Legal Compliance System
Signature: {{digital_signature}}
Timestamp: {{signature_timestamp}}
SHA-256: {{content_hash}}
```

---

*This report is auto-generated and digitally signed. Retain per data retention policy (7 years).*
*Report generated by CostLens Legal — AI-Powered Legal Cost Intelligence*
```

### 7.2 Example Filled Report (Sample Data)

```markdown
# CostLens Legal — Firm Verification Summary

**Report ID:** `VS-2026-05-22-001`
**Generated:** May 22, 2026
**Status:** Auto-generated | Digitally Signed

---

## Firm Overview

| Field | Value |
|-------|-------|
| **Firm Name** | Gibson Dunn |
| **Verification Status** | ✅ Verified (Badged) |
| **Verified Since** | May 18, 2026 |
| **Badge ID** | BADGE-GD-2026-001 |

---

## Verification Checks Summary

| Check | Status | Date | Details |
|-------|--------|------|---------|
| **Identity Verification** | ✅ PASS | May 18, 2026 | Provider: Stripe Identity |
| | | | Method: Government ID + Selfie Liveness |
| | | | Reference: GOV-ID-98765 |
| **Business Registration** | ✅ ACTIVE | May 18, 2026 | EIN: XX-XXXXXXX |
| | | | Registration: Active |
| | | | Watchlist: No Match |
| **Insurance** | ✅ VALID | May 18, 2026 | Carrier: Chubb |
| | | | Policy: PL-98765 |
| | | | Coverage: $2,000,000 |
| | | | **Expires: June 18, 2026** |
| **AML / Compliance** | ✅ CLEAR | May 18, 2026 | Sanctions: No Match |
| | | | PEP: No |
| | | | Adverse Media: No |
| **Documents Received** | ✅ Complete | May 18, 2026 | Engagement Letter: ✅ |
| | | | Business Registration: ✅ |
| | | | Insurance Certificate: ✅ |
| | | | Data Agreement: ✅ |

---

## Decision

| Field | Value |
|-------|-------|
| **Final Decision** | ✅ Auto-Approved |
| **Decision Date** | May 18, 2026 |
| **Approved By** | Automated (Low Risk, All Checks Pass) |
| **Risk Level** | Low |
| **Notes** | First firm onboarded. Standard verification completed. |

---

## Activity Log (Last 30 Days)

| Date | Action | Details |
|------|--------|---------|
| May 22, 2026 | Document Uploaded | 12 documents uploaded to Case 2026-001 |
| May 20, 2026 | User Login | Firm Admin J. Smith logged in (IP: 203.0.113.42) |
| May 19, 2026 | Document Access | 5 documents viewed across 2 cases |
| May 18, 2026 | Badge Awarded | Verification badge awarded automatically |
| May 17, 2026 | Welcome Email Sent | Onboarding verification link delivered |

---

## Alerts & Flags

| Severity | Alert | Action Required | Deadline |
|----------|-------|----------------|----------|
| ⚠️ Warning | Insurance cert expiring in 27 days | Upload renewed certificate | June 18, 2026 |

---

## Digital Signature

```
Signed: CostLens Legal Compliance System
Signature: CLSIG-A1B2C3D4E5F6-20260522
Timestamp: 2026-05-22T10:00:00Z
SHA-256: a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b
```

---

*This report is auto-generated and digitally signed. Retain per data retention policy (7 years).*
*Report generated by CostLens Legal — AI-Powered Legal Cost Intelligence*
```

---

## 8. Implementation Checklist

### Week 1: Foundation
- [ ] Set up S3 buckets (primary + backup) with versioning + encryption
- [ ] Configure KMS keys and IAM roles
- [ ] Create PostgreSQL tables (run migration scripts)
- [ ] Set up Elasticsearch domain
- [ ] Implement JWT auth middleware

### Week 2: Upload Pipeline
- [ ] Build pre-signed URL generation endpoint
- [ ] Implement S3 upload confirmation + SQS event
- [ ] Build ClamAV Lambda function
- [ ] Implement file validation (MIME, magic bytes, size check)
- [ ] Build OCR processing Lambda (Textract)

### Week 3: Document Management
- [ ] Build document CRUD endpoints
- [ ] Implement folder/organization structure
- [ ] Build search indexing pipeline
- [ ] Implement RBAC authorization middleware
- [ ] Build document list UI with pagination + filters

### Week 4: Backup & Versioning
- [ ] Configure S3 CRR between regions
- [ ] Set up lifecycle policies
- [ ] Implement version management endpoints
- [ ] Build version history UI
- [ ] Implement diff engine
- [ ] Set up RDS cross-region replica

### Week 5: Auto-Send & Notifications
- [ ] Build notification trigger pipeline
- [ ] Implement secure link generation (JWT)
- [ ] Build email template system
- [ ] Build in-app notification UI
- [ ] Implement notification preferences per user

### Week 6: Audit & Reports
- [ ] Build document access logging
- [ ] Implement admin audit log endpoint
- [ ] Build compliance report generation engine
- [ ] Implement report template (Firm Verification Summary)
- [ ] Set up weekly restore testing automation

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Ready for developer implementation*