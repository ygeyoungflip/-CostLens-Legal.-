# Case Cost Breakdown Template

**Case Name:** [Case Name]
**Matter ID:** [Matter ID]
**Case Type:** [Litigation/Corporate/IP/Family/Real Estate]
**Responsible Attorney:** [Attorney Name]
**Team/Department:** [e.g., Commercial Litigation Team A]
**Case Stage:** [Initial Filing / Discovery / Pre-trial / Trial]

## 1. Professional Fees (Internal)
| Role | Name | Hours Logged | Rate | Total Cost | Efficiency Score (Billable/Logged) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Partner | | | | | |
| Associate | | | | | |
| Paralegal | | | | | |
| **Total Professional Fees** | | | | **$0.00** | |

## 2. Direct Case Expenses (Out-of-Pocket)
| Category | Vendor/Description | Cost |
| :--- | :--- | :--- |
| Filing Fees | | |
| E-Discovery Software | | |
| Document Review (Ext) | | |
| Expert Witness Fees | | |
| Deposition Transcripts | | |
| Travel & Meals | | |
| **Total Direct Expenses** | | **$0.00** |

## 3. Technology & Research Allocation
*Standard allocation per case basis.*
* Research Subscription (Westlaw/Lexis): $[Amount]
* Practice Management Software: $[Amount]
* Document Storage: $[Amount]
* **Total Technology Allocation:** **$0.00**

## 4. Workflow & Bottleneck Detection
*   **Stage Start Date:** [Date]
*   **Estimated Days to Complete:** [Days]
*   **Actual Days to Complete:** [Days]
*   **Bottleneck Identified?** [Yes/No]
*   **Primary Cause of Delay:** [Intake/Conflict Check/Client Response/Discovery Volume/Court Scheduling]

## 5. Automation Opportunity Log
*   **Manual Task Surfaced:** [e.g., Manual Indexing of 500 documents]
*   **Time Spent:** [Hours]
*   **Automation Potential:** [Class A/B/C]
*   **Estimated Savings if Automated:** $[Amount]

## 6. Summary Metrics
* **Total Internal Cost:** $[Total Fees]
* **Total External Expense:** $[Total Direct]
* **Billable Revenue:** $[Revenue]
* **Gross Profit Margin per Case:** [(Billable Revenue - Total Cost) / Billable Revenue]
* **Effective Hourly Rate (EHR):** [Total Revenue / Total Hours]
* **Cost vs. Budget Variance:** [Actual / Budgeted]

---
**Early Warning Indicators:**
*   [ ] Discovery expenses exceed 25% of total budget.
*   [ ] Paralegal hours are less than 10% of total hours (suggests inefficient attorney tasks).
*   [ ] Expert witness fees exceed initial estimate by 20%.
