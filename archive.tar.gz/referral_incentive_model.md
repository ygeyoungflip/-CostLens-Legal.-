# CostLens Legal — Referral Incentive Program Model

**Owner:** FinOps & Licensing Agent  
**Date:** May 27, 2026  
**Context:** `/home/team/shared/retention_scaling_playbook.md` initiative #4

---

## 1) Program Goals

1. Lower acquisition cost relative to direct outbound/paid channels
2. Increase win-rate via trusted peer introductions
3. Drive expansion-ready accounts with better retention fit

---

## 2) Reward Structure Options (Requested)

## Option A — One Month Free Credit
- Referrer receives credit equal to 1 month of referred firm's plan value
- Payout form: account credit (preferred) vs cash

## Option B — 10% of First-Year Value
- Reward = 10% of first-year contract value of referred firm

## Option C — Recommended Hybrid with Cap (Cost-Controlled)
- Lower of:
  - one month free credit, or
  - 10% first-year value
- **Cap at $5,000** for standard program (custom terms for Ultra)
- Reward released only after referred firm completes 2 paid months

---

## 3) Cost vs Acquisition Value Analysis

### Tier economics assumptions
- Direct blended CAC benchmark: **$7,500 per firm**
- Monthly contribution per firm (from current tier economics):
  - Solo: **$886**
  - Growth: **$6,198**
  - Enterprise: **$8,702**

### 3.1 Reward cost by option

| Tier | Plan Price/mo | Option A: 1 Month Free | Option B: 10% First-Year | Hybrid Cap Outcome |
|---|---:|---:|---:|---:|
| Solo | 1,000 | 1,000 | 1,200 | 1,000 |
| Growth | 7,000 | 7,000 | 8,400 | 5,000 (cap) |
| Enterprise | 10,000 | 10,000 | 12,000 | 5,000 (cap) |

### 3.2 Cost vs acquisition value (direct CAC)

| Tier | Direct CAC | Option A Cost Delta | Option B Cost Delta | Hybrid Cost Delta |
|---|---:|---:|---:|---:|
| Solo | 7,500 | +6,500 better than direct | +6,300 better | +6,500 better |
| Growth | 7,500 | +500 better | -900 worse | +2,500 better |
| Enterprise | 7,500 | -2,500 worse | -4,500 worse | +2,500 better |

(Positive delta = cheaper than direct CAC)

### 3.3 Payback illustration (hybrid)

| Tier | Hybrid Reward Cost | Monthly Contribution | Payback Months |
|---|---:|---:|---:|
| Solo | 1,000 | 886 | 1.13 |
| Growth | 5,000 | 6,198 | 0.81 |
| Enterprise | 5,000 | 8,702 | 0.57 |

Interpretation: hybrid capped model remains fast-payback across tiers while avoiding oversized enterprise payouts.

---

## 4) Recommended Program Design

### Recommended default
Use **Option C (Hybrid with Cap)**:
- Reward = min(1 month plan value, 10% first-year value, $5,000 cap)
- Eligibility = referred firm reaches 2 paid months
- Reward type = platform credit first, cash by exception

### Ultra tier policy
- Ultra-tier referrals handled by custom agreement with executive approval
- Cap and percentage negotiated per deal economics

---

## 5) Tracking Mechanism

## 5.1 System fields
Add/maintain in pipeline + billing layer:
- referrer_firm_id
- referred_firm_id
- referral_source
- referral_status (lead/qualified/converted/invalid)
- referred_tier
- reward_type
- reward_amount
- payout_eligibility_date
- payout_status
- payout_date

## 5.2 Process flow
1. Referral submitted -> record created
2. Referred firm signs -> status = converted_pending
3. After 2 successful paid months -> status = payout_eligible
4. Weekly finance batch approves + posts credit/payout
5. Dashboard attributes MRR + ARR + payback to referral channel

## 5.3 KPI tracking
- Referral leads
- Referral conversion rate
- Referral CAC
- Referral-sourced MRR/ARR
- Referral payback months
- Invalid/fraud referral rate

---

## 6) Fraud & Governance Controls

- No self-referrals (domain/entity checks)
- Duplicate referral suppression
- Manual review for large-tier referrals
- Payout hold for chargeback/dispute during first 60 days
- Quarterly recalibration of cap and payout logic

---

## 7) Decision Summary

- **Do not** use uncapped “1 month free” or “10% first year” globally.
- **Use capped hybrid** to protect unit economics while maintaining strong referral incentive appeal.
- Track referral channel economics inside retention/expansion dashboard and review monthly.

