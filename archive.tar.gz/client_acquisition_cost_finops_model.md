# CostLens Legal — Client Acquisition Cost (CAC) FinOps Model

**Owner:** FinOps & Licensing Agent  
**Date:** May 20, 2026  
**Purpose:** Extend FinOps to cover growth economics so sign-up expansion (50 firms in 3 months) is tied to cost efficiency, payback, and ROI.

---

## 1) Core CAC Definitions

### Primary CAC
`CAC = (Sales + Marketing + Acquisition Tooling + Onboarding Cost) / New Signed Firms`

### Segment CAC
`Segment CAC = segment_acquisition_cost / segment_signups`

### Payback Period (months)
`CAC Payback = CAC / Monthly Gross Margin per New Firm`

### LTV:CAC Ratio
`LTV:CAC = Estimated Client Lifetime Gross Margin / CAC`

---

## 2) Cost Buckets to Include (Fully Loaded)

1. **Sales Labor**: SDR/AE compensation + commissions
2. **Marketing Spend**: paid campaigns, events, content production, list/data spend
3. **Sales Tooling**: CRM, sequencing tools, dialers, enrichment tools
4. **Demo/Pre-sales Cost**: solution engineering time, trial support
5. **Onboarding/Activation Cost**: implementation support, training, customer success ramp

Do not exclude tooling costs already paid annually; allocate pro-rata by period.

---

## 3) 90-Day Target Model (Aligned to Team Goal)

### Goal
- **50 firm sign-ups by August 20, 2026**

### Proposed guardrails
- Target blended CAC: **<= $8,500 per firm**
- CAC payback: **<= 6 months**
- LTV:CAC: **>= 3.0x**

### Example planning scenario (modeled)
- 90-day acquisition spend: **$375,000**
- Expected sign-ups: **50 firms**
- **Modeled CAC:** `$375,000 / 50 = $7,500`
- If monthly gross margin per new firm = **$1,400**, payback = `7,500 / 1,400 = 5.4 months`

---

## 4) Funnel-Efficiency Layer (Required)

Track conversion efficiency by stage to control CAC drivers:
- Leads sourced
- Qualified opportunities
- Demos completed
- Proposals sent
- Closed-won firms

Derived KPIs:
- Cost per lead (CPL)
- Cost per demo
- Cost per proposal
- Win rate
- CAC by channel (outbound, referral, partnership, paid)

---

## 5) Top CAC Cost Drivers to Monitor

1. **Low demo-to-close conversion** (high labor/tooling burn per closed deal)
2. **Channel mix inefficiency** (over-index on high-CAC paid channels)
3. **Slow onboarding activation** (delays payback and inflates support cost)

---

## 6) FinOps Actions to Reduce CAC

- Reallocate spend to lowest-CAC channels monthly
- Enforce tooling utilization minimums (remove unused sales-tool seats)
- Standardize onboarding playbooks to reduce activation labor per firm
- Tie campaign budget approvals to expected payback and LTV:CAC thresholds
- Require ROI card before launching new acquisition programs

---

## 7) Reporting Cadence

- **Weekly:** CAC pulse (spend-to-date, signups-to-date, blended CAC)
- **Biweekly:** channel reallocation review
- **Monthly close:** finance-reconciled CAC + payback + LTV:CAC
- **Quarterly:** benchmark against target guardrails and reset spend mix

---

## 8) Data Capture Requirements

Minimum fields per reporting period:
- Period start/end
- Spend by cost bucket
- Spend by channel
- New firms signed
- Gross margin per new firm (assumption + actual)
- Onboarding time to activation

Use `/home/team/shared/cac_tracking_template.csv`.

