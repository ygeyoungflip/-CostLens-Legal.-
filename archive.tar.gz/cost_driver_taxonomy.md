# Cost Driver Taxonomy for Law Firms

This document provides a standardized categorization for law firm costs to enable better tracking, analysis, and reduction strategies.

## 1. Personnel Costs
Direct and indirect costs associated with the legal and support team.
*   **Attorneys (Partner/Associate):** Billable hours vs. cost to firm.
*   **Paralegals & Legal Assistants:** Support work for cases.
*   **Administrative Staff:** Management, HR, Finance.
*   **Contract/Temp Labor:** Project-based legal support.

## 2. Litigation & Case-Specific Costs
Direct expenses incurred during the lifecycle of a case.
*   **Discovery & E-Discovery:** Software licenses, data hosting, and document review costs.
*   **Expert Witnesses:** Fees for professional testimony and consultation.
*   **Filing Fees & Court Costs:** Mandatory payments to court systems.
*   **Research & Subscriptions:** Access to Westlaw, LexisNexis, etc.
*   **Travel & Meals:** Expenses related to depositions, trials, and client meetings.

## 3. Technology & Software
Infrastructure and tools used to manage the practice.
*   **Practice Management (PMS):** Clio, MyCase, etc.
*   **Document Management (DMS):** NetDocuments, iManage.
*   **Accounting & Billing:** Tools for financial management.
*   **IT Infrastructure:** Hardware, cloud hosting, security.

## 4. Marketing & Business Development
Costs associated with acquiring new clients (Critical for the 50 sign-up goal).
*   **Advertising:** PPC, Social Media, Print.
*   **Client Outreach:** Events, networking.
*   **Referral Fees:** Payments for incoming leads.

## 5. General Overhead
Fixed costs of running the business.
*   **Rent & Utilities:** Office space.
*   **Insurance:** Malpractice, Liability.
*   **Office Supplies:** Stationery, printing.

## 6. Case Type Classification (for Profitability Analysis)
Categorizing matters to identify which areas of practice are most/least profitable.
*   **Litigation (Civil/Criminal):** High discovery costs, expert-heavy.
*   **Corporate/M&A:** High partner drag, tight timelines.
*   **Intellectual Property (IP):** Filing-intensive, high research costs.
*   **Family Law:** High admin overhead, communication-heavy.
*   **Real Estate:** High volume, fixed-fee opportunities.

## 7. Automation & Efficiency Categories
Surfacing opportunities to reduce manual labor costs.
*   **Class A (Routine):** Conflict checks, intake forms, filing fees. (Target: 90% automation)
*   **Class B (Standardized):** Document drafting, simple motions, billing. (Target: 50% automation)
*   **Class C (Complex):** Legal research, strategy, trial prep. (Target: 15% automation)

---
**Top 3 Cost Drivers (Overall):**
1. Personnel (Attorneys & Support Staff)
2. Technology & Software Licensing
3. E-Discovery & Litigation Support

**Product Vision Drivers:**
*   **Case Profitability:** Measuring billable revenue vs. direct labor + expense costs.
*   **Team Velocity:** Measuring days to complete standard workflow stages (Bottleneck Detection).
