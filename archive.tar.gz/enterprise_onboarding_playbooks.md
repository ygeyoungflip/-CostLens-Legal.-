# Enterprise Onboarding Playbooks & Customer Success Workflows

## Tiered Onboarding + Proactive Retention for CostLens Legal

**Prepared by:** Operations Optimization Agent  
**Date:** May 22, 2026  
**Context:** 4 pricing tiers (Solo/Starter $1K → Growth $7K → Enterprise $10K → Ultra-Premium $100K–$500K). 2 firms onboarded (Gibson Dunn, Quinn Emanuel), 4 demos scheduled, 202 firms in pipeline. Goal: onboarding that drives rapid time-to-value and proactive retention.

---

## Part 1: Tiered Onboarding Playbooks

### Onboarding Principles (All Tiers)

| Principle | Description |
|-----------|-------------|
| **Time-to-value <7 days** | Every firm sees their first cost insight within 7 days of signing |
| **ROI-first onboarding** | Each milestone tied to a measurable outcome, not just feature completion |
| **Tier-appropriate depth** | Solo: maximum simplicity (30 min setup). Enterprise: maximum depth (dedicated team, custom integrations) |
| **Escalation path** | Every tier has a clear path to escalate issues or upgrade |
| **Data-driven handoff** | Sales → Onboarding → Customer Success — no dropped context between teams |

### Shared Onboarding Phases (All Tiers)

```
Signup → Welcome → Data Intake → Configuration → First Report → Go-Live → Ongoing CS
  0        1           2             3             4            5          6+
```

---

### Tier 1: Solo / Starter ($1,000/mo)

**Target:** Solo practitioners, 2–5 attorneys  
**Onboarding Lead:** Growth & Sales Lead  
**Onboarding Time:** 30 min setup call + self-serve  
**Time to First ROI Insight:** 3 days

#### Week 1: Setup & First Insight

| Day | Milestone | Owner | Actions | Success Criteria |
|-----|-----------|-------|---------|-----------------|
| **0** | Signup | Growth Lead | Send welcome email with verification link | Verification link clicked |
| **1** | Identity verified | Growth Lead | Complete Stripe Identity check | ✅ Badge awarded |
| **2** | Data intake | Growth Lead | Firm uploads CSV: case catalog (5+ cases), time entries, expenses | Data received |
| **3** | Baseline set | Cost Agent | Map firm task codes to Cost Driver Taxonomy; set efficiency baselines | Baselines configured |
| **4** | First report | Cost Agent | Auto-generate Top 3 Cost Drivers + benchmarking report | Report delivered |
| **5** | Go-live call | Growth Lead | 30-min screen share: walk through dashboard, explain first report, show 3 quick wins | Firm can navigate dashboard |
| **7** | ROI checkpoint | Growth Lead | Check: is firm logging in? Using alerts? Send quick feedback email | Login confirmed |

#### Onboarding Checklist
```
☐ Welcome email sent with verification link
☐ Identity verification completed
☐ Firm data uploaded (CSV minimum: cases, time, expenses)
☐ Cost Driver Taxonomy mapped to firm codes
☐ Efficiency baselines configured
☐ First Top 3 Cost Drivers report delivered
☐ Dashboard walkthrough completed (30 min)
☐ 3 quick wins identified and communicated
☐ Early alert thresholds configured
☐ Support email shared
```

#### Success Milestones
- ✅ **Day 3:** First cost insight identified
- ✅ **Day 7:** 3 quick wins communicated
- ✅ **Day 30:** 1 actionable cost reduction identified
- ✅ **Day 90:** 15% cost reduction target on 1 case (goal)

#### Standard Email Templates

**Day 0 — Welcome + Verification:**
```
Subject: Welcome to CostLens Legal — Let's Get You Set Up

Hi {{name}},

Welcome to CostLens Legal! We're excited to have {{firm_name}} onboard.

Here's your 7-day plan:
Day 1: Complete identity verification (5 min)
Day 2: Upload your case data (CSV template attached)
Day 3: Receive your first Cost Driver Analysis

[Start Verification →]

Questions? We're here: support@costlens.legal

Best,
The CostLens Team
```

**Day 5 — First Report Delivered:**
```
Subject: Your First Cost Driver Analysis is Ready

Hi {{name}},

Your first Cost Driver Analysis is ready. Here's what we found:

📊 Top 3 Cost Drivers for {{firm_name}}:
1. [Driver 1] — {{pct_1}}% of costs
2. [Driver 2] — {{pct_2}}% of costs
3. [Driver 3] — {{pct_3}}% of costs

📈 Industry Benchmark: [Compare]

⚡ 3 Quick Wins:
1. [Quick win 1]
2. [Quick win 2]
3. [Quick win 3]

[View Full Report →]

Let's schedule a 15-min call to walk through it.
```

---

### Tier 2: Growth / Mid-Size ($7,000/mo)

**Target:** 6–50 attorneys, growing firms  
**Onboarding Lead:** Operations Optimization Agent (primary) + Cost Agent (data)  
**Onboarding Time:** 60-min strategy session + guided setup  
**Time to First ROI Insight:** 5 days

#### Week 1–2: Strategic Setup

| Day | Milestone | Owner | Actions | Success Criteria |
|-----|-----------|-------|---------|-----------------|
| **0** | Signup + welcome | Growth Lead | Welcome call scheduled; send data intake package | Call scheduled |
| **1** | Strategy session (60 min) | Ops Agent + Cost Agent | Identify top 3 firm objectives; map practice areas; assign ded. account manager | Session completed |
| **2** | Verification + data intake | Ops Agent + Cost Agent | Full verification (identity + business + insurance + AML); firm uploads all case data (20+ cases) | All checks passed |
| **3–4** | Configuration | Cost Agent + Ops Agent | Taxonomy mapping; efficiency benchmarks; profitability by case type; bottleneck thresholds | Dashboard configured |
| **5** | First Analysis Report | Cost Agent | Top 3 Cost Drivers + Profitability Audit + Bottleneck Detection + Efficiency Comparison | Report delivered |
| **7** | Go-live review (60 min) | Ops Agent | Walk through full dashboard: cost drivers, profitability, bottlenecks, efficiency comparison, alerts | Firm can navigate + interpret |
| **10** | Early alert tuning | Ops Agent | Adjust alert thresholds based on first week of data; configure notification preferences | Alerts configured |
| **14** | ROI checkpoint call | Ops Agent | Review first 2 weeks of data; identify 3–5 immediate cost reduction actions | 3 actions identified |

#### Onboarding Checklist
```
☐ Welcome call scheduled and completed
☐ Strategy session completed (60 min)
☐ Full verification completed (identity + business + insurance + AML)
☐ Case data uploaded (20+ cases minimum)
☐ Taxonomy mapped to firm task codes
☐ Efficiency benchmarks set
☐ Profitability by case type configured
☐ Bottleneck thresholds set (see workflow_bottleneck_framework.md)
☐ First Analysis Report delivered
☐ Full dashboard walkthrough (60 min)
☐ Early alert thresholds tuned
☐ 3–5 immediate cost reduction actions identified
☐ Dedicated account manager assigned
```

#### Success Milestones
- ✅ **Day 7:** Full dashboard operational
- ✅ **Day 14:** 3–5 cost reduction actions identified
- ✅ **Day 30:** 1 cost reduction implemented, savings tracked
- ✅ **Day 60:** 10% admin overhead reduction (billing/admin tasks automated)
- ✅ **Day 90:** 15% case cost reduction achieved on at least 2 cases

---

### Tier 3: Enterprise / Large ($10,000/mo)

**Target:** 51–200 attorneys, established firms  
**Onboarding Lead:** Operations Optimization Agent + Dedicated Implementation Team  
**Onboarding Time:** 2–3 weeks guided implementation  
**Time to First ROI Insight:** 10 days

#### Week 1–3: Full Implementation

| Week | Milestone | Owner | Actions | Success Criteria |
|------|-----------|-------|---------|-----------------|
| **W1 M** | Kickoff call (90 min) | Ops Agent + Cost Agent + Growth Lead | Executive sponsor identified; project plan shared; success criteria defined; data access arranged | Kickoff completed |
| **W1 W** | Full verification | Ops Agent + Web-Dev | Identity, business, insurance, AML for firm + key partners; verification badge assigned | All verified |
| **W1 F** | Data migration | Cost Agent + Ops Agent | Bulk import: 100+ cases, all time entries, expenses, vendor data; API integration scoped | Data loaded |
| **W2 M** | Platform configuration | Ops Agent + Cost Agent | Taxonomy; benchmarks; profitability models; bottleneck thresholds; compliance reporting; document management setup | Full config |
| **W2 W** | Integrations | Web-Dev | PMS API integration (if available); SSO setup (Okta/Azure AD); custom branding | Integrations live |
| **W2 F** | Admin training (2 sessions) | Ops Agent | Session 1: Firm admins — dashboard, reports, user management, RBAC (60 min). Session 2: All attorneys — day-to-day usage, alerts, reporting (60 min) | Training complete |
| **W3 M** | First Report + Review | Cost Agent | Full analysis delivered: cost drivers, profitability per case/attorney, benchmarks, bottlenecks, automation opportunities, compliance summary | Report delivered |
| **W3 W** | Executive review (60 min) | Ops Agent + Cost Agent | Present findings to firm leadership; agree on 5 priority actions; set ROI targets for Q1 | Leadership aligned |
| **W3 F** | Go-live | All | System live; integrations active; support escalation paths defined; SLA confirmed | Go-live declared |

#### Onboarding Checklist
```
☐ Executive kickoff completed (90 min)
☐ Full verification for firm + key partners
☐ Bulk data import (100+ cases)
☐ API integration scoped and in progress
☐ SSO configured
☐ Custom branding applied
☐ Admin training session 1 completed
☐ All-attorney training session 2 completed
☐ Full analysis report delivered
☐ Executive review completed
☐ 5 priority actions defined
☐ Support escalation paths documented
☐ SLA confirmed
☐ Document management system configured
☐ Compliance reporting configured
```

#### Success Milestones
- ✅ **Week 2:** All data imported + integrations live
- ✅ **Week 3:** Executive review completed, 5 actions in motion
- ✅ **Month 2:** First cost savings realized and tracked
- ✅ **Month 3:** Compliance reports automated + first QBR completed
- ✅ **Quarter 2:** Full ROI verified against baseline

#### Enterprise Escalation Path
```
Issue Detection → Tier 1 Support (within 30 min) 
    → Tier 2 (within 2 hours if unresolved)
    → Dedicated CS Manager (within 4 hours)
    → Ops Agent (urgent)
    → Managing Partner escalation (if SLA breached)
```

---

### Tier 4: Ultra-Premium ($100K–$500K/mo)

**Target:** 200+ attorneys, AmLaw 100  
**Onboarding Lead:** Operations Optimization Agent + Dedicated Enterprise Team  
**Onboarding Time:** 4–6 weeks, white-glove  
**Time to First ROI Insight:** 14 days

#### Month 1: Strategic Partnership Onboarding

| Week | Milestone | Owner |
|------|-----------|-------|
| **Pre** | Executive briefing — scope, custom SLAs, success criteria | Ops Agent + Cost Agent + Growth Lead |
| **1** | Full platform deployment (verification, DMS, compliance, drafting, billing) | Full team |
| **2** | Custom integration development (PMS, ERP, SSO, data warehouse) | Web-Dev |
| **3** | Firm-wide training (role-based: admin, partner, associate, paralegal, client) | Ops Agent |
| **4** | Executive ROI presentation + QBR cadence setup | Ops Agent + Cost Agent |
| **6** | Full go-live + ongoing CS transition | All |

#### Deliverables (Unique to Ultra-Premium)
- Custom dashboard with firm branding
- Dedicated Slack/Teams channel with CostLens team
- Monthly executive QBRs
- Custom SLA with uptime guarantees
- Priority feature requests (90-day turnaround)
- On-site training for key stakeholders

#### Success Milestones
- ✅ **Month 1:** Full platform live with custom integrations
- ✅ **Month 2:** First measurable ROI delivered
- ✅ **Quarter 1:** $500K+ in identified savings
- ✅ **Quarter 2:** Full compliance automation operational
- ✅ **Annual:** Multi-million dollar cost intelligence partnership

---

## Part 2: Customer Success Workflows

### 2.1 Proactive Touchpoint Schedule

| Timing | Touchpoint | Tier | Owner | Content | Trigger |
|--------|-----------|------|-------|--------|---------|
| **Day 7** | First ROI Check-in | All | Ops Agent / Growth Lead | "How's it going? 3 quick wins identified?" | Auto-triggered 7 days post go-live |
| **Day 30** | 30-Day Success Review | All | Ops Agent / Growth Lead | First cost savings tracked? Dashboard adoption? | Auto-triggered 30 days post go-live |
| **Day 60** | 60-Day Optimization | Growth+ | Ops Agent | Bottleneck review; automation recommendations; alert tuning | Auto-triggered |
| **Day 90** | Quarter 1 Business Review | All | Ops Agent + Cost Agent | Full ROI analysis; benchmark refresh; Q2 action plan | Quarterly |
| **Day 180** | Half-Year Strategic Review | Enterprise+ | Ops Agent + Cost Agent | Expansion roadmap; upgrade assessment; integration roadmap | Semi-annual |
| **Annual** | Annual Partnership Review | Ultra-Premium | Full team | Strategic partnership review; custom roadmap; SLA refresh | Annual |

### 2.2 Customer Health Scoring Model

#### Score Components

| Component | Weight | Source | Scoring Logic |
|-----------|--------|--------|---------------|
| **Login frequency** | 25% | Platform analytics | Daily=100, Weekly=75, Biweekly=50, Monthly=25, Never=0 |
| **Feature adoption** | 25% | Feature usage logs | % of assigned features used / total available (per tier) |
| **Data freshness** | 20% | Last data upload date | <7 days=100, 7–30=75, 30–60=50, 60–90=25, >90=0 |
| **Support interactions** | 15% | Support ticket system | No tickets=100, 1–3 resolved=75, >3 open=25, Escalated=0 |
| **ROI realization** | 15% | Cost tracking dashboard | >15% savings=100, 5–15%=75, 0–5%=50, Negative=0 |

#### Health Score Tiers

| Score | Classification | Action Required |
|-------|---------------|----------------|
| **80–100** | 🟢 Healthy | Monitor — Quarterly check-in only |
| **50–79** | 🟡 At Risk | Proactive outreach within 7 days — identify blockers |
| **25–49** | 🟠 Critical | Immediate outreach within 24 hours — escalation to Ops Agent |
| **0–24** | 🔴 Churning | Executive intervention — account review, potential discount, root cause analysis |

#### Health Score Calculation
```
HEALTH = (LOGIN × 0.25) + (FEATURES × 0.25) + (FRESHNESS × 0.20) 
       + (SUPPORT × 0.15) + (ROI × 0.15)
```

### 2.3 Escalation Triggers

| Trigger | Condition | Action | Response Time | Escalates To |
|---------|-----------|--------|---------------|-------------|
| **Low login** | No login >14 days | Send re-engagement email with new insight | 24 hours | Growth Lead |
| **No login** | No login >30 days | Personal call from account manager | 48 hours | Ops Agent |
| **Feature drop-off** | Feature usage drops >50% in 30 days | Proactive training session offer | 48 hours | Ops Agent |
| **Data staleness** | No data upload >60 days | Data refresh campaign + call | 48 hours | Cost Agent |
| **Support spike** | >5 unresolved tickets | Account review + escalation | 24 hours | Ops Agent |
| **Negative ROI** | Costs increased >5% since baseline | Full cost audit + remediation plan | Immediate | Ops Agent + Cost Agent |
| **Churn signal** | Firm mentions leaving | Executive outreach + retention offer | Immediate | Growth Lead + Ops Agent |
| **Billing issue** | Payment failure or downgrade request | Resolve billing → understand reason | 4 hours | FinOps Agent |

### 2.4 Quarterly Business Review (QBR) Framework

#### QBR Agenda (60 min)

```
┌────────────────────────────────────────────────────────────┐
│ QBR: {firm_name} — Q{quarter} {year}                      │
├────────────────────────────────────────────────────────────┤
│ 1. Executive Summary (5 min)                               │
│    - ROI-to-date vs. baseline                              │
│    - Top accomplishments                                  │
│                                                            │
│ 2. Cost Performance Review (15 min)                        │
│    - Case cost trend (quarter over quarter)               │
│    - Top 3 cost drivers — are they improving?              │
│    - Discovery cost analysis                               │
│    - Industry benchmark comparison                         │
│                                                            │
│ 3. Operational Efficiency (10 min)                         │
│    - Admin-to-billable ratio trend                         │
│    - Billing cycle improvements (DSO)                     │
│    - Bottleneck resolution status                         │
│                                                            │
│ 4. Automation & ROI (10 min)                               │
│    - Automation opportunities identified → implemented    │
│    - Hours reclaimed                                       │
│    - Software cost savings (if tracked)                    │
│                                                            │
│ 5. Next Quarter Plan (15 min)                              │
│    - Priority initiatives                                 │
│    - Feature adoption goals                               │
│    - Upgrade opportunities (if applicable)                │
│    - Q2 targets and success criteria                      │
│                                                            │
│ 6. Open Discussion (5 min)                                 │
│    - Feedback                                              │
│    - Feature requests                                      │
│    - Concerns                                              │
└────────────────────────────────────────────────────────────┘
```

#### QBR Preparation Checklist
```
☐ Pull cost performance data (quarter over quarter)
☐ Update industry benchmarks
☐ Calculate admin-to-billable ratio change
☐ Update DSO trend
☐ Identify top 3 automation wins
☐ Prepare next-quarter action plan
☐ Identify expansion/upgrade opportunities
☐ Send QBR deck to firm 48 hours in advance
```

### 2.5 Churn Prevention Playbook

#### Early Warning Signs
| Signal | Severity | Lead Time | Intervention |
|--------|----------|-----------|-------------|
| Login frequency drops >50% | 🟡 Medium | 2–4 weeks | Re-engagement email + personal check-in |
| No data upload >60 days | 🟠 High | 4–8 weeks | Data refresh campaign + ROI re-demonstration |
| Support tickets spike + negative sentiment | 🟠 High | 1–3 weeks | Account review + executive outreach |
| Feature usage drops to <30% | 🟡 Medium | 2–4 weeks | Retraining + new feature showcase |
| Unprompted feedback about competitors | 🔴 Critical | 1–2 weeks | Competitive differentiation discussion + value re-demonstration |
| Billing downgrade or non-payment | 🔴 Critical | Immediate | Financial review + retention offer |

#### Churn Intervention Flow
```
Churn Signal Detected
         │
    ┌────▼────┐
    │ Health  │
    │ Score?  │
    ├── 50–79 ──→ Proactive outreach (7 days)
    ├── 25–49 ──→ Immediate call + action plan (24 hours)
    └── 0–24 ──→ Executive intervention + retention offer (immediate)
         │
         ▼
    ┌────────────┐
    │ Root Cause │
    │ Analysis   │
    ├── Not seeing ROI ────→ Re-demonstrate value + adjust metrics
    ├── Too complex ───────→ Simplify + retrain
    ├── Competitor ────────→ Differentiate + offer discount/incentive
    └── Budget cut ────────→ Downgrade tier + stay engaged
         │
         ▼
    ┌────────────┐
    │ Outcome    │
    ├── Retained ──────────→ Strengthened engagement plan
    └── Lost ──────────────→ Exit interview + learn + re-engage in 6 months
```

### 2.6 Tier Upgrade Paths

| Current Tier | Upgrade Path | Trigger Signals | Upgrade Process |
|-------------|-------------|----------------|-----------------|
| **Solo → Growth** | $1K → $7K/mo | Firm adds 3+ attorneys; outgrowing basic reports; asking for profitability by case type | Upgrade call + new feature training + new report setup |
| **Growth → Enterprise** | $7K → $10K/mo | Firm needs compliance reporting; document management; API access; verification for partners | Executive review + full security assessment + custom integration |
| **Enterprise → Ultra-Premium** | $10K → $100K+/mo | Firm is AmLaw 100/200; needs white-glove service; custom SLAs; firm-wide deployment | Partnership proposal + executive briefing + 4-week onboarding |

#### Upgrade Timing Recommendations

| Scenario | Timing | Approach |
|----------|--------|----------|
| **Natural expansion** (firm growing) | At QBR | Present data showing ROI from X tier would exceed cost |
| **Feature need** (firm needs specific feature) | Within 30 days of request | Offer 14-day trial of higher tier feature |
| **Usage threshold** (firm hitting tier limits) | Immediate | Proactive outreach before firm feels friction |
| **Annual renewal** | At renewal | Bundle upgrade with renewal for pricing incentive |

### 2.7 Success Metrics & KPIs

| KPI | Target | Measurement |
|-----|--------|-------------|
| **Time to first value** | <7 days (Solo), <14 days (Enterprise) | Signup → first report delivered |
| **Onboarding completion rate** | >90% | Started vs. completed onboarding |
| **30-day activation rate** | >80% | Firms logging in at least 5x in first 30 days |
| **90-day retention** | >95% | Firms still active at 90 days |
| **Net Revenue Retention (NRR)** | >120% | Revenue from existing firms including upgrades |
| **Customer Health Score (avg)** | >75 | Composite health score across all firms |
| **QBR completion rate** | 100% for Enterprise+ | Scheduled vs. completed QBRs |
| **Churn rate** | <5% annually | Firms canceling / total firms |
| **Net Promoter Score (NPS)** | >50 | Survey at 30/90/365 days |
| **Time to resolve escalation** | <24 hours (critical), <72 hours (high) | Ticket open → resolved |

---

## 3. Cross-Team Coordination

| Teammate | Role in Onboarding & CS | Deliverables |
|----------|------------------------|--------------|
| **Growth & Sales Lead** | Warm handoff from Sales → Onboarding; manages Solo tier onboarding; runs upgrade campaigns | Welcome emails, checklist tracking, upgrade proposals |
| **Cost Agent** | Data intake, taxonomy mapping, benchmark configuration, first analysis report, quarterly benchmarking refresh | Cost baselines, profitability models, trend analysis |
| **Ops Agent** | Enterprise onboarding lead; customer success workflows; QBR facilitation; retention intervention | Onboarding playbooks, health score tracking, escalation management |
| **FinOps Agent** | Billing setup, invoicing, payment reconciliation; software cost tracking for firms | Billing integration, software spend monitoring |
| **Web-Dev** | Technical setup: verification, DMS, integrations, SSO, custom branding | Integrations, custom configuration |

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Builds on: Pricing Model, Client Onboarding Framework, Verification Workflow Design, Retention & Scaling Playbook*