# CostLens Legal — FinOps Dashboard Template (Licensing Cost Control)

**Date:** May 20, 2026  
**Audience:** Leadership, Finance, Operations, Cost Analytics  
**Purpose:** Track software licensing spend, utilization, and ROI realization against cost-reduction targets.

---

## 1) Dashboard Objectives

1. Monitor progress toward **>=10% software licensing reduction**.
2. Detect underutilized licenses early.
3. Track realized vs planned savings by initiative.
4. Tie savings to ROI and payback metrics.

---

## 2) KPI Layout (Recommended)

### A. Executive Tiles (Top Row)
- **Total Annualized License Spend**
- **Savings Realized YTD**
- **Savings % vs Baseline**
- **Net ROI (portfolio view)**
- **Average Payback Period (months)**

### B. Spend Composition (Row 2)
- Spend by vendor (stacked bar)
- Spend by capability category (pie/treemap)
- Trend line: monthly spend vs baseline

### C. Utilization & Waste (Row 3)
- Paid seats vs active seats by tool
- Utilization % by tool (last 30/60/90 days)
- Idle-seat cost heatmap

### D. Initiative Tracker (Row 4)
- Initiative status: planned / pilot / scaling / complete
- Planned savings vs realized savings
- Implementation cost vs budget
- Payback status (on-track / at-risk)

### E. Risk & Exception Monitor (Row 5)
- Dual-stack exceptions count
- Upcoming renewals (next 120 days)
- Contracts lacking flex-down clauses

---

## 3) Data Model (Minimum Tables)

### `license_inventory`
| Field | Type | Description |
|---|---|---|
| snapshot_date | date | Observation date |
| vendor | text | Vendor name |
| product | text | SKU/product |
| capability | text | Category (meetings, e-sign, etc.) |
| seats_purchased | integer | Paid seats |
| seats_active_30d | integer | Active seats over 30 days |
| annual_cost_usd | numeric | Annualized cost |
| contract_end_date | date | Renewal date |

### `initiative_roi`
| Field | Type | Description |
|---|---|---|
| initiative_id | text | Initiative identifier |
| initiative_name | text | Initiative title |
| owner | text | Accountable lead |
| baseline_cost_usd | numeric | Baseline annual cost |
| expected_savings_usd | numeric | Planned annual savings |
| realized_savings_usd | numeric | Actual annualized savings |
| implementation_cost_usd | numeric | One-time cost |
| ongoing_cost_usd | numeric | Ongoing incremental cost |
| payback_months | numeric | Calculated payback |
| net_roi_pct | numeric | Calculated ROI |
| status | text | planned/pilot/scaling/complete |

### `renewal_pipeline`
| Field | Type | Description |
|---|---|---|
| vendor | text | Vendor name |
| product | text | Product/SKU |
| renewal_date | date | Contract end |
| current_cost_usd | numeric | Current annual cost |
| owner | text | Negotiation owner |
| leverage_status | text | benchmarked / quoted / negotiated |

---

## 4) Core Calculated Metrics

1. **Utilization %** = `seats_active_30d / seats_purchased`
2. **Idle Seat Cost** = `annual_cost_usd * (1 - utilization%)`
3. **Savings % vs Baseline** = `realized_savings / baseline_spend`
4. **Net Savings** = `realized_savings - implementation_cost - ongoing_cost`
5. **Portfolio ROI %** = `(sum(year1_net_benefit) / sum(implementation_cost)) * 100`

---

## 5) Operating Cadence

- **Weekly:** utilization anomalies, idle seat review, renewal flags
- **Monthly:** executive savings review and initiative ROI refresh
- **Quarterly:** vendor strategy + consolidation scorecard + reforecast

---

## 6) Dashboard Filters

- Date range
- Vendor
- Capability category
- Practice group/team
- Initiative status
- Confidence level (High/Medium/Low)

---

## 7) Definition of Done for FinOps Reporting

Dashboard is “production-ready” when:
- Baseline spend is locked from invoice data
- All active initiatives have ROI scorecards
- Realized savings are reconciled with finance
- Renewal risk view covers next 2 quarters

---

## 8) Expansion Modules (Underused Resources + CAC)

### Module A: Underused Resource Monitor
- Underused license cost (annualized)
- Idle seat count by tool
- Retainer utilization and waste value
- Reclaimed capacity value (validated)

### Module B: Client Acquisition Economics
- Blended CAC (fully loaded)
- CAC by channel (outbound/referral/partnership/paid)
- CAC payback months
- LTV:CAC ratio
- Onboarding cost per signed firm

### New datasets to add
- `underused_resources`
- `acquisition_economics`

