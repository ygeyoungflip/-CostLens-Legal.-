# CostLens Legal — Billing Stripe Integration (CTO Fee Model)

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Spec:** `/home/team/shared/platform_expansion_v2.md` (Billing & Payments + Payment Flow)

---

## 1) Architecture Decision

Use **Stripe Connect destination charges** for marketplace-style split billing.

- Charge customer via Stripe Checkout / Billing
- Set `application_fee_amount = 10%` of transaction
- Send service proceeds to law-firm connected account
- Keep application fee in platform Stripe balance
- Run automated payout/sweep to CTO Stripe account on schedule

### Why this pattern
- Native Stripe fee-split support
- Clear ledger separation between customer charge, firm proceeds, and platform fee
- Compatible with subscriptions + one-time invoices

**Primary references:**
- Destination charges: https://docs.stripe.com/connect/destination-charges  
- Connect charge flows: https://docs.stripe.com/connect/charges  
- Billing webhooks: https://docs.stripe.com/billing/subscriptions/webhooks

---

## 2) Payment Flow

## 2.1 Subscription billing flow
1. Firm/admin selects plan (Stripe Billing)
2. Platform creates charge intent/session with:
   - `transfer_data[destination] = connected_account_id`
   - `application_fee_amount = round(gross * 0.10)`
3. Stripe captures payment
4. Accounting records:
   - Gross charge
   - 10% platform fee
   - Firm net share (before policy on processor fee handling)
5. Webhooks trigger invoicing, status updates, and notifications
6. Fee sweep job transfers platform-fee proceeds to CTO Stripe account

## 2.2 One-time invoice flow
Same split logic; can use Hosted Invoice Page or Checkout for ad hoc charges.

---

## 3) 10% Platform Fee Logic

- `gross_amount = invoice_or_checkout_total`
- `platform_fee = round(gross_amount * 0.10)`
- `firm_share_pre_adjustment = gross_amount - platform_fee`

### Sample values
| Gross | Platform Fee (10%) | Firm Share |
|---:|---:|---:|
| $100 | $10 | $90 |
| $1,000 | $100 | $900 |
| $5,000 | $500 | $4,500 |

---

## 4) Automated Invoicing

Enable Stripe Billing with:
- Recurring invoices per subscription cycle
- Tax/VAT settings per account jurisdiction (if needed)
- Retry rules (smart retries for failed payments)
- PDF invoice generation and storage of invoice IDs in internal ledger

Webhook triggers for invoicing lifecycle:
- `invoice.created`
- `invoice.finalized`
- `invoice.paid`
- `invoice.payment_failed`

---

## 5) Reconciliation Design

## Minimum ledger tables
### `billing_transactions`
- stripe_invoice_id / payment_intent_id / charge_id
- firm_id
- gross_amount
- platform_fee_amount
- firm_share_amount
- currency
- status
- event_timestamp

### `fee_payouts`
- payout_batch_date
- platform_fee_collected
- reserve_holdback
- amount_transferred_to_cto
- stripe_transfer_id
- payout_status

### `reconciliation_exceptions`
- record_id
- mismatch_type
- expected_value
- actual_value
- resolved_by
- resolved_at

## Reconciliation cadence
- Daily auto-recon: Stripe balance transactions vs internal ledger
- Weekly finance review: unresolved exceptions + dispute reserve
- Month-end close: gross / fee / net certified summary

---

## 6) Payout Scheduling (CTO Routing)

Recommended schedule:
- **Daily sweep at 02:00 UTC** to CTO account, with reserve buffer
- Reserve holdback: 10–15% of recent fee intake for refund/dispute volatility
- Weekly true-up every Friday to release excess reserve

Alternative:
- Weekly payout only (lower ops load, slower cash realization)

---

## 7) Refunds / Disputes / Edge Cases

1. Refund issued -> adjust platform fee and firm share based on refund policy
2. Dispute opened -> lock additional reserve, suspend payout of disputed amount
3. Insufficient platform balance -> defer CTO sweep and mark exception
4. Duplicate webhook delivery -> idempotent event processing required

---

## 8) Security Controls

- Verify Stripe webhook signature for every event
- Store webhook payload hash and processing status
- Use restricted API keys and rotation policy
- Full audit trail for fee calculations and transfers

---

## 9) Implementation Estimate

| Workstream | Hours |
|---|---:|
| Connect + fee split setup | 20 |
| Subscription + invoice automation | 18 |
| Reconciliation ledger + jobs | 24 |
| CTO payout scheduler + reserves | 16 |
| Refund/dispute handling + QA | 20 |
| **Total** | **98 hrs** |

At $120/hr blended rate: **~$11,760 one-time**.

---

## 10) Acceptance Criteria

- Every billable transaction applies 10% fee correctly
- CTO account receives scheduled fee payouts with reserve protection
- Automated invoices and reconciliation run without manual intervention
- Refund/dispute flows update ledgers and payouts correctly
- Finance can export auditable monthly gross/fee/net reports

