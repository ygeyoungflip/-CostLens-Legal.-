# Enterprise Onboarding Playbooks — Tiered Onboarding Flows

## CostLens Legal — From Signed Contract to Measurable ROI

**Prepared by:** Operations Optimization Agent  
**Date:** May 27, 2026  
**Context:** 4 pricing tiers based on Pricing Model. Goal: time-to-value <7 days (Solo), <14 days (Enterprise).

---

## Onboarding Principles (All Tiers)

| Principle | Description |
|-----------|-------------|
| **Time-to-value <7 days** | Every firm sees their first cost insight within 7 days of signing |
| **ROI-first onboarding** | Each milestone tied to a measurable outcome, not just feature completion |
| **Tier-appropriate depth** | Solo: maximum simplicity. Enterprise: maximum depth with dedicated team |
| **Escalation path** | Every tier has clear path to escalate issues or upgrade |
| **Data-driven handoff** | Sales → Onboarding → Customer Success — no dropped context |

### Shared Phases (All Tiers)
```
Signup → Welcome → Data Intake → Configuration → First Report → Go-Live → Ongoing CS
  0        1           2             3             4            5          6+
```

---

## Tier 1: Solo / Starter ($1,000/mo)

**Target:** Solo practitioners, 2–5 attorneys  
**Onboarding Lead:** Growth & Sales Lead  
**Onboarding Time:** 30-min setup call + self-serve wizard  
**Time to First ROI Insight:** 3 days

### Week 1 Timeline

| Day | Milestone | Owner | Actions | Success Criteria |
|-----|-----------|-------|---------|-----------------|
| **0** | Signup | Growth Lead | Send welcome email with verification link | Link clicked |
| **1** | Identity verified | Growth Lead | Complete Stripe Identity check | ✅ Badge awarded |
| **2** | Data intake | Growth Lead | Firm uploads CSV via self-serve wizard (5+ cases, time, expenses) | Data received |
| **3** | Baseline + First Report | Cost Agent | Auto-generate Top 3 Cost Drivers + benchmarking report | Report delivered |
| **4** | Go-live call (30 min) | Growth Lead | Screen share: dashboard walkthrough, first report, 3 quick wins | Firm can navigate |
| **7** | ROI checkpoint | Growth Lead | Check login activity; send feedback email | Login confirmed |

### Onboarding Checklist
```
☐ Welcome email sent with verification link
☐ Identity verification completed
☐ Firm data uploaded via self-serve wizard
☐ Cost Driver Taxonomy mapped
☐ Efficiency baselines configured
☐ First Top 3 Cost Drivers report delivered
☐ Dashboard walkthrough completed (30 min)
☐ 3 quick wins identified and communicated
☐ Early alert thresholds configured
☐ Support email shared (support@costlens.legal)
```

### Success Milestones
- ✅ **Day 3:** First cost insight identified
- ✅ **Day 7:** 3 quick wins communicated
- ✅ **Day 30:** 1 actionable cost reduction identified
- ✅ **Day 90:** 15% cost reduction on at least 1 case

### Handoff Criteria (Sales → Onboarding → CS)
| Stage | From | To | Trigger | Data Passed |
|-------|------|----|---------|-------------|
| Sales → Onboarding | Growth Lead | Self-serve wizard | Signup form completed | Name, email, firm, size, practice area |
| Onboarding → CS | Self-serve | Ops Agent (monitoring) | Go-live call completed | Verification status, first report, health score |

### Welcome Email Template
```
Subject: Welcome to CostLens Legal — Let's Get You Set Up

Hi {{name}},

Welcome! Here's your 7-day plan:
Day 1: Complete identity verification (5 min)
Day 2: Upload your case data (CSV template attached)
Day 3: Receive your first Cost Driver Analysis

[Start Verification →]

Questions? support@costlens.legal

Best,
The CostLens Team
```

---

## Tier 2: Growth / Mid-Size ($7,000/mo)

**Target:** 6–50 attorneys, growing firms  
**Onboarding Lead:** Operations Optimization Agent (primary) + Cost Agent (data)  
**Onboarding Time:** 60-min strategy session + guided setup  
**Time to First ROI Insight:** 5 days

### Week 1–2 Timeline

| Day | Milestone | Owner | Actions | Success Criteria |
|-----|-----------|-------|---------|-----------------|
| **0** | Signup + welcome | Growth Lead | Welcome call scheduled; send data intake package | Call scheduled |
| **1** | Strategy session (60 min) | Ops Agent + Cost Agent | Identify top 3 firm objectives; map practice areas; assign dedicated AM | Session completed |
| **2** | Verification + data intake | Ops Agent + Cost Agent | Full verification (identity + business + insurance + AML); firm uploads 20+ cases | All checks passed |
| **3–4** | Configuration | Cost Agent + Ops Agent | Taxonomy mapping; efficiency benchmarks; profitability by case type; bottleneck thresholds | Dashboard configured |
| **5** | First Analysis Report | Cost Agent | Top 3 Cost Drivers + Profitability Audit + Bottleneck Detection + Efficiency Comparison | Report delivered |
| **7** | Go-live review (60 min) | Ops Agent | Walk through full dashboard: cost drivers, profitability, bottlenecks, efficiency comparison, alerts | Firm can navigate + interpret |
| **10** | Early alert tuning | Ops Agent | Adjust thresholds based on first week data; configure notifications | Alerts configured |
| **14** | ROI checkpoint call | Ops Agent | Review first 2 weeks; identify 3–5 immediate cost reduction actions | 3 actions identified |

### Onboarding Checklist
```
☐ Welcome call scheduled and completed
☐ Strategy session completed (60 min)
☐ Full verification (identity + business + insurance + AML)
☐ Case data uploaded (20+ cases)
☐ Taxonomy mapped to firm task codes
☐ Efficiency benchmarks set
☐ Profitability by case type configured
☐ Bottleneck thresholds configured
☐ First Analysis Report delivered
☐ Full dashboard walkthrough (60 min)
☐ Early alert thresholds tuned
☐ 3–5 immediate cost reduction actions identified
☐ Dedicated account manager assigned
```

### Success Milestones
- ✅ **Day 7:** Full dashboard operational
- ✅ **Day 14:** 3–5 cost reduction actions identified
- ✅ **Day 30:** 1 cost reduction implemented, savings tracked
- ✅ **Day 60:** 10% admin overhead reduction
- ✅ **Day 90:** 15% case cost reduction on ≥2 cases

### Handoff Criteria
| Stage | From | To | Trigger | Data Passed |
|-------|------|----|---------|-------------|
| Sales → Onboarding | Growth Lead | Ops Agent | Contract signed + welcome call done | Full pipeline data + firm objectives |
| Onboarding → CS | Ops Agent | Health Score Monitor | Go-live review completed | Dashboard config, alerts, first report |

### Team Training Session (60 min)
```
Session: CostLens Legal — Day-to-Day Usage
Agenda:
1. Dashboard navigation + alerts (15 min)
2. Running reports + benchmarking (10 min)
3. Bottleneck detection walkthrough (10 min)
4. Automation recommendations (10 min)
5. Q&A (15 min)
```

---

## Tier 3: Enterprise / Large ($10,000/mo)

**Target:** 51–200 attorneys, established firms  
**Onboarding Lead:** Operations Optimization Agent + Dedicated Implementation Team  
**Onboarding Time:** 2–3 weeks guided implementation  
**Time to First ROI Insight:** 10 days

### Week 1–3 Timeline

| Week | Day | Milestone | Owner | Actions | Success Criteria |
|------|-----|-----------|-------|---------|-----------------|
| **W1** | Mon | Kickoff call (90 min) | Ops Agent + Cost Agent + Growth Lead | Executive sponsor ID'd; project plan shared; success criteria defined; data access arranged | Kickoff completed |
| **W1** | Wed | Full verification | Ops Agent + Web-Dev | Identity, business, insurance, AML for firm + key partners | All verified |
| **W1** | Fri | Data migration | Cost Agent + Ops Agent | Bulk import: 100+ cases, all time entries + expenses + vendor data; API integration scoped | Data loaded |
| **W2** | Mon | Platform configuration | Ops Agent + Cost Agent | Taxonomy, benchmarks, profitability models, bottleneck thresholds, compliance reports, DMS setup | Full config |
| **W2** | Wed | Integrations | Web-Dev | PMS API integration (if available); SSO setup (Okta/Azure AD); custom branding | Integrations live |
| **W2** | Fri | Admin training (2 sessions) | Ops Agent | Session 1: Admins — dashboard, reports, user management, RBAC (60 min). Session 2: All attorneys — day-to-day usage (60 min) | Training complete |
| **W3** | Mon | First Report + Review | Cost Agent | Full analysis: cost drivers, profitability per case/attorney, benchmarks, bottlenecks, automation opportunities, compliance summary | Report delivered |
| **W3** | Wed | Executive review (60 min) | Ops Agent + Cost Agent | Present findings to firm leadership; agree on 5 priority actions; set ROI targets | Leadership aligned |
| **W3** | Fri | **Go-Live** | All | System live; integrations active; support escalation paths defined; SLA confirmed | Go-live declared |

### Onboarding Checklist
```
☐ Executive kickoff completed (90 min)
☐ Full verification for firm + key partners
☐ Bulk data import (100+ cases)
☐ API integration scoped and in progress
☐ SSO configured (Okta/Azure AD)
☐ Custom branding applied
☐ Admin training session 1 completed
☐ All-attorney training session 2 completed
☐ Full analysis report delivered
☐ Executive review completed
☐ 5 priority actions defined and agreed
☐ Support escalation paths documented
☐ SLA confirmed
☐ Document management system configured
☐ Compliance reporting configured
```

### Success Milestones
- ✅ **Week 2:** All data imported + integrations live
- ✅ **Week 3:** Executive review completed, 5 actions in motion
- ✅ **Month 2:** First cost savings realized and tracked
- ✅ **Month 3:** Compliance reports automated + first QBR completed
- ✅ **Quarter 2:** Full ROI verified against baseline

### Handoff Criteria
| Stage | From | To | Trigger | Data Passed |
|-------|------|----|---------|-------------|
| Sales → Onboarding | Growth Lead | Ops Agent | Contract signed | Full pipeline data, executive sponsor, custom requirements |
| Onboarding → CS | Ops Agent | Health Score Monitor | Go-live declared | Full config, integrations, SLA, escalation paths |

### Enterprise Escalation Path
```
Issue Detection → Tier 1 Support (30 min) 
    → Tier 2 (2 hours if unresolved)
    → Dedicated CS Manager (4 hours)
    → Ops Agent (urgent)
    → Managing Partner escalation (if SLA breached)
```

---

## Tier 4: Ultra-Premium ($100K–$500K/mo)

**Target:** 200+ attorneys, AmLaw 100  
**Onboarding Lead:** Ops Agent + Dedicated Enterprise Team  
**Onboarding Time:** 4–6 weeks, white-glove  
**Time to First ROI Insight:** 14 days

### Month 1 Timeline

| Week | Milestone | Owner | Activities |
|------|-----------|-------|------------|
| **Pre** | Executive briefing | Ops Agent + Cost Agent + Growth Lead | Scope agreement, custom SLAs, success criteria, stakeholder mapping |
| **1** | Full platform deployment | Full team | Verification, DMS, compliance, drafting, billing — all configured and integrated |
| **2** | Custom integrations | Web-Dev | PMS, ERP, SSO, data warehouse, custom dashboards — built and tested |
| **3** | Firm-wide training (role-based) | Ops Agent | Admin session, partner session, associate session, paralegal session, client portal session |
| **4** | Executive ROI presentation | Ops Agent + Cost Agent | Full analysis + QBR cadence setup + strategic roadmap |
| **6** | Full go-live + CS transition | All | System live; dedicated Slack channel active; monthly QBRs scheduled |

### Onboarding Checklist (Ultra-Premium Only)
```
☐ Executive briefing completed
☐ Custom SLA drafted and signed
☐ Stakeholder mapping completed
☐ Full platform deployed (all features)
☐ Custom integrations built and tested
☐ Firm-wide training completed (5 role-based sessions)
☐ Executive ROI presentation delivered
☐ QBR cadence established
☐ Dedicated Slack/Teams channel created
☐ Priority feature request pipeline established
☐ On-site training delivered (if applicable)
☐ Custom dashboard with firm branding launched
```

### Unique Deliverables
- Custom dashboard with firm branding
- Dedicated Slack/Teams channel with CostLens team
- Monthly executive QBRs
- Custom SLA with uptime guarantees (99.9%+)
- Priority feature requests (90-day turnaround)
- On-site training for key stakeholders

### Success Milestones
- ✅ **Month 1:** Full platform live with custom integrations
- ✅ **Month 2:** First measurable ROI delivered
- ✅ **Quarter 1:** $500K+ in identified savings
- ✅ **Quarter 2:** Full compliance automation operational
- ✅ **Annual:** Multi-million dollar cost intelligence partnership

---

## Handoff Criteria Summary (All Tiers)

| Transition | What's Transferred | Who's Involved | Success Check |
|-----------|-------------------|----------------|---------------|
| **Sales → Onboarding** | Signed contract, firm profile, key contacts, data access | Growth Lead → Ops Agent | Contract signed in CRM |
| **Onboarding → Go-Live** | Configured platform, first report, verified badge, training complete | Ops Agent → Firm | Go-live call completed |
| **Go-Live → Customer Success** | Health score baseline, support contacts, QBR schedule | Ops Agent → Health Monitor | Day 7 check-in auto-triggered |

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: Pricing Model, Client Onboarding Framework, Retention & Scaling Playbook*