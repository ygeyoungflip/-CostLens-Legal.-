# CostLens Legal — Notification Template Library

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Channels:** Email, SMS  
**Use Cases Requested:** welcome email, verification approved, document uploaded, billing receipt, compliance alert

---

## Template Variables

Use these placeholders in templates:
- `{{recipient_name}}`
- `{{firm_name}}`
- `{{case_or_request_id}}`
- `{{event_time}}`
- `{{action_url}}`
- `{{support_email}}`
- `{{invoice_id}}`
- `{{amount}}`
- `{{payment_method}}`
- `{{alert_level}}`
- `{{alert_summary}}`
- `{{due_date}}`

---

## 1) Welcome Email

### Email Subject
Welcome to CostLens Legal — Start Your Verification

### Email Body
Hi {{recipient_name}},

Welcome to CostLens Legal. We’re excited to have {{firm_name}} in our trusted legal network.

To activate your account, please complete the verification steps below:
1) Confirm identity
2) Verify firm registration and insurance
3) Upload required documents

Start verification here: {{action_url}}

If you need help, contact us at {{support_email}}.

Best,  
CostLens Legal Team

### SMS Version
CostLens: Welcome {{firm_name}}! Start verification: {{action_url}}. Need help? {{support_email}}

---

## 2) Verification Approved

### Email Subject
Verification Approved — {{firm_name}} is Now Active

### Email Body
Hi {{recipient_name}},

Great news — {{firm_name}} has successfully passed verification and is now active on CostLens Legal.

What happens next:
- Your verified status is now visible in-platform
- You can begin onboarding workflows immediately
- Your team can now access full product features

Go to your dashboard: {{action_url}}

Questions? Reach us at {{support_email}}.

Best,  
CostLens Legal Team

### SMS Version
CostLens: {{firm_name}} verification approved ✅ Access your dashboard: {{action_url}}

---

## 3) Document Uploaded (Confirmation)

### Email Subject
Document Received — {{firm_name}}

### Email Body
Hi {{recipient_name}},

We received your document upload for {{firm_name}}.

Details:
- Request ID: {{case_or_request_id}}
- Uploaded at: {{event_time}}

If more documentation is needed, we’ll notify you immediately.

View status: {{action_url}}

Best,  
CostLens Legal Team

### SMS Version
CostLens: Document received for {{firm_name}} ({{case_or_request_id}}). Track status: {{action_url}}

---

## 4) Billing Receipt

### Email Subject
Payment Receipt — Invoice {{invoice_id}}

### Email Body
Hi {{recipient_name}},

Your payment has been successfully processed.

Receipt details:
- Invoice: {{invoice_id}}
- Amount paid: {{amount}}
- Payment method: {{payment_method}}
- Date/time: {{event_time}}

You can view billing history here: {{action_url}}

If anything looks incorrect, contact {{support_email}}.

Best,  
CostLens Legal Billing

### SMS Version
CostLens receipt: {{amount}} paid for invoice {{invoice_id}}. View details: {{action_url}}

---

## 5) Compliance Alert (High Priority)

### Email Subject
[{{alert_level}}] Compliance Alert — Action Required for {{firm_name}}

### Email Body
Hi {{recipient_name}},

A compliance alert has been triggered for {{firm_name}}.

Alert details:
- Severity: {{alert_level}}
- Summary: {{alert_summary}}
- Triggered at: {{event_time}}
- Response due: {{due_date}}

Please review and take action immediately: {{action_url}}

If you believe this is an error, contact {{support_email}}.

Best,  
CostLens Legal Compliance

### SMS Version
CostLens {{alert_level}} alert for {{firm_name}}: {{alert_summary}}. Action by {{due_date}}: {{action_url}}

---

## Sending Rules

- Welcome, verification, document, billing: send email immediately; SMS optional by user preference.
- Compliance high-priority alerts: send email + SMS immediately; repeat escalation if unacknowledged.
- All templates should log send status and message ID in notification audit table.

