# Referral Outreach Templates

## To Signed Partners (Kirkland, Latham, etc.)
**Subject: Introduction Request / Expanding the CostLens Verified Network**

Hi [Name],

Great working with you on the [Firm Name] onboarding. We're already seeing some early wins on the case profitability benchmarks.

As we discussed, we're expanding our "CostLens Verified" network to a few more elite firms. Given your success with the platform, I was wondering if you’d be open to making a warm introduction to 2-3 partners at other firms who would benefit from these cost intelligence insights?

Specifically, we’re looking to connect with leadership at firms like [Target Firm 1] or [Target Firm 2]. 

Would you be open to a quick intro? I've included a short blurb below to make it easy.

Best,
[My Name]

---

## Blurb for Partner to Forward
**Subject: Cost intelligence and ROI benchmarking**

Hi [Peer Partner Name],

I've been using a platform called CostLens Legal to get better visibility into our case cost drivers and profitability. They just helped us identify a [X]% reduction in admin overhead and mapped out a [Y]% ROI for our next quarter.

They're expanding their verified network and I thought it might be worth a look for your group. I've cc'd [My Name] from their team if you want to grab 15 minutes to see the benchmarks they're running for us.

---

## Request for 3 Referrals (Standard Onboarding)
**Subject: 3 Referrals for the CostLens Network**

Hi [Name],

As part of our premium onboarding, we offer a "Referral ROI" credit for every peer firm you introduce to the network. 

Could you provide the names and contact info for 3 colleagues at other firms who are currently focused on operational efficiency or cost reduction? We'd love to show them the same 1,740% ROI model we built for you.

1. [Name] - [Firm]
2. [Name] - [Firm]
3. [Name] - [Firm]

Thanks for being a key part of our growth!
