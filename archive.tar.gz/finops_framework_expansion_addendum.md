# CostLens Legal — FinOps Framework Expansion Addendum

**Date:** May 20, 2026  
**Owner:** FinOps & Licensing Agent  
**Objective:** Integrate underused-resource detection and CAC controls into the existing FinOps operating system.

---

## 1) What Changed

This addendum expands the prior FinOps package from "license consolidation only" to a broader cost-control layer that now includes:

1. **Underused Resource Detection** — recurring waste detection and capacity reclamation
2. **Client Acquisition Cost (CAC) Analysis** — growth spend efficiency and payback control

New companion docs:
- `/home/team/shared/underused_resource_detection_framework.md`
- `/home/team/shared/client_acquisition_cost_finops_model.md`
- `/home/team/shared/cac_tracking_template.csv`

---

## 2) KPI Extensions to Existing Stack

Add these fields to current dashboard/reporting packs:

### Resource Efficiency (FinOps + Ops)
- Underused License Cost
- Idle Seat Count
- Retainer Waste
- Reclaimed Capacity Value

### Growth Efficiency (FinOps + Sales)
- Blended CAC
- CAC by channel
- CAC payback (months)
- LTV:CAC ratio
- Onboarding cost per signed firm

---

## 3) Data Model Additions

### Table: `underused_resources`
- snapshot_date
- resource_type (license/retainer/platform)
- owner_team
- committed_cost_usd
- utilized_value_usd
- waste_value_usd
- action_status
- expected_savings_usd

### Table: `acquisition_economics`
- period_start
- period_end
- channel
- sales_cost_usd
- marketing_cost_usd
- tooling_cost_usd
- onboarding_cost_usd
- signups
- cac_usd
- payback_months
- ltv_cac_ratio

---

## 4) Governance + Cadence

- Weekly: underused watchlist + CAC pulse
- Monthly: finance-reconciled savings and CAC close
- Quarterly: reforecast savings + acquisition spend mix

Owners:
- Underused resource KPIs: FinOps + Ops
- CAC KPIs: FinOps + Growth/Sales

---

## 5) Immediate Next Steps (Time-Bound)

1. By **May 24, 2026**: publish first underused resource watchlist.
2. By **May 27, 2026**: begin weekly CAC capture in template.
3. By **June 30, 2026**: deliver first combined month-end report including software savings + CAC efficiency metrics.
4. By **August 20, 2026**: validate cost-reduction and acquisition-efficiency results against team goals.

