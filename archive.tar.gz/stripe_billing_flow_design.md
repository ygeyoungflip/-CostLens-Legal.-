# CostLens Legal — Stripe Billing Flow Design

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Task:** Design Stripe billing integration with 10% platform fee routing to CTO account, automated notifications, and payment flow.

---

## 1) Requirements (from task + platform expansion)

1. Stripe-based payment processing for subscriptions and one-time invoices
2. **10% platform fee** on each billable transaction
3. Platform fee routed to **CTO Stripe account**
4. Automated notifications (email/SMS/in-app) for billing status events
5. Reconciliation-friendly ledger and audit trail

---

## 2) Recommended Stripe Pattern

## 2.1 Connect charge model
Use **Stripe Connect destination charges** for marketplace-style split payments.

### Why this pattern
- Supports `application_fee_amount` at charge time (our 10% platform fee)
- Clear flow-of-funds visibility in Stripe
- Works with Checkout and PaymentIntents

### Key Stripe behavior (official docs)
- Full amount is sent to destination connected account, application fee is transferred back to platform.
- Stripe processing fees are debited from platform amount in destination-charge flow.
- `checkout.session.completed` and billing/invoice events can drive post-payment automation.

Sources:
- Destination charges: https://docs.stripe.com/connect/destination-charges
- Connect charge types/refunds/disputes: https://docs.stripe.com/connect/charges
- Subscription/Billing webhooks: https://docs.stripe.com/billing/subscriptions/webhooks
- Webhook security: https://docs.stripe.com/webhooks

---

## 3) Account Topology

1. **Platform Stripe account** (CostLens)
2. **Connected account per law firm** (recipient of service payment share)
3. **CTO Stripe treasury account** (recipient of platform-fee sweep)

> Note: Stripe sends application fees to the platform account. To route fee proceeds to CTO account, run an automated transfer/sweep job from platform balance to CTO account.

---

## 4) Core Billing Flow

## 4.1 Subscription / recurring charge flow

1. Customer selects plan (Starter/Growth/Enterprise)
2. Backend creates Checkout Session or PaymentIntent with:
   - `transfer_data[destination] = <firm_connected_account_id>`
   - `application_fee_amount = round(gross_amount * 0.10)`
3. Payment captured by Stripe
4. Fund movement:
   - Firm connected account receives gross then net after app fee adjustment
   - Platform receives 10% application fee
   - Stripe fees debited per destination-charge rules
5. Webhooks process status + notifications
6. Nightly sweep transfers platform-fee proceeds to CTO account

## 4.2 One-time invoice flow

Same split logic; invoice is generated in Stripe Billing or internal billing service and collected via hosted invoice/checkout link.

---

## 5) Fee Routing Logic (10%)

## Formula
- `gross = invoice_total`
- `platform_fee = round(gross * 0.10)`
- `firm_share_before_processor_fees = gross - platform_fee`

## Example values

| Gross Charge | 10% Platform Fee | Firm Share (pre-processor adjustments) |
|---:|---:|---:|
| $100 | $10 | $90 |
| $1,000 | $100 | $900 |
| $5,000 | $500 | $4,500 |

## CTO routing
- Option A (recommended): daily automated transfer from platform available balance to CTO account (after reserve buffer)
- Option B: weekly payout cadence to smooth dispute/refund volatility

---

## 6) Notification System Design

## 6.1 Channels
- Email (primary): customer + firm admin + internal ops
- SMS (optional for failed/urgent states)
- In-app notifications (status center)

## 6.2 Event-driven notifications

### Payment success path
- `checkout.session.completed`
- `invoice.paid` / `invoice.payment_succeeded`
- `payment_intent.succeeded`

### Payment failure / recovery path
- `invoice.payment_failed`
- `invoice.payment_action_required`
- `customer.subscription.updated` (status changes)
- `customer.subscription.deleted` (if canceled)

### Internal finance ops
- `transfer.created` / payout events for CTO fee sweeps
- dispute/refund events for exception workflows

## 6.3 Delivery architecture
1. Stripe webhook endpoint receives event
2. Verify `Stripe-Signature` header (raw-body verification)
3. Persist event idempotently (`event_id` unique)
4. Route to notification worker queue
5. Send templated notifications + persist delivery outcome

---

## 7) Data Model (minimum)

### `billing_transactions`
- id
- stripe_event_id
- charge_id / payment_intent_id / invoice_id
- firm_id
- gross_amount
- platform_fee_amount
- estimated_firm_share
- status
- created_at

### `fee_sweep_ledger`
- id
- date
- platform_fee_collected
- reserve_held
- amount_swept_to_cto
- stripe_transfer_id
- status

### `billing_notifications`
- id
- stripe_event_id
- recipient_type (client/admin/internal)
- channel (email/sms/in-app)
- template_key
- send_status
- sent_at

### `webhook_events`
- stripe_event_id (unique)
- event_type
- payload_hash
- processed_at
- processing_status

---

## 8) Refunds, Disputes, and Edge Cases

1. **Refunds** (destination charge): platform balance is debited; optionally use transfer reversal and fee refund behavior when policy requires.
2. **Disputes/chargebacks** (destination charge): platform is typically debited; maintain reserve buffer in fee sweep logic.
3. **Insufficient platform balance**: delay CTO sweep until reserve + pending obligations covered.
4. **Idempotency failures**: enforce unique event processing and replay-safe handlers.

---

## 9) Security & Compliance Controls

- Webhook signature verification mandatory
- IP allowlisting for Stripe webhook source ranges
- Least-privilege API keys and restricted webhook secret scope
- Audit logs for all fee calculations and payout actions
- Transparent fee disclosure on invoices/checkout

---

## 10) Implementation Plan & Effort Estimate

| Phase | Scope | Estimate |
|---|---|---:|
| Phase 1 | Stripe Connect setup + destination charge flow + 10% fee calc | 24 hrs |
| Phase 2 | Webhook processor + idempotency + notification queue | 28 hrs |
| Phase 3 | CTO sweep ledger + automated transfer job + reconciliation views | 22 hrs |
| Phase 4 | Failure handling (refund/dispute flows), monitoring, QA | 26 hrs |
| **Total** |  | **100 hrs** |

Assuming blended build rate of $120/hr, one-time implementation budget is approximately **$12,000**.

---

## 11) Acceptance Criteria

1. Every charge applies and records exactly 10% platform fee
2. CTO sweep job successfully routes fee proceeds on schedule
3. Success/failure billing notifications auto-send from Stripe events
4. Webhook pipeline is signature-verified and idempotent
5. Finance can reconcile gross, fee, net, and payout values per transaction

