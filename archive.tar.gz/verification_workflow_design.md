# Verification Workflow & Secure Document Storage Design

## End-to-End Onboarding Verification for Law Firm Clients

**Prepared by:** Operations Optimization Agent  
**Date:** May 20, 2026  
**Context:** 2 firms already signed up (Gibson Dunn, Quinn Emanuel), 4 demos scheduled, 202 firms in pipeline. Verification system must handle scaling to 50+ firms in 3 months.

---

## 1. Current State Assessment

### Existing Signup Flow (Landing Page)
```
Landing Page → Signup Form (name, email, firm, size) 
    → Google Sheet record → "We'll be in touch within 48 hours"
```

**Gap:** No identity verification, no compliance checks, no document upload, no automated onboarding. After signup, everything is manual follow-up from Growth & Sales Lead.

### Target State Vision
```
Signup → Identity Verification → Compliance Checks → Document Upload 
    → Approval → Verified Badge → Product Access → Ongoing Monitoring
```

---

## 2. Verification API Research Report

### Evaluation Criteria
| Criterion | Weight | Description |
|-----------|--------|-------------|
| Coverage | 25% | Supports business + identity + compliance checks |
| Pricing Model | 20% | Per-verification vs. subscription; fits law firm margins |
| Integration Ease | 20% | API docs, SDK availability, webhook support |
| Compliance | 15% | SOC 2, GDPR, data residency |
| Speed | 10% | Time to verification result |
| Scalability | 10% | Handles 50 → 500+ firms |

### Provider Comparison Matrix

| Provider | Core Function | Pricing | Best For | Score |
|----------|--------------|---------|----------|-------|
| **Stripe Identity** | Identity verification (government ID + selfie) | $1.50/verification | Individual identity at low cost | ⭐⭐⭐⭐⭐ |
| **Middesk** | Business registration, tax ID, insurance verification | ~$5–$15/company | **Best fit for law firm verification** | ⭐⭐⭐⭐⭐ |
| **Alloy** | Compliance orchestration (KYC/KYB/AML) | ~$2–$10/check + platform fee | Multi-source compliance orchestration | ⭐⭐⭐⭐ |
| **Persona** | Identity, document, business verification | ~$2–$10/verification | Flexible, no-code workflow builder | ⭐⭐⭐⭐ |
| **Checkr** | Background checks (criminal, employment) | ~$30–$60/check | Employee screening (overkill for firm-level) | ⭐⭐⭐ |
| **CLEAR** | Identity verification (biometric + ID) | Subscription (~$20–$50/user/yr) | Recurring user verification | ⭐⭐⭐ |
| **Veriff** | Identity verification (ID + liveness) | ~$0.50–$2/verification | Low-cost ID checks | ⭐⭐⭐⭐ |

### Recommended Stack

| Purpose | Primary Provider | Backup | Monthly Cost (est.) |
|---------|----------------|--------|-------------------|
| **Business verification** (EIN, registration, insurance) | Middesk | Alloy | $100–$500 |
| **Identity verification** (firm representative) | Stripe Identity | Persona | $75–$300 |
| **Compliance orchestration** (AML, sanctions) | Alloy | — | $200–$1,000 |
| **Secure document upload** | Uploadthing / AWS S3 + signed URLs | — | $50–$200 |

**Recommended Monthly Budget**: $425–$2,000 (scales with onboarding volume)

---

## 3. End-to-End Verification Onboarding Workflow

### Stage 0: Lead Capture (Existing)
```
                          ┌─────────────────────┐
                          │   Landing Page       │
                          │   Signup Form        │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │   Google Sheet /     │
                          │   Pipeline Tracker   │
                          └──────────┬──────────┘
                                     │
                          ┌──────────▼──────────┐
                          │  Growth Lead sends  │
                          │  welcome email with  │
                          │  verification link   │
                          └──────────┬──────────┘
                                     │
                                     ▼
```

### Stage 1: Identity Verification (Day 1)
```
                    WELCOME EMAIL WITH VERIFICATION LINK
                              │
                    ┌─────────▼──────────┐
                    │  Click verification │
                    │  link (magic link / │
                    │  time-limited)      │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  Identity Check    │
                    │  (Stripe Identity) │
                    │  ├─ Upload gov't ID│
                    │  ├─ Selfie + liveness│
                    │  └─ 15–30 sec ⏱   │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  PASS?             │
                    │  ┌── Yes ──► Stage 2│
                    │  └── No ──► Manual  │
                    │            review   │
                    └────────────────────┘
```

### Stage 2: Business Verification (Day 1–2)
```
                    BUSINESS VERIFICATION FORM
                              │
                    ┌─────────▼──────────┐
                    │  Firm Details      │
                    │  ├─ Legal name     │
                    │  ├─ EIN / Tax ID   │
                    │  ├─ Business address│
                    │  ├─ State of incorporation│
                    │  └─ Website        │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  Middesk API Call  │
                    │  ├─ Business       │
                    │  │  registration   │
                    │  ├─ Tax ID validity│
                    │  ├─ Active status  │
                    │  └─ Watchlist check│
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  PASS?             │
                    │  ┌── Yes ──► Stage 3│
                    │  └── No ──► Request │
                    │            docs for │
                    │            manual   │
                    │            review   │
                    └────────────────────┘
```

### Stage 3: Insurance & Compliance (Day 2–3)
```
                    COMPLIANCE & INSURANCE
                              │
                    ┌─────────▼──────────┐
                    │  Insurance Upload  │
                    │  ├─ Professional   │
                    │  │  liability cert │
                    │  ├─ Effective date │
                    │  ├─ Expiration date│
                    │  └─ Coverage amount│
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  AML/Sanctions     │
                    │  Check (Alloy)     │
                    │  ├─ PEP screening  │
                    │  ├─ Sanctions lists │
                    │  ├─ Adverse media  │
                    │  └─ 1–5 min ⏱     │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  PASS?             │
                    │  ┌── Yes ──► Stage 4│
                    │  └── No ──► Manual  │
                    │            review +  │
                    │            escalation│
                    └────────────────────┘
```

### Stage 4: Secure Document Upload (Day 2–3)
```
                    SECURE DOCUMENT UPLOAD
                              │
                    ┌─────────▼──────────┐
                    │  Document Portal   │
                    │  (Encrypted Upload)│
                    │                    │
                    │  Required:         │
                    │  ├─ Signed         │
                    │  │  engagement     │
                    │  │  letter         │
                    │  ├─ Proof of firm  │
                    │  │  registration   │
                    │  ├─ Insurance cert │
                    │  └─ Data sharing   │
                    │     agreement      │
                    │                    │
                    │  Optional:         │
                    │  ├─ Org chart      │
                    │  ├─ Practice area  │
                    │  │  descriptions   │
                    │  └─ Sample case    │
                    │     data (future)  │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  All Documents     │
                    │  Uploaded?         │
                    │  ┌── Yes ──► Stage 5│
                    │  └── No ──► Reminder│
                    │            email    │
                    │            (72 hrs) │
                    └────────────────────┘
```

### Stage 5: Review & Approval (Day 3–5)
```
                    ADMIN REVIEW DASHBOARD
                              │
                    ┌─────────▼──────────┐
                    │  Automated Checks  │
                    │  ├─ All API checks │
                    │  │  passed?        │
                    │  ├─ All documents  │
                    │  │  uploaded?      │
                    │  └─ Any flags?     │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  DECISION          │
                    │                    │
                    │  ┌── Auto-Approve──┐│
                    │  │ (Low risk, all  ││
                    │  │ checks pass)    ││
                    │  └──────┬──────────┘│
                    │          │          │
                    │  ┌── Manual ───────┐│
                    │  │ Review (flags   ││
                    │  │ or exceptions)  ││
                    │  └──────┬──────────┘│
                    │          │          │
                    │  ┌── Deny ─────────┐│
                    │  │ (Failed checks,││
                    │  │ cannot resolve)││
                    │  └──────┬──────────┘│
                    └─────────┼──────────┘
                              │
                              ▼
```

### Stage 6: Verified Status & Access (Day 5)
```
                    ┌─────────────────────┐
                    │  APPROVED           │
                    │                     │
                    │  ├─ Verified Badge  │
                    │  │  awarded ✅      │
                    │  ├─ Product access  │
                    │  │  granted         │
                    │  ├─ Welcome packet  │
                    │  │  sent            │
                    │  ├─ Onboarding call │
                    │  │  scheduled       │
                    │  └─ Pipeline tracker│
                    │     updated         │
                    └─────────────────────┘

                    ┌─────────────────────┐
                    │  DENIED             │
                    │                     │
                    │  ├─ Rejection email │
                    │  │  with reason     │
                    │  ├─ Appeal process  │
                    │  │  explained       │
                    │  └─ Record kept for │
                    │     compliance      │
                    └─────────────────────┘
```

### Complete Swimlane Flow

| Stage | Client/Customer | Automated System | Ops Agent (Admin) |
|-------|----------------|-----------------|-------------------|
| **0** | Submits signup form | Records in DB; sends welcome email | Pipeline tracker updated |
| **1** | Completes identity verification (ID + selfie) | Stripe Identity API call; PASS/FAIL | Alerted on fail |
| **2** | Enters business details; uploads EIN/docs | Middesk API call; business check | Flagged for manual if partial match |
| **3** | Uploads insurance cert; signs agreements | Alloy AML/sanctions check | Flagged for manual if PEP hit |
| **4** | Uploads required documents via secure portal | Encrypted S3 storage; scans malware | Notified of upload completion |
| **5** | — | Aggregates all results → auto-approve or flag | Reviews flagged items within 24 hrs |
| **6** | Receives verified badge + product access | Grants access; sends welcome packet | Updates pipeline status |

---

## 4. Secure Document Upload & Storage Architecture

### Recommended Architecture

```
CLIENT BROWSER
      │
      │ HTTPS (TLS 1.3)
      ▼
┌──────────────────────┐
│  Upload Portal       │  ← Served from app domain (subdomain)
│  (React/Vanilla JS)  │
└──────────┬───────────┘
           │
           │ Pre-signed URL (time-limited, 15 min)
           ▼
┌──────────────────────┐
│  Cloud Storage       │  ← AWS S3 / GCP Cloud Storage
│  ├─ AES-256 at rest  │
│  ├─ Server-side      │
│  │  encryption       │
│  ├─ Versioning ON    │
│  ├─ Lifecycle:       │
│  │  Standard →       │
│  │  Glacier (90 day) │
│  └─ Delete (7 yr)    │
└──────────┬───────────┘
           │
           │ S3 Event → SQS Queue
           ▼
┌──────────────────────┐
│  Processing Pipeline │
│  ├─ ClamAV antivirus │
│  ├─ File type        │
│  │  validation       │
│  ├─ File size check  │
│  │  (max 50MB/file)  │
│  └─ OCR + metadata   │
│     extraction       │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│  Admin Dashboard     │
│  ├─ View/Download    │
│  ├─ Status tracking  │
│  ├─ Expiry alerts    │
│  └─ Audit log        │
└──────────────────────┘
```

### Document Categories & Requirements

| Category | Documents | Max Size | Storage Duration | Sensitivity |
|----------|-----------|----------|-----------------|-------------|
| **Identity** | Government ID, selfie | 10 MB | 90 days post-verification | 🔴 Highly sensitive |
| **Business** | EIN letter, registration cert, business license | 25 MB | Duration of engagement + 7 yrs | 🟡 Sensitive |
| **Insurance** | Professional liability cert, workers' comp | 25 MB | Duration of engagement + 7 yrs | 🟡 Sensitive |
| **Agreements** | Signed engagement letter, data sharing agreement | 10 MB | Duration of engagement + 7 yrs | 🟡 Sensitive |
| **Legal Data** | Case data, financial records, time entries | 50 MB | As specified in DSA | 🔴 Highly sensitive |

### Security Controls

| Control | Implementation | Justification |
|---------|---------------|---------------|
| **Encryption at rest** | AES-256 (S3 server-side) | Industry standard for legal data |
| **Encryption in transit** | TLS 1.3 | All uploads/downloads |
| **Pre-signed URLs** | 15-minute expiry | Prevents unauthorized access |
| **Virus scanning** | ClamAV + S3 event trigger | Malware prevention |
| **File type whitelist** | PDF, DOCX, XLSX, JPG, PNG only | Prevents executable uploads |
| **File size limits** | 50 MB per file, 200 MB total | Prevents abuse |
| **Access logging** | CloudTrail / S3 access logs | Compliance & auditing |
| **Retention policies** | Lifecycle rules → Glacier → Delete | Regulatory compliance |
| **Access control** | IAM roles, least privilege | Internal security |
| **Data residency** | US-only regions (us-east-1, us-west-2) | Law firm requirements |

### Compliance Alignment

| Regulation | How We Meet It |
|-----------|---------------|
| **ABA Model Rules 1.6** (Confidentiality) | AES-256, access controls, audit logging |
| **GDPR** (if EU firms onboard) | Right to deletion, data portability, 30-day deletion window |
| **CCPA** (California firms) | Data inventory, disclosure capabilities |
| **SOC 2** (Target certification) | Implement controls → auditor review → certification |
| **State bar ethics rules** | Segregated storage, client data protection |

---

## 5. Verification Dashboard Concept (UI Mockup)

### Dashboard Layout

```
┌────────────────────────────────────────────────────────────┐
│ ◆ CostLens Legal — Verification Dashboard     [🔔] [👤]    │
├────────────────────────────────────────────────────────────┤
│                                                            │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  STATUS OVERVIEW                          [Refresh]  │   │
│ │                                                     │   │
│ │  ✅ Verified    ⏳ In Progress    ❌ Flagged         │   │
│ │  [ 12 ]        [ 8 ]            [ 3 ]               │   │
│ │                                                     │   │
│ │  ┌─────────┬──────────┬──────────┬──────────┐       │   │
│ │  │ Identity│ Business │ Insurance│ AML      │       │   │
│ │  │  ✅ 92% │ ✅ 88%   │ ✅ 75%   │ ✅ 96%   │       │   │
│ │  └─────────┴──────────┴──────────┴──────────┘       │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                            │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  ⏳ PENDING REVIEW (3)                   [View All]  │   │
│ │                                                     │   │
│ │  ┌─────────────────────────────────────────────────┐│   │
│ │  │ Firm: Gibson Dunn                               ││   │
│ │  │ Rep: John Smith | john@gibsondunn.com          ││   │
│ │  │ ⚠️ Insurance cert expiring in 30 days           ││   │
│ │  │ [Approve] [Request Docs] [Flag]                 ││   │
│ │  └─────────────────────────────────────────────────┘│   │
│ │  ┌─────────────────────────────────────────────────┐│   │
│ │  │ Firm: Quinn Emanuel                             ││   │
│ │  │ Rep: Jane Doe | jane@quinnemanuel.com          ││   │
│ │  │ 🔴 AML alert: PEP match (manual review)        ││   │
│ │  │ [Approve] [Request Docs] [Flag]                 ││   │
│ │  └─────────────────────────────────────────────────┘│   │
│ │  ┌─────────────────────────────────────────────────┐│   │
│ │  │ Firm: Kirkland & Ellis (pending)                ││   │
│ │  │ Rep: Bob Wilson | bob@kirkland.com             ││   │
│ │  │ ⏳ Awaiting identity verification (3 days)     ││   │
│ │  │ [Send Reminder] [Cancel]                        ││   │
│ │  └─────────────────────────────────────────────────┘│   │
│ └──────────────────────────────────────────────────────┘   │
│                                                            │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  ✅ RECENTLY VERIFIED (5)                             │   │
│ │                                                     │   │
│ │  Firm            | Status  | Verified Date | Badge  │   │
│ │  ─────────────────────────────────────────────────  │   │
│ │  Latham & Watkins | ✅ All  | May 18, 2026  | 🟢    │   │
│ │  Skadden           | ✅ All  | May 17, 2026  | 🟢    │   │
│ │  Jones Day         | ✅ All  | May 16, 2026  | 🟢    │   │
│ │  Fox Rothschild    | ✅ All  | May 15, 2026  | 🟢    │   │
│ │  Morgan Lewis      | ✅ All  | May 14, 2026  | 🟢    │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                            │
│ ┌──────────────────────────────────────────────────────┐   │
│ │  FIRM DETAIL: Gibson Dunn                    [Edit]  │   │
│ │                                                     │   │
│ │  Identity:   ✅ Stripe — PASS (May 18, 2026)        │   │
│ │  Business:   ✅ Middesk — ACTIVE (EIN: XX-XXXXXXX)  │   │
│ │  Insurance:  ⚠️ Expiring Jun 18, 2026 (30 days)    │   │
│ │  AML:        ✅ Alloy — CLEAR                        │   │
│ │  Docs:       ✅ All 4 uploaded (May 18)              │   │
│ │                                                     │   │
│ │  [View Documents] [Download Report] [Revoke Access] │   │
│ │  [Set Expiry Alert]                                  │   │
│ │                                                     │   │
│ │  ─── Activity Log ───                               │   │
│ │  May 20 10:30 — Insurance expiry alert sent         │   │
│ │  May 18 14:22 — All documents verified             │   │
│ │  May 18 11:00 — Identity check completed            │   │
│ │  May 17 09:15 — Welcome email sent                  │   │
│ └──────────────────────────────────────────────────────┘   │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Badge Design (Verified Trust Signal)

```
┌──────────────────┐
│   ✅ VERIFIED    │
│   CostLens Legal │
│   Since May 2026 │
│   ─────────────  │
│   ✓ Identity     │
│   ✓ Business     │
│   ✓ Insurance    │
│   ✓ Compliance   │
└──────────────────┘
```

The verification badge could be displayed on:
- Firm's CostLens profile page
- Audit reports generated for the firm
- Client-facing materials (optional)
- Directory listings (future)

---

## 6. Implementation Roadmap

### Phase 1: Manual Verification MVP (Weeks 1–3)
**Target:** Enable verification for first 50 firms without full API integration

| Week | Deliverable | Owner | Details |
|------|-------------|-------|---------|
| 1 | Verification checklist template | Ops Agent | PDF checklist with all required items |
| 1 | Secure upload portal (simple) | Web-Dev | Password-protected page with file upload to S3 |
| 2 | Manual review workflow | Ops Agent + Growth Lead | Email-based: send checklist → receive docs → manual verify |
| 2 | Verified badge generation | Web-Dev | Simple badge image; manual assignment |
| 3 | Pipeline tracker update | Growth Lead | Add verification fields to pipeline tracker |
| 3 | SOP document | Ops Agent | "How to verify a new firm" internal procedure |

**Cost**: ~$500/mo for basic S3 storage + domain

### Phase 2: Automated Verification Core (Weeks 4–8)
**Target:** ~80% automated verifications with API integration

| Week | Deliverable | Owner | Details |
|------|-------------|-------|---------|
| 4 | Stripe Identity integration | Web-Dev | ID + selfie verification in onboarding flow |
| 4 | Middesk integration | Web-Dev | Business registration + EIN validation API |
| 5 | Alloy compliance orchestration | Web-Dev | AML/sanctions checks |
| 5 | Automated email sequence | Web-Dev | Welcome → verify → remind → approved |
| 6 | Verification dashboard v1 | Web-Dev | Basic dashboard: pending, approved, flagged |
| 6 | Document upload portal (enhanced) | Web-Dev | Encrypted upload, file validation, anti-virus |
| 7 | Auto-approve rules engine | Web-Dev | Rules: all checks pass → auto-approve |
| 7 | Badge auto-assignment | Web-Dev | Badge granted automatically on approval |
| 8 | End-to-end testing | All | Full flow test with 5 mock firms |

**Cost**: $2,000–$5,000/mo for APIs + storage + dev time

### Phase 3: Advanced Verification (Weeks 8–16)
**Target:** 95%+ automated, insurance expiry monitoring, renewal workflows

| Week | Deliverable | Owner | Details |
|------|-------------|-------|---------|
| 8–9 | Insurance expiry monitoring | Web-Dev | Automated alerts 30/15/7 days before expiry |
| 9–10 | Re-verification workflow | Ops Agent | Annual re-verification cycle |
| 10–11 | Risk scoring engine | Ops Agent + Cost Agent | Score firms by risk level for differentiated checks |
| 11–12 | Bulk verification for large firms | Web-Dev | Multi-representative verification for 200+ attorney firms |
| 12–14 | Detailed audit trail | Web-Dev | Full compliance audit log for each firm |
| 14–16 | SOC 2 readiness | Ops Agent | Controls documentation → auditor preparation |

**Cost**: $3,000–$7,000/mo ongoing

### Phase 4: Platform Integration (Ongoing, Week 16+)
**Target:** Full integration with product access, single sign-on

| Feature | Description | Timeline |
|---------|-------------|----------|
| Verified → product access gate | Verification required before accessing cost analysis tools | Week 16 |
| Verified firm directory | Public-facing directory of verified firms (opt-in) | Week 20 |
| SSO integration | Okta/Azure AD SSO for enterprise firms | Week 24 |
| Automated data import | Once verified, firms can import PMS data directly | Week 30+ |
| SLA dashboards | Verification SLAs for enterprise clients | Week 32+ |

---

## 7. Key Metrics & SLAs

| Metric | Target | Measurement |
|--------|--------|-------------|
| Time to verify (auto) | <24 hours | From signup → verified badge |
| Time to verify (manual) | <72 hours | From signup → verified badge |
| Auto-approval rate | >80% (target 90%) | Auto-approved / Total verifications |
| Document upload completion | >90% within 48 hours | Uploads started / Uploads completed |
| False positive rate | <5% | Legitimate firms incorrectly flagged |
| Verification abandonment | <20% | Started but never completed verification |
| Badge acceptance | >95% | Firms that accept/display their badge |
| Re-verification rate on expiry | >95% | Insurance expired → renewed within 30 days |

---

## 8. SOP: Verification Admin Workflow

### Daily Tasks (Ops Agent)
1. **Check flagged queue** — Review any firms in "Flagged" status
2. **Approve or request more info** — Within 24 hours of flag
3. **Monitor expiring insurance** — Send reminders to firms approaching expiry
4. **Update pipeline tracker** — Sync verification status with Growth Lead

### Escalation Paths

| Scenario | Action | Timeframe |
|----------|--------|-----------|
| Failed identity check (3+ attempts) | Manual ID review via secure link | 24 hours |
| Business registration mismatch | Request Articles of Incorporation | 48 hours |
| AML/PEP match | Full manual review + compliance consult | 72 hours |
| Insurance expired >30 days | Suspend access; notify firm | Immediate |
| Suspicious documents reported | Security review; potential report to authorities | 24 hours |
| Account takeover indicators | Immediate suspension + security audit | Immediate |

---

## 9. Coordination with Team

| Teammate | Role in Verification | Dependencies |
|----------|---------------------|-------------|
| **Growth & Sales Lead** | Sends welcome email; tracks verification in pipeline; hands off to Ops Agent | Verification checklist (Ops Agent) |
| **Web-Dev** | Builds upload portal, dashboard, API integrations, badge system | Requirements (Ops Agent) |
| **Cost Agent** | Risk scoring model; compliance data integration | Verification data feeds |
| **FinOps Agent** | Budget for API costs; vendor negotiations with API providers | Usage projections (Ops Agent) |

---

## 10. Appendix: Verification Checklist (Manual Phase)

```
COSTLENS LEGAL — FIRM VERIFICATION CHECKLIST
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Firm Name: ______________________________
Representative: _________________________
Date Started: ___________________________

□ 1. IDENTITY
   □ Government-issued ID uploaded
   □ Selfie/photo matches ID
   □ Name matches signup form

□ 2. BUSINESS
   □ EIN / Tax ID verified (Middesk/Manual)
   □ Business registration active
   □ Business address confirmed
   □ No watchlist hits

□ 3. INSURANCE
   □ Professional liability cert uploaded
   □ Coverage amount ≥ $1M
   □ Effective date in past
   □ Expiration date ≥ 90 days out

□ 4. AML / COMPLIANCE
   □ PEP check cleared
   □ Sanctions list cleared
   □ Adverse media check cleared

□ 5. DOCUMENTS
   □ Signed engagement letter
   □ Data sharing agreement signed
   □ Proof of registration

□ 6. DECISION
   □ APPROVED — Badge assigned
   □ FLAGGED — Reason: ______________
   □ DENIED — Reason: ______________

Verified By: ________________ Date: ________
```

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: PRD Design Principles (simple entry point), Verification System PRD (all 7 priorities + 5 deliverables)*