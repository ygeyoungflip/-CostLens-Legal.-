# Automation Opportunity Surfacing Framework

This framework provides a structured approach to identifying and prioritizing manual legal and administrative tasks for automation, aimed at reaching the firm's goal of a 20% reduction in admin overhead.

## 1. Task Classification (Class A, B, C)

| Category | Description | Automation Target | Examples |
| :--- | :--- | :--- | :--- |
| **Class A (Routine)** | Highly repetitive, rules-based, no legal judgment required. | 90% | Conflict checks, intake, filing fee payments, scheduling. |
| **Class B (Standard)** | Pattern-based, requires "fill-in-the-blank" legal logic. | 50% | Basic motions, NDAs, employment contracts, invoice generation. |
| **Class C (Complex)** | High-judgment, strategic, or unique to the case. | 15% | Legal strategy, deposition preparation, complex negotiations. |

## 2. Identification Methodology (Bottom-Up)
1.  **Manual Log:** Attorneys and staff use the `case_cost_breakdown_template.md` (Section 4) to log manual tasks as they occur.
2.  **Time-Volume Analysis:** Calculate (Time spent per task) * (Frequency per month) = **Total Waste Potential**.
3.  **The "Admin Drag" Signal:** If a lawyer's Admin-to-Billable ratio exceeds 15%, an automation audit of their typical workflow is triggered.

## 3. Prioritization Matrix
*   **High Priority:** High Volume + Class A (Immediate ROI).
*   **Medium Priority:** Low Volume + Class A OR High Volume + Class B.
*   **Low Priority:** Class C tasks (Wait for advanced AI maturity).

## 4. ROI on Automation
Every automated task is tied to the **Billable Efficiency ROI** metric:
**Value Gained = (Hours Saved) * (Attorney/Staff Billable Rate)**

## 5. Integration with Operations
This framework directly feeds into the `ops-agent`'s Admin Efficiency Plan, providing the "real-world" data needed to justify software investments or process changes.
