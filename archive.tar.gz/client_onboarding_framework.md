# CostLens Legal — Client Onboarding Framework
**Purpose:** Rapid transition from signed contract to measurable ROI.

## 1. Initial Data Intake (Manual Entry Phase)
To begin analysis immediately, we require the following data points (CSV or Excel format preferred):
- **Case Catalog:** Case ID, Type, Date Opened, Lead Attorney.
- **Time Entries:** Case ID, Task Type, Hours, Billing Rate.
- **Expenses:** Case ID, Category (Discovery, Software, Vendor), Amount.
- **Administrative Baseline:** Estimated weekly hours spent by associates/paralegals on non-billable tasks.

## 2. Configuration & Baseline Setting (Week 1)
- **Taxonomy Mapping:** Align firm task codes with the CostLens Cost Driver Taxonomy.
- **Efficiency Benchmarking:** Set internal efficiency targets based on industry averages (AmLaw 200/Regional).
- **Early Alert Setup:** Define budget variance thresholds for automated notifications.

## 3. First Analysis Report (Week 2)
- **Top 3 Cost Drivers:** Identifying the specific tasks/teams driving the highest margin erosion.
- **Profitability Audit:** Breakdown of profitability by case type and lead partner.
- **ROI Roadmap:** A prioritized list of 3-5 immediate actions (e.g., software consolidation, paralegal task shift).

## 4. Recurring Success Reviews (Monthly)
- **Realized ROI Tracking:** Measuring actual savings against the initial 990%+ projection.
- **Capacity Reclamation:** Tracking the recovery of billable hours from administrative automation.

---
*Prepared by Growth & Sales Lead | CostLens Legal*
