# Document Management System Design

## Auto-Backup, Auto-Send, Encrypted Storage & Version Control

**Prepared by:** Operations Optimization Agent  
**Date:** May 22, 2026  
**Alignment:** Platform Expansion V2 Item #4, Capability #7 (PRD)

---

## 1. System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    DOCUMENT MANAGEMENT SYSTEM                │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐    ┌──────────────────┐   ┌───────────┐  │
│  │  Upload API   │    │  Document Engine  │   │  Search   │  │
│  │  (Pre-signed  │───▶│  Processing       │──▶│  Index    │  │
│  │   URLs)       │    │  Pipeline         │   │  (Elastic)│  │
│  └──────────────┘    └────────┬─────────┘   └───────────┘  │
│                               │                              │
│  ┌──────────────┐    ┌────────▼─────────┐   ┌───────────┐  │
│  │  Auto-Backup  │◀───│  Storage Layer   │──▶│  Auto-Send │  │
│  │  Scheduler    │    │  (S3 AES-256)    │   │  Queue     │  │
│  └──────────────┘    └──────────────────┘   └───────────┘  │
│                                                              │
│  ┌──────────────┐    ┌──────────────────┐   ┌───────────┐  │
│  │  Version      │    │  Access Control  │   │  Audit    │  │
│  │  Manager      │    │  (RBAC per firm) │   │  Log      │  │
│  └──────────────┘    └──────────────────┘   └───────────┘  │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Tech Stack
| Component | Technology | Justification |
|-----------|-----------|---------------|
| **Object storage** | AWS S3 (or Box API for enterprise) | Industry standard, encryption at rest, lifecycle management |
| **Encryption** | AES-256 (SSE-S3 or SSE-KMS) | ABA Model Rule 1.6 compliance |
| **Upload** | Pre-signed S3 URLs (15-min expiry, TLS 1.3) | Secure, time-limited, no direct public access |
| **Virus scanning** | ClamAV + S3 event → Lambda trigger | Malware prevention |
| **OCR** | AWS Textract / Tesseract | Scanned document processing |
| **Search** | Elasticsearch | Full-text search across all firm documents |
| **Processing** | AWS Lambda (serverless) | Auto-scaling, no infrastructure management |
| **Queue** | SQS for async processing | Reliable document pipeline |

---

## 2. Secure Upload & Storage

### Upload Flow
```
User Upload ──▶ Pre-signed URL Request ──▶ Auth Check (RBAC)
                                              │
                                         ┌────▼────┐
                                         │  PASS?  │
                                         │ YES  NO │
                                         └──┬──┘  │
                                            │     └─▶ 403 Error
                                     ┌──────▼──────┐
                                     │ Generate     │
                                     │ Pre-signed   │
                                     │ URL (15 min) │
                                     └──────┬──────┘
                                            │
                                     ┌──────▼──────┐
                                     │ Upload to S3 │
                                     │ (TLS 1.3)   │
                                     └──────┬──────┘
                                            │
                                     ┌──────▼──────┐
                                     │ S3 Event →   │
                                     │ SQS Queue    │
                                     └──────┬──────┘
                                            │
                                     ┌──────▼──────────┐
                                     │ Processing Pipeline│
                                     │ 1. ClamAV scan    │
                                     │ 2. MIME validation│
                                     │ 3. OCR extraction  │
                                     │ 4. Metadata tag    │
                                     │ 5. Elasticsearch   │
                                     │    index           │
                                     └──────┬──────────┘
                                            │
                                     ┌──────▼──────┐
                                     │ Store in S3  │
                                     │ + version +  │
                                     │ backup       │
                                     └─────────────┘
```

### File Specifications
| Parameter | Specification |
|-----------|--------------|
| **Allowed types** | PDF, DOCX, DOC, XLSX, XLS, JPG, PNG, TIFF, EML, MSG |
| **Max file size** | 50 MB per file, 200 MB per batch |
| **Max batch count** | 25 files per upload session |
| **Virus scan** | ClamAV (auto-quarantine on detection) |
| **MIME validation** | Extension + magic byte verification |
| **Malware response** | Quarantine file, notify admin, log incident |

---

## 3. Auto-Backup System

### Backup Architecture
```
                         ┌──────────────────────┐
                         │  PRIMARY REGION       │
                         │  us-east-1            │
                         │                      │
                         │  ┌────────────────┐  │
                         │  │ S3 Bucket      │  │
                         │  │ (Standard)     │  │
                         │  │ Versioning: ON │  │
                         │  │ 90 days →      │  │
                         │  │ Glacier        │  │
                         │  └───────┬────────┘  │
                         └──────────┼───────────┘
                                    │
                    Cross-Region    │  Real-time replication
                    Replication     │
                                    │
                         ┌──────────▼───────────┐
                         │  BACKUP REGION        │
                         │  us-west-2            │
                         │                      │
                         │  ┌────────────────┐  │
                         │  │ S3 Bucket      │  │
                         │  │ (Replica)      │  │
                         │  │ Versioning: ON │  │
                         │  │ Glacier: 7 yr  │  │
                         │  └────────────────┘  │
                         └──────────────────────┘
```

### Backup Specifications
| Feature | Specification |
|---------|--------------|
| **Primary storage** | S3 Standard — 90 days, then auto-transition to Glacier |
| **Backup storage** | S3 Standard (cross-region replica) — 7 years retention |
| **Replication** | S3 Cross-Region Replication (CRR) — real-time |
| **Versioning** | Enabled on both buckets — all versions retained |
| **Backup trigger** | Every S3 upload event → instant replication |
| **Daily snapshot** | Secondary: daily inventory verification |
| **Restore RTO** | <1 hour from primary, <4 hours from Glacier |
| **Restore RPO** | <5 minutes (real-time replication) |
| **Test schedule** | Weekly automated restore test (5 random files) |
| **Retention** | 7 years post-case (ABA requirements) |
| **Deletion policy** | Legal hold override for active litigation |

---

## 4. Auto-Send to Lawyers

### Event-Driven Notification Matrix

| Trigger Event | Action | Recipients | Delivery Method | Timing |
|--------------|--------|-----------|-----------------|--------|
| **Document uploaded to case** | Send copy + contextual notification | All attorneys + paralegals on case | Email (secure link) + in-app notification | Immediate |
| **Document finalized** | Send final version with approval request | Lead partner + supervising attorney | Email (secure link, no attachment) | On finalize click |
| **New version available** | Send version diff summary + link | All collaborators on doc | Email summary + in-app | On new version save |
| **Document shared externally** | Send notification + access log entry | Case admin + firm security officer | Email with full audit detail | On external share |
| **Bulk send** | Send document set to role-based group | All partners / all associates / all paralegals | Email with individual secure links | As triggered |
| **Document expiry (30 days)** | Send renewal reminder | Document owner + firm admin | Email alert | 30/15/7 days before |

### Secure Link Delivery Specification
| Feature | Specification |
|---------|--------------|
| **Link format** | `https://app.costlens.legal/d/{firm_id}/{doc_id}?token={jwt}` |
| **Link expiry** | 7 days (default), configurable per firm |
| **Authentication** | Single-use JWT embedded in link |
| **Re-authentication** | 2FA prompt for sensitive docs (configurable) |
| **Download limit** | Max 5 downloads per link (configurable) |
| **Forwarding** | Links cannot be forwarded — tied to recipient email |
| **Watermark** | "Confidential — CostLens Legal" overlay for shared links |

### Email Templates
```
Subject: 📄 New document: [Document Name] — [Case Name]

Hi [Attorney Name],

A new document has been uploaded to [Case Name]:

📄 [Document Name]
📁 [Document Category]
👤 Uploaded by: [Uploader Name]
⏱ [Timestamp]

🔗 [View Document] (secure link expires in 7 days)

[Download] [Comment] [Share]

---
CostLens Legal — Document Management
This link is unique to you. Do not forward.
```

---

## 5. Version Control System

### Version Management
| Feature | Specification |
|---------|--------------|
| **Auto-version trigger** | Every save (30-sec auto-save) → collapsed into hourly snapshots |
| **Manual version** | User creates named version ("Pre-review draft v1", "Partner edits") |
| **Version limit** | Unlimited (billed per GB of storage) |
| **Version tree** | Visual DAG showing branch/merge paths for collaborative docs |
| **Diff view** | Side-by-side or inline diff between any two versions |
| **Restore** | One-click restore to any version — creates new version (no overwrite) |
| **Compare** | Select any 2 versions → highlighted changes |
| **Version metadata** | Author, timestamp, change summary, file size |

### Version History UI
```
┌────────────────────────────────────────────────────────────┐
│ VERSION HISTORY — Motion_v3.docx                           │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ○ v5 — "Partner review complete"     Bob Wilson   Today  │
│  │    Restore | Compare | Download                         │
│  │                                                         │
│  ○ v4 — "Addressing court comments"    Jane Smith   Today  │
│  │    Restore | Compare | Download                         │
│  │                                                         │
│  ○ v3 — "Initial draft"                Jane Smith   May 20 │
│  │    Restore | Compare | Download                         │
│  │                                                         │
│  ○ v2 — Auto-save (collapsed)                    May 20   │
│  │    (8 auto-saves between 14:00-17:00)                   │
│  │                                                         │
│  ○ v1 — "Uploaded from template"       Jane Smith   May 20 │
│       Restore | Compare | Download                         │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Document Naming Convention
```
{CaseNumber}_{DocumentType}_{Title}_v{Version}.{ext}

Example: 2026-001_Motion_SummaryJudgment_v3.docx
```

---

## 6. Document Organization & Access Control

### Folder Structure
```
🏢 Gibson Dunn
├── 🟢 M&A Practice
│   ├── Case: Acme Corp Acquisition (2026-001)
│   │   ├── 📁 Pleadings
│   │   ├── 📁 Discovery
│   │   ├── 📁 Correspondence
│   │   ├── 📁 Drafts
│   │   └── 📁 Final Orders
│   └── Case: BetaCorp Merger (2026-002)
│       └── ...
└── 🔵 Litigation
    └── Case: State v. Client (2026-003)
        └── ...
```

### Role-Based Access Control
| Role | View | Upload | Edit | Delete | Share | Export |
|------|------|--------|------|--------|-------|--------|
| **Firm Admin** | ✅ All firm docs | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Partner** | ✅ Own cases | ✅ | ✅ | ⚠️ Soft delete | ✅ | ✅ |
| **Associate** | ✅ Assigned cases | ✅ | ✅ | ❌ | ⚠️ Request | ✅ |
| **Paralegal** | ✅ Assigned cases | ✅ | ✅ | ❌ | ❌ | ✅ |
| **Client (read)** | ✅ Own cases only | ⚠️ Via intake | ❌ | ❌ | ❌ | ✅ |
| **CostLens Admin** | ✅ Cross-firm (audit) | ❌ | ❌ | ❌ | ❌ | ⚠️ Logged |

**Minimum 2FA required for**: Firm Admin, Partner roles.

---

## 7. User Interface (Web)

```
┌────────────────────────────────────────────────────────────────┐
│ ◆ CostLens Legal  [🏢 Gibson Dunn ▼]  [🔍 Search docs...] [👤]│
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌──────────────┐  ┌────────────────────────────────────────┐  │
│  │ 📁 ALL CASES  │  │  Case: Acme Corp v. State (2026-001)  │  │
│  │ ────────────  │  │───────────────────────────────────────│  │
│  │ 🟢 M&A 2026   │  │  📄 Documents (24)                     │  │
│  │   ├─ Acme     │  │                                        │  │
│  │   └─ BetaCorp │  │  ☐ Type       Name           Date  ↘  │  │
│  │ 🔵 Litigation │  │  ☐ 📄 Pleading  Complaint.pdf  May 20 │  │
│  │   ├─ State v X│  │  ☐ 📊 Exhibit   Exhibit-A.pdf  May 19 │  │
│  │   └─ Smith v Y│  │  ☐ 📝 Draft    Motion_v3.docx May 18 │  │
│  │ 🟡 IP/Trademark│  │  ☐ 📎 Corresp  DemandLetter  May 15 │  │
│  │ ────────────  │  │                      [Upload +]       │  │
│  │ ⚡ Recent      │  └────────────────────────────────────────┘  │
│  │ ⭐ Favorites   │                                            │
│  │ 🗑️ Trash      │  ┌────────────────────────────────────────┐  │
│  └──────────────┘  │  📄 Preview: Complaint.pdf              │  │
│                    │  ┌────────────────────────────────────┐  │  │
│                    │  │  IN THE UNITED STATES DISTRICT...  │  │  │
│                    │  └────────────────────────────────────┘  │  │
│                    │  [Download] [Share] [Send to] [v3]      │  │
│                    │  [Auto-backup: ✅ Active]                 │  │
│                    └────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

---

## 8. Security Controls

| Control | Implementation |
|---------|---------------|
| **Encryption at rest** | AES-256 (SSE-S3 or SSE-KMS) |
| **Encryption in transit** | TLS 1.3 minimum |
| **Access logging** | S3 access logs + CloudTrail (7 year retention) |
| **Data residency** | US-only (us-east-1 primary, us-west-2 backup) |
| **IP whitelist** | Optional per-firm setting |
| **Session timeout** | 15 min idle timeout |
| **Document watermarking** | Optional overlay for shared links |
| **DLP** | Regex patterns for SSN, EIN, credit cards → flag + mask |
| **Legal hold** | Prevents deletion of documents related to active litigation |

---

## 9. Implementation Roadmap

### Phase 1: Core Storage & Upload (Weeks 1–2)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 1 | S3 bucket setup + encryption + versioning + lifecycle policies | Web-Dev |
| 1 | Pre-signed URL upload API | Web-Dev |
| 2 | ClamAV virus scanning pipeline | Web-Dev |
| 2 | Basic folder UI with tree navigation | Web-Dev |

### Phase 2: Backup & Versioning (Weeks 2–4)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 2–3 | Cross-region replication setup | Web-Dev |
| 3 | Version control engine | Web-Dev |
| 3–4 | Version history UI + diff view | Web-Dev |
| 4 | Restore functionality | Web-Dev |

### Phase 3: Auto-Send & Access Control (Weeks 4–6)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 4 | Auto-send notification engine | Web-Dev |
| 5 | Email template system + secure link delivery | Web-Dev |
| 5 | RBAC implementation | Web-Dev |
| 6 | Full-text search (Elasticsearch) | Web-Dev |

---

## 10. Cost Estimate

| Component | Monthly Cost | Setup Cost |
|-----------|-------------|-----------|
| S3 Storage (100 firms × 500MB avg) | $50–$150 | $0 |
| S3 CRR replication | $25–$75 | $0 |
| Elasticsearch | $100–$300 | $500–$1,000 |
| ClamAV (self-hosted) | $0 | $200 |
| Email (SendGrid/SES) | $20–$100 | $0 |
| Lambda processing | $10–$50 | $0 |
| **TOTAL** | **$205–$675/mo** | **$700–$1,200** |

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: Platform Expansion V2 Item #4 (Document Management)*