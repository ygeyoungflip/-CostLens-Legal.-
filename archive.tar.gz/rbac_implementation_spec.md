# Role-Based Access Control (RBAC) Implementation Specification

This specification provides the technical details required to implement the RBAC system for CostLens Legal.

## 1. Database Schema (PostgreSQL)

```sql
-- Core tables for RBAC
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) UNIQUE NOT NULL, -- e.g., 'firm_admin', 'attorney', 'paralegal', 'client'
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resource VARCHAR(50) NOT NULL, -- e.g., 'matters', 'billing', 'documents'
    action VARCHAR(50) NOT NULL,   -- e.g., 'create', 'read', 'update', 'delete'
    UNIQUE(resource, action)
);

CREATE TABLE role_permissions (
    role_id UUID REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE user_roles (
    user_id UUID NOT NULL, -- Link to Auth provider ID
    firm_id UUID NOT NULL,
    role_id UUID REFERENCES roles(id),
    PRIMARY KEY (user_id, firm_id)
);

-- Matter-specific assignments (for granular staff/client access)
CREATE TABLE matter_assignments (
    user_id UUID NOT NULL,
    matter_id UUID NOT NULL,
    access_level VARCHAR(20) DEFAULT 'read', -- 'read', 'write', 'owner'
    PRIMARY KEY (user_id, matter_id)
);
```

## 2. JWT Claims Structure

To minimize database lookups, the following claims should be injected into the user's JWT upon login:

```json
{
  "sub": "user_123456789",
  "email": "attorney@firm-alpha.com",
  "app_metadata": {
    "firm_id": "firm_uuid_001",
    "role": "attorney"
  },
  "user_metadata": {
    "full_name": "Jane Doe"
  }
}
```

## 3. Middleware Authorization Flow

The backend should implement a middleware (e.g., `authorize(resource, action)`) that follows this logic:

1.  **Extract JWT:** Parse the JWT from the `Authorization: Bearer <token>` header.
2.  **Validate Token:** Verify signature and expiration.
3.  **Check Firm ID:** Ensure the request context includes a `firm_id` that matches the JWT claim.
4.  **Role Verification:**
    *   If `role == 'system_admin'`, grant access to everything.
    *   If `role == 'firm_admin'`, grant access to all resources within their `firm_id`.
5.  **Permission Check:** Query `role_permissions` for the user's role to see if `resource:action` is allowed.
6.  **Matter Scoping (Object-Level Security):**
    *   If the resource is a specific **Matter** or **Document** associated with a matter:
    *   Check if the user has an entry in `matter_assignments` for that `matter_id`.
    *   If no entry exists (and user is not a Firm Admin), deny access.

## 4. API Endpoint Permissions Table

| Endpoint | Method | Resource | Action | Allowed Roles |
| :--- | :--- | :--- | :--- | :--- |
| `/api/matters` | GET | matters | read | Admin, Partner, Associate, Paralegal |
| `/api/matters` | POST | matters | create | Admin, Partner, Associate |
| `/api/matters/:id` | PATCH | matters | update | Admin, Partner, Associate, Assigned Paralegal |
| `/api/billing` | GET | billing | read | Admin, Partner |
| `/api/billing/pay` | POST | billing | pay | Client (Assigned Matter) |
| `/api/documents` | POST | documents | create | All Staff, Assigned Client |
| `/api/team/invite` | POST | team | manage | Admin, Partner |
| `/api/reports/compliance` | GET | compliance | read | Admin, Partner |

## 5. Seed Data

```sql
INSERT INTO roles (name, description) VALUES 
('system_admin', 'Global platform administrator'),
('firm_admin', 'Law firm managing partner/owner'),
('attorney', 'Associate or Senior Attorney'),
('paralegal', 'Support and administrative staff'),
('client', 'External client with access to own case');

INSERT INTO permissions (resource, action) VALUES 
('matters', 'create'), ('matters', 'read'), ('matters', 'update'),
('billing', 'read'), ('billing', 'pay'),
('documents', 'create'), ('documents', 'read'),
('compliance', 'read'),
('team', 'manage');
```
