# CostLens Legal — User Access Control & Video Chat Design

This document details the Role-Based Access Control (RBAC) system and the Live Video Chat implementation specification for the CostLens Legal platform.

## 1. Role Definitions

### A. Super Admin (CTO / Platform Level)
*   **Definition:** The ultimate authority on the platform.
*   **Scope:** Global (Across all law firms).
*   **Key Capabilities:**
    *   System health monitoring and global configuration.
    *   Managing and auditing all law firm accounts.
    *   Configuring Stripe Connect (routing the 10% platform fee).
    *   Full data access for compliance and support purposes.

### B. Firm Admin (Partner / Firm Level)
*   **Definition:** The owner or managing partner of a specific law firm.
*   **Scope:** Firm-wide.
*   **Key Capabilities:**
    *   Managing the firm's team (Inviting/Removing Attorneys and Paralegals).
    *   Full access to all Firm Matters, Financial Dashboards, and Compliance Reports.
    *   Managing firm-level billing and insurance verification.
    *   Customizing firm branding and color coding.

### C. Attorney (Staff Level)
*   **Definition:** Licensed legal professionals within a firm.
*   **Scope:** Assigned Matters.
*   **Key Capabilities:**
    *   Managing assigned cases/matters.
    *   Using document drafting and collaboration tools.
    *   Time entry and cost tracking.
    *   Initiating live video calls with clients or team members.

### D. Paralegal (Support Level)
*   **Definition:** Administrative and support staff.
*   **Scope:** Assigned Matters.
*   **Key Capabilities:**
    *   Document management and organization.
    *   Updating case status and administrative tasks.
    *   Basic time entry (if authorized).
    *   *No access* to firm-wide financial dashboards or user management.

### E. Client / Guest (External Level)
*   **Definition:** The law firm's clients or external stakeholders.
*   **Scope:** Specific Matter (Own case only).
*   **Key Capabilities:**
    *   Viewing case status and progress badges.
    *   Securely uploading documents.
    *   Paying invoices via Stripe.
    *   Joining video calls when invited by the firm.

---

## 2. Permission Matrix

| Feature | Super Admin | Firm Admin | Attorney | Paralegal | Client |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Global Dashboard** (All Firms) | Full | No | No | No | No |
| **Firm Dashboard** (Financials) | Full | Full | Partial* | No | No |
| **Case Management** | Full | Full | Read/Write | Read/Write | View |
| **Billing & Stripe** | Full | Full | No | No | Pay Only |
| **Document Management** | Full | Full | Read/Write | Read/Write | Own Only |
| **Verification System** | Full | Full | View | No | View Status |
| **Compliance Reports** | Full | Full | View | No | No |
| **Team Management** | Full | Full | No | No | No |
| **Live Video Chat** | View Only | Full | Full | Full | Joined Only |

*\*Attorneys can see their own efficiency/utilization metrics.*

---

## 3. Access Control Flow

### User Assignment & Invitation
1.  **Creation:** The **Super Admin** initializes a Law Firm account and assigns the first **Firm Admin**.
2.  **Invitation:** The **Firm Admin** invites team members (Attorneys/Paralegals) via email using the `Team Management` module.
3.  **Role Selection:** The Firm Admin selects the role (Attorney/Paralegal) during the invitation process.
4.  **Acceptance:** The invited user receives a secure link, sets their password, and is automatically granted permissions based on their role.

### Permission Escalation
*   Permissions do not "auto-escalate."
*   A user (e.g., Paralegal promoted to Associate) must have their role updated manually by the **Firm Admin** or **Super Admin**.
*   All role changes are logged in the `Audit Trail` for compliance.

### Multi-Tenancy & Data Isolation
*   All database queries are scoped by `firm_id`.
*   Users are restricted to matters where they are explicitly listed in the `Matter_Assignments` table (except Firm Admins who see all firm matters).

---

## 4. Live Video Chat Specification

To facilitate real-time collaboration between lawyers and clients, CostLens Legal will implement an embedded video chat system.

### Recommended Approach: Daily.co (WebRTC)
**Daily.co** is recommended over building a custom WebRTC stack due to its:
*   **Time-to-Market:** The "Daily Prebuilt" component can be embedded in minutes.
*   **Security:** HIPAA and SOC2 compliance ready, with end-to-end encryption support.
*   **Scalability:** Handles global signaling and TURN/STUN infrastructure automatically.

### Feature Spec:
1.  **Context-Aware Rooms:** Each Matter in the system is assigned a unique, transient video room URL.
2.  **In-App Integration:** The video window appears as an overlay or sidebar within the Case view, allowing users to draft documents and chat simultaneously.
3.  **Permissions:** 
    *   Only **Firm Admins** and **Attorneys** can "Start" a call.
    *   **Clients** join via a secure, authenticated link from their portal.
4.  **Recording:** Calls can be recorded directly to secure platform storage (S3) for compliance and audit purposes, subject to firm-level settings.
5.  **Screen Sharing:** Native support for sharing legal documents during drafting sessions.

---
*Authored by: CostLens Cost Agent | May 2026*
