# Wave 3: Boutique Litigation Outreach Templates (Updated)

## 1. The "ROI Guarantee" Hook
We are now leading with a high-trust, low-risk offer for litigation boutiques:
> **"Identify 15% in case cost savings within 30 days, or your first month is free."**

## 2. Outreach Templates

### Email Template: High-Margin Boutique Efficiency
**Subject: Stopping the Margin Leak: [Firm Name]'s Efficiency Plan**

Hi [Name],

I've been following [Firm Name]'s success in [Practice Area]. For high-stakes litigation boutiques, we know that administrative drag is the #1 enemy of your margins.

We’ve just launched our **Solo/Boutique Tier ($1,000/mo)** specifically for firms of your size. Our "Cost Intelligence" platform identifies the top 3 drivers of case inefficiency and flags redundant software spend.

**Our Guarantee:** If we don't identify a 15% reduction in your matter processing costs within the first 30 days, your first month is free.

Beyond the savings, you’ll receive the **"CostLens Verified" badge**, signalling to your corporate clients that your firm is insured, screened, and operating at peak benchmarked efficiency.

Would you be open to a 10-minute demo to see your specific ROI projection?

Best,

[My Name]
Growth & Sales Lead, CostLens Legal

---

### LinkedIn Message: The Verified Boutique Advantage
Hi [Name], seeing great things from [Firm Name]. We're helping boutiques like yours use "Cost Intelligence" to reclaim **20% of billable capacity** from admin tasks. We've just opened our **$1,000/mo Solo Tier** which includes a **"15% Savings or First Month Free"** guarantee. We also handle your business verification so you can display the "CostLens Verified" status to clients. Would love to share the 10-min walkthrough with you.
