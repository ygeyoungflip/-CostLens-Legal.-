# CostLens Legal — User Access Control & RBAC Design

This document outlines the Role-Based Access Control (RBAC) system for the CostLens Legal platform, ensuring data security and granular permission management across different user tiers.

## 1. User Roles

The system recognizes five primary roles, categorized by their scope of authority:

### A. System Admin (Platform Level)
*   **Scope:** Global platform management.
*   **Key Responsibilities:** System health monitoring, global configuration, managing law firm accounts, platform-wide billing/Stripe Connect settings.
*   **Access:** Full read/write access to all data across the platform.

### B. Firm Admin / Partner (Firm Level)
*   **Scope:** Manage an entire law firm's workspace.
*   **Key Responsibilities:** Firm configuration (branding, color coding), user management within the firm, high-level financial reporting, software licensing optimization approval.
*   **Access:** Full access to all firm matters, documents, and financial data.

### C. Associate Attorney (Staff Level)
*   **Scope:** Professional legal work and matter management.
*   **Key Responsibilities:** Managing assigned cases, time/cost entry, document drafting, client communication.
*   **Access:** Read/write access to assigned matters; access to their own efficiency dashboards.

### D. Paralegal / Support (Staff Level)
*   **Scope:** Administrative and document support.
*   **Key Responsibilities:** Document management, status updates, basic time entry, case administration.
*   **Access:** Restricted access to assigned matters; focus on document and task management.

### E. Client (External Level)
*   **Scope:** Restricted, case-specific access.
*   **Key Responsibilities:** Providing documentation, tracking case status, paying invoices.
*   **Access:** Access limited to their own matters; "Guest" view of case progress; invoice payment portal.

---

## 2. Permission Matrix

| Feature / Action | Admin | Partner | Associate | Paralegal | Client |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Firm Management** | | | | | |
| Configure Firm Settings/Branding | Yes | Yes | No | No | No |
| Manage Firm Users (Invite/Remove) | Yes | Yes | No | No | No |
| **Matter Management** | | | | | |
| Create New Matter | Yes | Yes | Yes | No | No |
| View All Firm Matters | Yes | Yes | No* | No* | No |
| View/Edit Assigned Matters | Yes | Yes | Yes | Yes | Yes (View) |
| **Financials & Costs** | | | | | |
| View Firm-wide Financial Dashboards | Yes | Yes | No | No | No |
| View Matter Cost/Profitability | Yes | Yes | Yes | No | No |
| Manage Billing & Stripe Settings | Yes | Yes | No | No | No |
| Pay Invoices | No | No | No | No | Yes |
| **Documents & Tools** | | | | | |
| Manage Matter Documents | Yes | Yes | Yes | Yes | Yes (Own) |
| Use Document Drafting Tool | Yes | Yes | Yes | Yes | No |
| Access Live Video Chat | Yes | Yes | Yes | Yes | Yes (Invited) |
| **Compliance & Verification** | | | | | |
| Manage Verification Settings | Yes | Yes | No | No | No |
| View Audit Trails | Yes | Yes | Yes | No | No |

*\* Assigned matters only. Partners can see all; Associates/Paralegals see what they are added to.*

---

## 3. Data Isolation Policy

*   **Firm Isolation:** No user (except System Admin) shall have access to data belonging to a different law firm.
*   **Case Isolation:** Support staff and external clients are restricted to specific matters via an "Assignments" table in the database.
*   **Encrypted Storage:** All document access is mediated through an authorization service that validates the user's RBAC role before generating a pre-signed URL for the encrypted storage (S3/Box).

---

## 4. Implementation Strategy (Phase 2)

1.  **JWT Claims:** Include the user's `role` and `firm_id` in the JWT token for stateless authorization.
2.  **Middleware:** Implement a permissions-check middleware in the API layer that validates `role_level` against required endpoints.
3.  **Audit Logging:** Every administrative action (user changes, permission changes) must be logged with the actor's ID and timestamp for compliance.
