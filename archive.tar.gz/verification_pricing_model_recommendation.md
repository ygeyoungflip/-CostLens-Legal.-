# CostLens Legal — Verification Pricing Model Recommendation (Tier-Aligned Update)

**Owner:** FinOps & Licensing Agent  
**Updated:** May 27, 2026  
**Pricing Source:** `/home/team/shared/pricing_model.md`

---

## 1) Official Tier Prices (Now Live)

| Tier | Monthly Price |
|---|---:|
| Solo / Starter | $1,000 |
| Growth / Mid-Size | $7,000 |
| Enterprise / Large | $10,000 |
| Ultra-Premium | $100,000–$500,000 |

---

## 2) Verification Cost Assumptions (Base COGS)

Per-check base COGS used in this model:
- Identity check: **$1.20**
- Business check: **$3.00**
- Insurance check: **$2.00**
- Background check: **$32.00**

These align with current verification financial assumptions and should be refreshed when final contracted quote cards are signed.

---

## 3) Included Verification by Tier (What’s Included)

| Tier | Included Checks / Month | Included Verification COGS / Month |
|---|---|---:|
| Solo / Starter ($1K) | 5 identity, 2 business, 1 insurance, 0 background | **$14** |
| Growth / Mid-Size ($7K) | 25 identity, 10 business, 5 insurance, 1 background | **$102** |
| Enterprise / Large ($10K) | 60 identity, 30 business, 20 insurance, 3 background | **$298** |
| Ultra-Premium ($100K–$500K) | Custom high-volume baseline (example: 500 identity, 250 business, 150 insurance, 30 background) | **$2,610** (example baseline) |

### Overage policy (recommended)
- Identity: **$3/check**
- Business: **$7/check**
- Insurance: **$5/check**
- Background: **pass-through + 20–25% platform fee**

---

## 4) Stripe 10% Routing Confirmation (All Tiers)

Yes — percentage routing works consistently across all tiers because it is formula-based:

- `application_fee_amount = round(invoice_total * 0.10)`

| Tier Price | 10% Routed Fee |
|---:|---:|
| $1,000 | $100 |
| $7,000 | $700 |
| $10,000 | $1,000 |
| $100,000 | $10,000 |
| $500,000 | $50,000 |

This logic remains stable regardless of price tier and scales linearly.

---

## 5) Unit Economics by Tier (Monthly)

Assumptions:
- Gross subscription price = list tier price
- 10% fee routed via Stripe Connect to CTO account
- Included verification COGS deducted from remaining tier amount

### 5.1 Tier unit economics

| Tier | Gross Price | 10% Routed Fee | Net After 10% | Included Verification COGS | Contribution After COGS | Contribution Margin on Gross |
|---|---:|---:|---:|---:|---:|---:|
| Solo / Starter | 1,000 | 100 | 900 | 14 | **886** | **88.6%** |
| Growth / Mid-Size | 7,000 | 700 | 6,300 | 102 | **6,198** | **88.5%** |
| Enterprise / Large | 10,000 | 1,000 | 9,000 | 298 | **8,702** | **87.0%** |
| Ultra-Premium (low) | 100,000 | 10,000 | 90,000 | 2,610 | **87,390** | **87.4%** |
| Ultra-Premium (high) | 500,000 | 50,000 | 450,000 | 8,400* | **441,600** | **88.3%** |

\*High-end Ultra example assumes expanded included verification pack at scale.

### 5.2 Verification COGS load vs price

| Tier | Included Verification COGS as % of Gross Price |
|---|---:|
| Solo / Starter | 1.4% |
| Growth / Mid-Size | 1.5% |
| Enterprise / Large | 3.0% |
| Ultra-Premium (low example) | 2.6% |
| Ultra-Premium (high example) | 1.7% |

Interpretation: verification inclusion remains financially sustainable across all live tiers with current assumptions.

---

## 6) Updated Pricing Recommendation (Aligned to Live Tiers)

### Recommended go-forward model
1. Keep verification **included at baseline per tier** (table above).
2. Keep high-cost checks (especially background and custom compliance checks) **metered/pass-through above included thresholds**.
3. Maintain 10% Stripe routing rule across all invoices (already compatible with all tiers).
4. Revisit included check volumes quarterly using realized utilization and verification COGS drift.

This matches the live price architecture ($1K/$7K/$10K/$100K–$500K) while preserving margin discipline.

---

## 7) Guardrails and Monitoring

- Blended verification COGS should remain below planned inclusion envelope by tier.
- Alert if verification COGS per tier rises >15% month-over-month.
- Alert if background checks exceed planned mix threshold.
- Reprice overage rates if contracted vendor costs move materially.

Track in:
- `/home/team/shared/roi_calculation_template.md`
- `/home/team/shared/finops_dashboard_template.md`

