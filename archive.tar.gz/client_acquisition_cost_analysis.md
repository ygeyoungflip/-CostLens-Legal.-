# CostLens Legal — Client Acquisition Cost Analysis Framework

**Owner:** FinOps & Licensing Agent (with Growth/Sales coordination)  
**Date:** May 20, 2026  
**PRD Alignment:** Input data includes client acquisition costs; core goal #7 is lowering CAC.

---

## 1) Objective

Create a standardized CAC framework that tracks acquisition cost drivers, benchmarks CAC by case type, and ties every optimization action to ROI.

---

## 2) Coordination with Growth/Sales Lead

Shared responsibilities:
- **Growth/Sales Lead:** funnel volume, channel attribution, outreach effort, referrals, close rates
- **FinOps:** cost allocation, tooling spend, payback/LTV:CAC calculations, variance controls

Data handoff cadence:
- Weekly CAC pulse (channel + signups)
- Monthly finance reconciliation

---

## 3) Fully Loaded CAC Formula

### Blended CAC
`CAC = (Marketing Spend + Sales Labor Cost + Referral Fees + Acquisition Tooling + Pre-sales Support + Onboarding Cost) / New Signed Firms`

### Channel CAC
`Channel CAC = channel_total_cost / channel_signups`

### Case-Type CAC (required for product benchmarking)
`CaseType CAC = total_acquisition_cost_for_case_type / signed_firms_for_case_type`

---

## 4) Cost Buckets (Required)

1. Marketing spend (paid campaigns, content, events, sponsorships)
2. Sales time cost (SDR/AE loaded hourly cost x hours)
3. Referral/partner fees
4. Sales tooling allocation (CRM, sequencing, enrichment, dialers)
5. Pre-sales/demo support
6. Onboarding/activation cost (implementation and training)

---

## 5) Benchmarking by Case Type

Track CAC by these example case-type segments (extend as needed):
- Litigation
- Employment/Labor
- Corporate/Transactional
- IP/Patent
- Compliance/Regulatory

For each segment, track:
- Signups
- Blended and channel CAC
- Average sales cycle length
- Conversion rate (demo → close)
- Payback months
- LTV:CAC ratio

---

## 6) Thresholds & Alerts

- **High CAC alert:** case-type CAC > target by >20%
- **Payback risk:** CAC payback >6 months
- **Efficiency risk:** LTV:CAC <3.0x
- **Channel inefficiency:** channel CAC 25% above blended CAC for 2 consecutive periods

Action triggers:
- Reallocate spend toward lower-CAC channels
- Tighten qualification for high-CAC segments
- Improve demo-to-close conversion for weak segments
- Reduce onboarding cost/time for slow-payback segments

---

## 7) ROI Tie-In (Required)

Use `/home/team/shared/roi_calculation_template.md` for each CAC optimization initiative.

Example initiative types:
- Referral program redesign
- Paid channel reduction/reallocation
- Sales tooling consolidation
- Faster onboarding playbook

Minimum outputs:
- Baseline CAC and target CAC
- Gross and net annual savings
- Implementation cost
- Payback months
- Net ROI

---

## 8) Data Model Fields (for dashboard ingestion)

Minimum fields per period:
- period_start, period_end
- case_type
- channel
- marketing_cost_usd
- sales_labor_cost_usd
- referral_fees_usd
- tooling_cost_usd
- onboarding_cost_usd
- total_acquisition_cost_usd
- new_firms_signed
- cac_usd
- payback_months
- ltv_cac_ratio

Template file for capture:
- `/home/team/shared/cac_tracking_template.csv`

---

## 9) Reporting Cadence

- Weekly: CAC pulse by channel and case type
- Monthly: finance-reconciled CAC and payback
- Quarterly: benchmark reset and spend-mix reforecast

