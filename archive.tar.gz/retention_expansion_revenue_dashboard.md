# CostLens Legal — Retention & Expansion Revenue Dashboard Design

**Owner:** FinOps & Licensing Agent  
**Date:** May 27, 2026  
**Task:** Build retention/expansion revenue tracking dashboard design.

---

## 1) Dashboard Objective

Track recurring revenue quality, not just new signups:
1. **Retention** (logo + revenue)
2. **Expansion** (upsell/cross-sell)
3. **Contraction/churn** risks
4. **Net revenue durability** toward 50-firm goal

---

## 2) Baseline Snapshot (Current Confirmed Pipeline)

Using `/home/team/shared/pipeline_tracker.csv` (confirmed rows):
- Confirmed firms: **7**
  - Enterprise: **5**
  - Growth: **1**
  - Solo: **1**

Using live tier prices (`pricing_model.md`):
- MRR baseline = `5*10,000 + 1*7,000 + 1*1,000 = $58,000`
- ARR baseline = `$58,000 * 12 = $696,000`

---

## 3) Core KPI Dictionary

| KPI | Formula | Target/Guardrail |
|---|---|---|
| Ending MRR | `starting_mrr + new_mrr + expansion_mrr - contraction_mrr - churn_mrr` | Upward trend |
| Logo Retention % | `(customers_start - churned_customers) / customers_start` | >=90% monthly |
| GRR % (Gross Revenue Retention) | `(starting_mrr - churn_mrr - contraction_mrr) / starting_mrr` | >=90% |
| NRR % (Net Revenue Retention) | `(starting_mrr - churn_mrr - contraction_mrr + expansion_mrr) / starting_mrr` | >=110% target |
| Expansion MRR | `upsell_mrr + add_on_mrr + overage_mrr` | increasing |
| Churn MRR | `sum(mrr_lost_from_canceled_accounts)` | <=3% of starting MRR/month |
| Contraction MRR | `sum(downgrade_mrr_loss)` | <=2% monthly |
| Revenue per Firm (ARPA) | `ending_mrr / active_firms` | stable-to-up |
| Payback on Expansion Motion | `expansion_program_cost / incremental_expansion_mrr` | <=6 months |

---

## 4) Dashboard Layout (Suggested)

### A) Executive Row
- Starting MRR
- Ending MRR
- New MRR
- Expansion MRR
- Churn + Contraction MRR
- NRR % and GRR %

### B) Revenue Waterfall
- Starting MRR
- + New
- + Expansion
- - Contraction
- - Churn
- = Ending MRR

### C) Cohort & Tier Retention
- Monthly cohort heatmap (logo retention)
- NRR by cohort
- Retention by pricing tier (Solo/Growth/Enterprise/Ultra)

### D) Expansion Performance
- Upsell conversion by tier
- Add-on attach rate
- Expansion MRR by driver (seat growth, modules, verification overages)

### E) Risk Monitoring
- Accounts at churn risk (usage drop, unresolved tickets, payment failures)
- Renewal risk list (next 90 days)

---

## 5) Minimum Data Model

### `revenue_monthly`
- month
- firm_id
- tier
- starting_mrr
- new_mrr
- expansion_mrr
- contraction_mrr
- churn_mrr
- ending_mrr
- account_status

### `firm_lifecycle_events`
- event_date
- firm_id
- event_type (new, upsell, downgrade, cancel, reactivate)
- mrr_delta
- reason_code

### `expansion_program_costs`
- month
- program_name
- spend_usd
- attributable_expansion_mrr

---

## 6) Alert Logic

- NRR below 100% for 2 consecutive months -> alert
- Churn MRR >3% of starting MRR in any month -> alert
- Contraction MRR >2% monthly -> alert
- Enterprise-tier downgrade/cancel -> immediate executive alert

---

## 7) Operating Cadence

- Weekly: churn-risk review + expansion opportunity list
- Monthly close: MRR/NRR/GRR publication and variance commentary
- Quarterly: tier packaging and upsell strategy recalibration

---

## 8) Implementation Notes

- Join `pipeline_tracker.csv` tier/status data with billing ledger once Stripe recurring billing tables are live.
- Keep a single source of truth for “active firm” and tier history to avoid MRR double-counting.

