# CostLens Legal — FinOps + Ops KPI Alignment Sheet

**Owners:** FinOps & Licensing Agent + Operations Optimization Agent  
**Date:** May 20, 2026  
**First joint reporting cycle:** June 2026 month-end  
**Goal:** One shared metric layer so software savings and operational savings roll up cleanly into the same ROI dashboard.

---

## 1) Joint KPI Dictionary (Source of Truth)

| KPI | Definition | Formula | Data Source | Owner | Cadence |
|---|---|---|---|---|---|
| Licensing Spend (Annualized) | Annual run-rate software spend from active contracts | `sum(active_contract_monthly_cost*12)` | AP invoices + contract register | FinOps | Monthly |
| Active Seat Ratio | % of paid seats active in trailing 30 days | `active_seats_30d / paid_seats` | Vendor admin exports | FinOps + IT | Weekly |
| Duplicate Tool Count | Number of capabilities with >1 paid platform in active use | count(capability where active_tools > 1) | Tool inventory + usage logs | FinOps | Monthly |
| Software Savings Realized | Verified reduction vs locked baseline | `baseline_spend - current_run_rate` | Finance reconciliation | FinOps + Finance | Monthly |
| Overhead Spend (Non-software) | Annualized overhead excluding software line | `total_overhead - software_overhead` | GL + ops budget | Ops | Monthly |
| Overhead % of Revenue | Operating overhead intensity | `total_overhead / revenue` | Finance P&L | Ops + Finance | Monthly |
| Billing Cycle Time | Average days from work completed to invoice issued | `avg(invoice_date - work_complete_date)` | Billing system | Ops | Weekly |
| DSO | Average days to collect invoices | `AR / avg_daily_revenue` | AR ledger | Ops + Finance | Weekly |
| Admin-to-Billable Ratio | Time split between admin and billable work | `admin_hours : billable_hours` | Timekeeping + workforce reports | Ops | Monthly |
| Portfolio Net ROI | Net ROI across all active initiatives | `(sum(year1_net_benefit)/sum(implementation_cost))*100` | Initiative ROI registry | FinOps + Ops | Monthly |

---

## 2) Baselines and Targets (Locked for This Cycle)

| KPI | Baseline | Target | Deadline |
|---|---:|---:|---|
| Licensing Spend (fixed-seat) | $310,200 | $263,640 | August 20, 2026 |
| Software Savings Realized | $0 | $46,560 annualized | August 20, 2026 |
| Variable E-discovery Spend | $66,000 | $56,100 | September 30, 2026 |
| Overhead % of Revenue | 40.0% | 36.0% | September 30, 2026 |
| Billing Cycle (invoice lag days) | 18 days | 14 days (20% reduction) | August 31, 2026 |
| DSO | 52 days | 35 days | September 30, 2026 |
| Admin-to-Billable Ratio | 43:57 | 34:66 (phase-1) | September 30, 2026 |
| Duplicate Tool Count | 4 | <=2 | August 20, 2026 |

---

## 3) Combined Reporting Structure

### Executive roll-up sections
1. **Run-rate savings achieved** (software + non-software overhead)
2. **Cash acceleration achieved** (billing cycle + DSO)
3. **Capacity recapture achieved** (admin-to-billable shift)
4. **ROI quality** (gross savings, net savings, payback, confidence)

### Required shared dimensions
- Month
- Practice group
- Initiative ID
- Cost category (software / labor / facilities / billing)
- Confidence level (High / Medium / Low)

---

## 4) Reconciliation Rules (Avoid Metric Drift)

1. Baseline values are immutable after lock date unless jointly approved by FinOps + Ops + Finance.
2. A savings claim is “realized” only when finance ledger and operational metric both confirm it.
3. No double-counting: software savings that already reduce overhead cannot be counted again in another track.
4. All initiative updates must include gross savings, implementation cost, and net savings.
5. Exception users (dual-stack tooling) must be tagged and excluded from core consolidation success rates.

---

## 5) Operating Cadence & Ownership

- **Weekly (every Monday):** anomalies review (inactive seats, billing delays, DSO spikes)
- **Biweekly (1st/15th):** vendor action + process action checkpoint
- **Monthly close (last business day):** finalized KPI pack and ROI reconciliation
- **Quarterly review (Sep 30, 2026):** target attainment and next-quarter reforecast

Meeting owner rotation:
- Week 1/3: FinOps chair
- Week 2/4: Ops chair

---

## 6) Immediate Next Steps

1. Ops-agent to confirm shared definitions for Billing Cycle, DSO, and Admin-to-Billable by **May 23, 2026**.
2. FinOps agent to publish first license telemetry extract by **May 24, 2026**.
3. Joint dry run of dashboard roll-up by **May 28, 2026**.
4. Leadership-ready June report package due **June 30, 2026**.

