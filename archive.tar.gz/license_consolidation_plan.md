# CostLens Legal — License Consolidation Plan

**Date:** May 20, 2026  
**Goal:** Deliver at least **10% licensing cost reduction** with controlled migration risk and measurable ROI.

---

## 1) Target-State Tooling Strategy

### Consolidation Principles
1. One primary platform per capability (chat, meetings, e-sign, reporting).
2. Dual-stack only when required for client/regulatory constraints.
3. Every paid seat must meet utilization threshold (>=60% active use over trailing 60 days).
4. Renewals require ROI evidence and owner sign-off.

### Proposed Target Stack
- **Meetings/Collaboration:** Microsoft Teams as default; limited Zoom carve-out
- **E-signature:** Adobe Sign as default; reduced DocuSign footprint only for exceptions
- **Document Review / E-discovery:** Define default platform by matter complexity tier to prevent dual-platform spend
- **Reporting:** Power BI retained but right-sized to core analyst users
- **Automation:** Zapier retained for approved high-ROI workflows only

---

## 2) Consolidation Workstreams

| Workstream | Current State | Target State | Owner | Timeline | Savings Estimate |
|---|---|---|---|---|---:|
| W1: Meeting Platform | Zoom + Teams active | Teams default + 10 Zoom host seats | IT + Ops | Weeks 1–6 | $19,200 |
| W2: E-sign Platform | DocuSign + Adobe overlap | Adobe Sign default, DocuSign minimized | Legal Ops | Weeks 2–8 | $13,230 |
| W3: Seat Rightsizing | Idle seats across BI/research/automation | 60-day utilization policy + monthly cleanup | FinOps | Weeks 1–12 | $9,180 |
| W4: Slack Tier Optimization | Broad Pro seat assignment | Paid seats for high-collab users only | Ops + Team Leads | Weeks 4–10 | $4,950 |
| W5: E-discovery Rationalization *(incremental)* | Relativity + Everlaw overlap on mid-tier matters | Matter-tier routing + volume-tier negotiation | Legal Ops + FinOps | Weeks 3–12 | $9,900 |

**Total planned savings (fixed-seat baseline):** **$46,560/year**  
**Incremental variable-spend upside:** **$9,900/year**

---

## 3) Vendor Negotiation Playbook

### Renewal Tactics
- Ask for co-termination across products to align negotiation windows.
- Request step-down pricing for reduced seat volume.
- Seek migration credits and training support when consolidating to remaining vendor footprint.
- Benchmark alternatives before final renewal decision to improve leverage.

### Commercial Guardrails
- No auto-renew without 90-day review.
- Include “flex down” clause for seat reductions at quarter boundaries.
- Require SKU-level usage reporting in contract terms.
- Cap annual uplift percentage in multiyear agreements.

---

## 4) Implementation Roadmap (90 Days)

### Phase 1 — Validate & Prepare (Weeks 1–2)
- Confirm invoice-level baseline spend by SKU
- Identify departmental power users and exception needs
- Publish migration communication plan

### Phase 2 — Pilot (Weeks 3–5)
- Pilot Teams-first meetings for one legal practice group
- Pilot Adobe Sign templates for routine agreements
- Measure cycle time, exception rate, and user satisfaction

### Phase 3 — Scale (Weeks 6–10)
- Expand to all internal teams
- Execute seat cleanup wave 1 + wave 2
- Reissue role-based access and SOPs

### Phase 4 — Lock Savings (Weeks 11–13)
- Finalize contract amendments and license true-downs
- Disable redundant SKUs
- Publish realized savings and ROI report

---

## 5) Governance Model

- **Monthly FinOps Review:** utilization, cost trends, renewal pipeline
- **Quarterly License Committee:** approve/deny new software and exceptions
- **Control Metrics:**
  - License spend vs baseline
  - Paid seats vs active users
  - Duplicative tool count by capability
  - Savings realized vs target

---

## 6) Dependencies & Cross-Team Inputs

- **Operations Optimization Agent:** validate workflow impact and billing-cycle effects; align shared SaaS overhead KPIs (license spend, active-seat ratio, duplicate-tool count, realized savings)
- **Cost Analysis Agent:** integrate software savings into per-case cost models
- **Growth & Sales Lead:** ensure client-facing communication and tooling do not hurt conversion/onboarding

