# Document Drafting Tool Specification

## In-Browser Editor, Template Library & Collaborative Drafting with Version History

**Prepared by:** Operations Optimization Agent  
**Date:** May 22, 2026  
**Alignment:** Platform Expansion V2 Item #8 (Document Drafting Tool)

---

## 1. Product Overview

An in-browser document editor purpose-built for legal document creation — with template library, collaborative drafting, version history, and auto-save — fully integrated with the CostLens Legal Document Management System.

### User Personas
| Persona | Needs | Editor Features Used |
|---------|-------|---------------------|
| **Associate (primary)** | Drafting motions, briefs, contracts from templates | Templates, formatting, citations, auto-save |
| **Partner (reviewer)** | Reviewing, commenting, approving drafts | Track changes, comments, approval workflow |
| **Paralegal (supporter)** | Formatting, clause insertion, filing prep | Clause library, formatting, table of authorities |
| **Firm Admin** | Managing templates, user permissions | Template library admin, RBAC |

---

## 2. Core Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  DOCUMENT DRAFTING TOOL                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────────┐  ┌────────────────┐  ┌─────────────┐ │
│  │  Editor Engine    │  │  Template      │  │  Clause     │ │
│  │  (TipTap/         │  │  Library       │  │  Library    │ │
│  │   ProseMirror)    │  │                │  │             │ │
│  └────────┬─────────┘  └───────┬────────┘  └──────┬──────┘ │
│           │                     │                  │        │
│  ┌────────▼─────────────────────▼──────────────────▼─────┐ │
│  │                 Document State Manager                  │ │
│  │           (Operational Transform / CRDT — for          │ │
│  │            real-time collaboration)                     │ │
│  └────────────────────────┬──────────────────────────────┘ │
│                           │                                 │
│  ┌────────────────────────▼──────────────────────────────┐ │
│  │               Auto-Save + Version Engine               │ │
│  │     (Save every 30s + manual checkpoint versions,     │ │
│  │      diff engine, version tree, restore)               │ │
│  └────────────────────────┬──────────────────────────────┘ │
│                           │                                 │
│  ┌────────────────────────▼──────────────────────────────┐ │
│  │                DMS Integration Layer                    │ │
│  │  (Save to case folder, load templates, auto-backup)   │ │
│  └────────────────────────────────────────────────────────┘ │
```

### Tech Stack
| Component | Technology | Justification |
|-----------|-----------|---------------|
| **Editor engine** | TipTap (ProseMirror-based) | Extensible, open-source, legal formatting plugins available |
| **Real-time collaboration** | Y.js + WebSockets | CRDT-based — no conflict resolution needed |
| **Auto-save** | Background XHR (every 30s) | Non-blocking, user sees "Saved" indicator |
| **Version engine** | Custom (diff + snapshot hybrid) | Store full snapshots for named versions, diffs for auto-saves |
| **Template engine** | Handlebars + custom merge fields | Simple syntax, extensible for legal documents |
| **Search** | Elasticsearch (shared with DMS) | Cross-document search |

---

## 3. In-Browser Editor Features

### 3.1 Core Editor

| Feature | Specification | Priority |
|---------|--------------|----------|
| **Rich text formatting** | Bold, italic, underline, strikethrough, superscript | P0 |
| **Headings** | H1–H6 — legal document hierarchy (Caption, Title, Heading, Subheading) | P0 |
| **Lists** | Ordered, unordered, nested up to 5 levels | P0 |
| **Tables** | Insert/edit tables with legal formatting, merge cells | P0 |
| **Page breaks** | Manual page break insertion | P0 |
| **Line spacing** | Single, 1.5, double — court-compliant | P0 |
| **Margins** | Set page margins (1-inch default for courts) | P0 |
| **Line numbers** | Toggle line numbering (required for many courts) | P1 |
| **Footnotes** | Footnote insertion with auto-numbering | P1 |
| **Bookmarks** | Named anchors for internal document navigation | P2 |
| **Hyperlinks** | Insert/edit clickable links | P0 |
| **Citation support** | Bluebook/ALWD format auto-suggest | P1 |
| **Table of authorities** | Auto-generate from citation markers in document | P2 |
| **Table of contents** | Auto-generate from headings | P1 |
| **Word/character/page count** | Real-time status bar | P0 |
| **Spell check** | Legal dictionary (Black's Law Dictionary) | P1 |
| **Find & replace** | Standard find/replace with regex option | P0 |

### 3.2 Legal-Specific Features

| Feature | Description | Example |
|---------|-------------|---------|
| **Caption block** | Auto-formatted case caption field | Court name, parties, case number |
| **Signature block** | Insert attorney signature block with bar number | Auto-populated from user profile |
| **Certificate of service** | Auto-generate from case metadata | Filed parties, date, method of service |
| **Citation format** | Detect citation patterns → bluebook format | "123 U.S. 456" → proper citation |
| **Redaction tool** | Select text → mark as redacted | [REDACTED — Privileged] |
| **Page numbering** | Insert page numbers (bottom center standard) | "Page 1 of 25" |

### 3.3 Auto-Save

| Feature | Specification |
|---------|--------------|
| **Save frequency** | Every 30 seconds of inactivity or on content change |
| **Save trigger** | Content change, close tab, navigate away |
| **User feedback** | Status bar: "Saved just now" / "Saving..." / "Changes not saved" |
| **Offline resilience** | Buffer changes in localStorage; flush on reconnect |
| **Conflict handling** | Never overwrite — branch if concurrent edits from same user |

---

## 4. Template Library

### 4.1 Template Catalog (MVP — 5 Templates)

| Template | Use Case | Merge Fields |
|----------|----------|-------------|
| **Demand Letter** | Pre-litigation demand to opposing party | 15 fields |
| **Engagement Letter** | Client engagement / representation agreement | 18 fields |
| **Motion for Extension of Time** | Request court deadline extension | 12 fields |
| **Non-Disclosure Agreement** | Standard mutual NDA | 20 fields |
| **Simple Complaint** | Federal court complaint (short form) | 25 fields |

### 4.2 Merge Field System

```
Template Format:
  {{court_name}} — Auto-fills from firm's primary court
  {{case_number}} — Auto-fills from case metadata
  {{plaintiff_name}} — From case parties
  {{defendant_name}} — From case parties
  {{attorney_name}} — From current user's profile
  {{attorney_bar_number}} — From user profile → State Bar lookup
  {{firm_name}} — From firm profile
  {{firm_address}} — From firm profile
  {{firm_phone}} — From firm profile
  {{date_filed}} — Current date
  {{signature_block}} — Auto from user profile
  {{cert_of_service}} — Auto-generated from case service list
```

**Field Types:**
| Type | Example | Behavior |
|------|---------|----------|
| `Text` | {{plaintiff_name}} | Direct text replacement |
| `Date` | {{date_filed}} | Auto-formatted date |
| `Dropdown` | {{motion_type}} | Shows dropdown with options |
| `Conditional` | {{#if arbitration}}...{{/if}} | Show/hide clause blocks |
| `Lookup` | {{attorney_bar_number}} | Cross-reference user profile |

### 4.3 Template Management

| Feature | Specification |
|---------|--------------|
| **Template editor** | Admin interface to create/edit templates with merge fields |
| **Template categories** | Pleadings, Motions, Contracts, Correspondence, Discovery |
| **Firm-specific templates** | Each firm can save their own custom templates |
| **Template versioning** | Update templates without breaking in-progress documents |
| **Template search** | Search by name, category, practice area |
| **Smart clauses** | Conditional inclusion based on case type |
| **Preview** | See merge field values before generating |

### 4.4 Template Creation Interface

```
┌────────────────────────────────────────────────────────────────┐
│ ◆ TEMPLATE EDITOR — Motion for Extension                      │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  Template: Motion for Extension of Time   [Category: Motions] │
│  ───────────────────────────────────────────────────────────  │
│                                                                │
│  IN THE {{court_name|Court Name}}                              │
│  {{#if subdivision}}{{subdivision}}{{/if}}                     │
│                                                                │
│  {{plaintiff_name}},                )                          │
│       Plaintiff,                   )                           │
│       v.                           )  Case No. {{case_number}}│
│  {{defendant_name}},                )                          │
│       Defendant.                   )                           │
│                                                                │
│  MOTION FOR EXTENSION OF TIME TO FILE                         │
│  {{motion_type|dropdown:Response,Reply,Brief}}                │
│                                                                │
│  [INSERT CLAUSE: ExtensionStandard]                            │
│                                                                │
│  [SAVE TEMPLATE] [PREVIEW] [TEST MERGE]                        │
└────────────────────────────────────────────────────────────────┘
```

---

## 5. Collaborative Drafting

### 5.1 Real-Time Co-Editing

| Feature | Specification |
|---------|--------------|
| **Engine** | Y.js (CRDT-based) — scales to 10+ simultaneous editors |
| **Cursor presence** | See other users' cursors with name labels |
| **Selection highlighting** | See what others have selected |
| **User colors** | Each user assigned a unique color |
| **Connectivity** | WebSocket (reconnect with state recovery) |
| **Offline mode** | Edit locally → sync on reconnect |
| **Locking** | Optional paragraph-level locking for solo sections |

### 5.2 Comments & Review

| Feature | Specification |
|---------|--------------|
| **Inline comments** | Select text → add comment — positioned in margin |
| **@mentions** | @JaneSmith sends in-app notification |
| **Comment threads** | Replies to comments, resolved/unresolved status |
| **Comment history** | View all comment edits |
| **Resolve** | Mark comment as resolved (strikethrough, grayed out) |
| **Suggested edits** | Similar to Google Docs suggestion mode |

### 5.3 Track Changes

| Feature | Specification |
|---------|--------------|
| **Track changes toggle** | On/off per user |
| **Change types** | Insertion (green, underline), deletion (red, strikethrough), formatting change |
| **Author attribution** | Each change shows author name + timestamp on hover |
| **Accept all / reject all** | Bulk accept/reject |
| **Accept selected / reject selected** | Accept/reject individual changes |
| **Show markup / show final / show original** | View modes |

### 5.4 Approval Workflow

```
                    ┌───────────────────┐
                    │  Author creates   │
                    │  draft            │
                    └────────┬──────────┘
                             │
                    ┌────────▼──────────┐
                    │  Submits for      │
                    │  Review           │  → Notification to reviewer
                    └────────┬──────────┘
                             │
                    ┌────────▼──────────┐
                    │  Reviewer reviews │
                    │  with comments +  │
                    │  track changes    │
                    └────────┬──────────┘
                             │
                    ┌────────▼──────────┐
                    │  DECISION          │
                    │  ┌── Approve ─────┐│
                    │  │ (Final version)││
                    │  └──────┬─────────┘│
                    │  ┌── Changes ─────┐│
                    │  │ (Return for    ││
                    │  │  revision)     ││
                    │  └──────┬─────────┘│
                    │  ┌── Reject ──────┐│
                    │  │ (With reason)  ││
                    │  └────────────────┘│
                    └────────────────────┘
```

**Notification events:**
- Draft submitted for review → Notify reviewer
- Review returned with changes → Notify author
- Document approved → Notify all collaborators
- Comment added → Notify @mentioned user

---

## 6. Version History

| Feature | Specification |
|---------|--------------|
| **Auto-versions** | Saved every 30 seconds (collapsed into hourly snapshots) |
| **Manual versions** | Named checkpoints ("Pre-review draft", "Partner edits") |
| **Version tree** | Visual DAG showing branch/merge paths |
| **Diff view** | Side-by-side or inline diff between any 2 versions |
| **Restore** | One-click restore to any prior version (creates new version) |
| **Version metadata** | Author, timestamp, change summary, word count |
| **Retention** | All versions retained for case duration + 90 days |

### Version History UI
```
┌────────────────────────────────────────────────────────────┐
│ VERSION HISTORY — Motion_v3.docx                           │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ○ v5 — "Partner review complete"     Bob Wilson   Today  │
│  │    [Restore] [Compare with current] [Download]          │
│  │                                                         │
│  ○ v4 — "Addressing court comments"    Jane Smith   Today  │
│  │    [Restore] [Compare with v3] [Download]               │
│  │                                                         │
│  ○ v3 — "Initial draft"                Jane Smith   May 20 │
│  │    [Restore] [Compare with v2] [Download]               │
│  │                                                         │
│  ○ v2 — Auto-save (collapsed)                    May 20   │
│  │    (8 auto-saves between 14:00-17:00)                   │
│  │                                                         │
│  ○ v1 — "Uploaded from template"       Jane Smith   May 20 │
│       [Restore] [Compare] [Download]                       │
│                                                            │
│  SHOWING: Diff between v3 and v5                           │
│  ┌─────────────────────────────────────────────────────┐  │
│  │ + Lorem ipsum dolor sit amet                       │  │
│  │ - consectetur adipiscing elit                       │  │
│  │ + sed do eiusmod tempor                             │  │
│  └─────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────┘
```

---

## 7. User Interface Design

### Main Editor View
```
┌────────────────────────────────────────────────────────────────┐
│ ◆ Draft: Motion for Summary Judgment — Acme Corp v. State     │
│ [📄 Templates] [💾 Save] [👁️ Review] [↩️ v3] [🤝 Share]      │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌─── Toolbar ───────────────────────────────────────────────┐ │
│  │ [B] [I] [U] [S] [H1] [H2] [¶] [±] [🔗] [📋] [🔍] [💬]  │ │
│  │ [Track: ON] [Comment] [Cite] [Redact] [TOC] [Line#]     │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                │
│  ┌─── Collaborative Status ─────────────────────────────────┐ │
│  │ 🟢 Jane Smith editing • 🟡 Bob Wilson viewing            │ │
│  │ 🟣 Alice Garcia adding comment — Section III              │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                │
│  ┌─── Document ──────────────────────────────────────────────┐ │
│  │                                                             ││
│  │  IN THE UNITED STATES DISTRICT COURT                        ││
│  │  FOR THE NORTHERN DISTRICT OF CALIFORNIA                   ││
│  │                                                             ││
│  │  ACME CORPORATION,          )                               ││
│  │       Plaintiff,           )  Case No. 3:26-cv-00123       ││
│  │       v.                   )                               ││
│  │  STATE OF CALIFORNIA,      )                               ││
│  │       Defendant.           )                               ││
│  │                                                             ││
│  │  PLAINTIFF'S MOTION FOR SUMMARY JUDGMENT                   ││
│  │                                                             ││
│  │  {{Jane Smith}} is typing... 🖊️                            ││
│  │                                                             ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                │
│  ┌─── Sidebar: Clauses ────────────────────────────────┐      │
│  │ 🔍 Search clauses...                                 │      │
│  │ ──────────────────────────────────────────────────  │      │
│  │ 📋 Standard Clauses                                 │      │
│  │   ├─ 📌 Jurisdiction                                │      │
│  │   ├─ 📌 Venue                                       │      │
│  │   ├─ 📌 Choice of Law                               │      │
│  │   ├─ 🔒 Confidentiality                             │      │
│  │   ├─ ⚖️ Arbitration                                 │      │
│  │   └─ 📝 Indemnification                             │      │
│  │ ──────────────────────────────────────────────────  │      │
│  │ 📎 Recent Documents                                 │      │
│  │   ├─ Motion_v3.docx (current)                       │      │
│  │   ├─ Complaint.pdf                                  │      │
│  │   └─ DemandLetter.docx                              │      │
│  │ ──────────────────────────────────────────────────  │      │
│  │ 💬 Comments (3 unread)                              │      │
│  │ ──────────────────────────────────────────────────  │      │
│  │ Bob: "Need to update citation on p.4"               │      │
│  │ Jane: "Done — see v4"              [Resolve]        │      │
│  └────────────────────────────────────────────────────┘      │
│                                                                │
│  Status: ✅ Saved just now | Words: 1,234 | Pages: 6 | v3    │
└────────────────────────────────────────────────────────────────┘
```

---

## 8. Integration Points

| Integration | What It Does | Status | Dependency |
|-------------|-------------|--------|------------|
| **DMS** | All drafts saved to DMS on auto-save; templates loaded from DMS template folder | **P0 — Required** | DMS must exist |
| **Verification System** | Drafting tool access gated behind verified badge | P1 | Verification system |
| **User Access Control (RBAC)** | Role-based permissions for create/edit/approve | P0 | User system |
| **Auto-Send** | Draft finalized → auto-send to assigned lawyers | P1 | DMS auto-send |
| **Firm Color Coding** | Drafting tool interface uses firm color scheme | P2 | Color coding system |
| **Billing System** | Auto-log drafting time as billable activity | P3 | Billing system |
| **E-Signature** | One-click send for signature via Adobe Sign/DocuSign | P3 | E-signature vendor |
| **Auto-Backup** | Document drafts backed up via DMS backup pipeline | P0 (via DMS) | DMS backup |

---

## 9. Implementation Roadmap

### Phase 1: Core Editor (Weeks 1–3)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 1 | TipTap editor integration + basic formatting | Web-Dev |
| 1 | Auto-save engine (30-sec intervals) | Web-Dev |
| 2 | Template library (5 templates) + merge field system | Web-Dev + Ops Agent |
| 2 | Clause library (10 clauses) | Ops Agent |
| 3 | DMS integration (save/open) | Web-Dev |

### Phase 2: Collaboration & Review (Weeks 3–6)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 3–4 | Real-time co-editing (Y.js + WebSockets) | Web-Dev |
| 4 | Track changes system | Web-Dev |
| 4–5 | Inline comments + @mentions | Web-Dev |
| 5 | Approval workflow (submit → review → approve/reject) | Web-Dev |
| 5–6 | Version history + diff view | Web-Dev |

### Phase 3: Legal Features (Weeks 6–8)
| Week | Deliverable | Owner |
|------|-------------|-------|
| 6 | Legal formatting (caption block, signature, certificate of service) | Web-Dev |
| 6–7 | Citation support + table of authorities | Web-Dev |
| 7 | Spell check (legal dictionary) + redaction tool | Web-Dev |
| 7–8 | Template management UI (create/edit templates) | Web-Dev |

---

## 10. Cost Estimate

| Component | Monthly Cost | Setup Cost |
|-----------|-------------|-----------|
| TipTap (open source) | $0 | $0 |
| Y.js (open source) | $0 | $0 |
| WebSocket server | $20–$100 | $0 |
| Template engine (custom) | $0 | 1–2 weeks dev |
| Elasticsearch (shared) | Included in DMS | $0 |
| **TOTAL** | **$20–$100/mo** | **~2–3 weeks dev** |

---

## 11. Key Metrics & SLAs

| Metric | Target |
|--------|--------|
| Auto-save reliability | 100% (no data loss) |
| Version history retention | All versions, 90 days post-case |
| Template fill accuracy | 100% field population |
| Real-time co-editing latency | <200ms |
| Collaborative editor limit | 10+ simultaneous users |
| Diff generation time | <1 second for 50-page document |
| Document load time | <2 seconds |

---

## 12. Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Data loss on auto-save failure | Low | Critical | LocalStorage backup buffer + reconnect flush |
| Collaborative edit conflict | Low | Medium | CRDT handles conflicts; version history for restore |
| Template merge field error | Medium | Medium | Pre-save validation with field preview |
| Editor performance on large docs | Medium | Medium | Pagination at 50 pages; split-document recommendation |
| Browser compatibility | Low | Medium | Test Chrome, Firefox, Safari; fallback to read-only |

---

## 13. Appendix: Clause Library (MVP — 10 Clauses)

| # | Clause Name | Use Case | Content Preview |
|---|-------------|----------|----------------|
| 1 | **Jurisdiction** | Venue selection | "The parties hereby submit to the exclusive jurisdiction of..." |
| 2 | **Venue** | Court location | "Any action arising under this agreement shall be brought in..." |
| 3 | **Choice of Law** | Governing law | "This agreement shall be governed by the laws of..." |
| 4 | **Confidentiality** | NDA clause | "Each party agrees to maintain the confidentiality of..." |
| 5 | **Arbitration** | Dispute resolution | "Any dispute arising out of this agreement shall be resolved by..." |
| 6 | **Indemnification** | Liability | "Party A agrees to indemnify, defend, and hold harmless Party B from..." |
| 7 | **Force Majeure** | Unforeseeable events | "Neither party shall be liable for failure to perform due to..." |
| 8 | **Severability** | Partial invalidity | "If any provision of this agreement is held invalid..." |
| 9 | **Entire Agreement** | Merger clause | "This agreement constitutes the entire agreement between..." |
| 10 | **Attorney's Fees** | Fee shifting | "In any action to enforce this agreement, the prevailing party shall be entitled to..." |

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: Platform Expansion V2 Item #8 (Document Drafting Tool)*