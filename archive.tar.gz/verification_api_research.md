# Verification API Research Report

This report compares verification API providers for the CostLens Legal trust and verification system.

## Comparison Table

| Provider | Primary Verifications | Pricing Model | Integration | Time to Verify | Geographic Coverage |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Stripe Identity** | ID Documents, Biometrics | $1.50 per verification | API, SDK, No-code | Real-time | 33+ Countries |
| **Persona** | Identity, KYB, Sanctions | Custom ($1 - $2/ID) | Robust API & SDK | Real-time | Global |
| **Checkr** | Background, Criminal, SSN | $20 - $80 per check | API, Webhooks | 1 - 3 Days | US (Limited Global) |
| **Middesk** | Business Reg, EIN, SOS | $5 - $10 per check | Modern REST API | Seconds | US |
| **CLEAR** | Identity Verification | Custom Enterprise | API, SDK | Real-time | US |
| **Alloy** | KYC/KYB Orchestration | Custom ($20k+ min) | Unified API | Real-time | Global |
| **Veriff** | ID Documents, Face Match | $1.50 - $3.00/ID | API, Mobile SDK | Real-time | 190+ Countries |

## Provider Details

### 1. Stripe Identity
*   **What they verify:** Individual identity via documents (passport, driver's license) and biometric selfie matching.
*   **Pricing:** Transparent $1.50 per successful verification.
*   **Integration:** Excellent documentation, Stripe-native (uses same API keys), and offers a no-code verification link option.
*   **Speed:** Near real-time automated results.

### 2. Persona
*   **What they verify:** Identity, documents, KYB (Know Your Business), and continuous monitoring against sanctions/PEPs.
*   **Pricing:** Custom, but competitive for startups. Offers a "Free" tier for basic use cases.
*   **Integration:** Highly customizable UI components (embedded flows) and robust SDKs.
*   **Speed:** Real-time automated checks with manual review options.

### 3. Checkr
*   **What they verify:** Comprehensive background checks (criminal records, drug tests, education, and employment history).
*   **Pricing:** Per-report fee based on the depth of the check (e.g., Basic vs. Pro).
*   **Integration:** Well-documented API; standard for high-volume gig economy platforms.
*   **Speed:** Not real-time; typically takes 24-72 hours depending on county record access.

### 4. Middesk
*   **What they verify:** Business registration (Secretary of State data), EIN/Tax ID validation, and insurance coverage.
*   **Pricing:** Usage-based fee per business lookup.
*   **Integration:** Clean, developer-friendly API focused specifically on business identity.
*   **Speed:** Instant for most US-based business records.

### 5. CLEAR
*   **What they verify:** Identity. Leverages their trusted consumer network and biometric data.
*   **Pricing:** Enterprise-level custom pricing.
*   **Integration:** Developer-focused, requires partnership setup.
*   **Speed:** Instant.

### 6. Alloy
*   **What they verify:** Orchestrates multiple data sources for KYC, KYB, and AML compliance.
*   **Pricing:** High-end enterprise pricing with significant annual minimums.
*   **Integration:** Acts as a "single API" for 100+ data vendors.
*   **Speed:** Real-time decisioning engine.

### 7. Veriff
*   **What they verify:** Identity documents and liveness checks using AI and video.
*   **Pricing:** Tiered pricing based on volume.
*   **Integration:** Strong mobile SDK support for iOS and Android.
*   **Speed:** Automated real-time results.

## Top 3 Recommendations

1.  **Middesk (Best for Business Integrity)**
    *   **Why:** For CostLens Legal, verifying that a law firm is a legitimate, registered business entity with an active EIN is the top priority. Middesk is the gold standard for automated US KYB.
2.  **Persona (Best All-in-One Identity)**
    *   **Why:** Offers the most flexible platform for verifying both the individual (lawyer) and the business (firm). Its orchestration allows for scaling from simple ID checks to complex compliance workflows.
3.  **Stripe Identity (Best for Rapid Implementation)**
    *   **Why:** If the project is already using Stripe for billing, Stripe Identity can be integrated in hours with minimal overhead and a very predictable cost structure ($1.50/check).

---
*Created by Cost Agent - 2026-05-21*
