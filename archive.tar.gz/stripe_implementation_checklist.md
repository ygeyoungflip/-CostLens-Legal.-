# CostLens Legal — Stripe Connect Implementation Checklist

**Owner:** FinOps & Licensing Agent  
**Date:** May 22, 2026  
**Goal:** Implement Stripe Connect destination charges with a 10% application fee and fee routing to CTO account.

---

## 0) Pre-Implementation Decisions (Required)

- [ ] Confirm legal account ownership model:
  - Platform Stripe account owner
  - CTO payout account structure (internal treasury account vs external connected account)
- [ ] Confirm who absorbs Stripe processing fees (platform vs firm share)
- [ ] Confirm refund/dispute policy for fee reversals
- [ ] Define reserve policy for CTO sweeps (e.g., 10–15% holdback)

---

## 1) Stripe Account & Connect Setup

### 1.1 Platform account
- [ ] Create/verify platform Stripe account
- [ ] Complete business verification/KYC in Stripe dashboard
- [ ] Enable Stripe Connect

### 1.2 Connected accounts for firms
- [ ] Choose account type (Express vs Custom)
  - Recommended: Express for faster launch unless deep UX customization needed
- [ ] Build onboarding flow for connected accounts
- [ ] Persist `connected_account_id` per firm in internal DB
- [ ] Enforce capabilities checks before accepting charges

### 1.3 CTO fee destination setup
- [ ] Confirm CTO receiving account details (where fee sweeps go)
- [ ] Create payout destination mapping in internal config
- [ ] Configure sweep cadence (daily recommended, weekly fallback)

---

## 2) API Keys, Environment, and Secrets

### 2.1 Test mode keys
- [ ] Create restricted test API keys
- [ ] Store secrets in secrets manager (not code/env files in repo)
- [ ] Set per-environment config (`test`, `staging`, `prod`)

### 2.2 Live mode keys (production readiness gate)
- [ ] Create restricted live API keys
- [ ] Assign least-privilege permissions
- [ ] Document key rotation owner + schedule (quarterly minimum)

### 2.3 Webhook secrets
- [ ] Generate webhook signing secret per environment
- [ ] Store and version safely
- [ ] Verify rotation procedure

---

## 3) Destination Charge Implementation

### 3.1 Core charge logic
- [ ] For each billable transaction, set:
  - `transfer_data[destination] = <firm_connected_account_id>`
  - `application_fee_amount = round(gross_amount * 0.10)`
- [ ] Persist gross, fee, and net values in `billing_transactions`
- [ ] Include idempotency keys on all payment-creation requests

### 3.2 Subscription billing
- [ ] Integrate Stripe Billing/Checkout for recurring plans
- [ ] Configure invoice generation and retries
- [ ] Attach firm metadata for reconciliation exports

### 3.3 One-time billing
- [ ] Implement ad hoc invoice/checkout path
- [ ] Ensure same fee-split logic and ledger capture

---

## 4) Webhook Endpoints & Event Processing

### 4.1 Endpoint setup
- [ ] Create webhook endpoints for each environment
- [ ] Subscribe to required events:
  - `checkout.session.completed`
  - `invoice.paid`
  - `invoice.payment_failed`
  - `invoice.payment_action_required`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`
  - `charge.refunded`
  - `charge.dispute.created`
  - `transfer.created`

### 4.2 Security & idempotency
- [ ] Verify `Stripe-Signature` on raw request body
- [ ] Store `stripe_event_id` unique index to prevent duplicate processing
- [ ] Route failed events to dead-letter queue with retry controls

---

## 5) Automated Invoicing, Reconciliation, and CTO Sweeps

### 5.1 Invoicing
- [ ] Enable PDF invoice generation and storage
- [ ] Map invoice IDs to internal transaction IDs
- [ ] Add transparent fee line item disclosures

### 5.2 Reconciliation
- [ ] Build daily auto-recon job:
  - Stripe balance transactions vs internal ledger
- [ ] Build exceptions table with resolution workflow
- [ ] Build month-end export (gross / fee / net / disputes / refunds)

### 5.3 CTO fee payout scheduler
- [ ] Create scheduled job (02:00 UTC daily)
- [ ] Apply reserve holdback before transfer
- [ ] Record all sweeps in `fee_payouts`
- [ ] Add insufficient-balance safeguards

---

## 6) Test Mode Verification Plan (Go/No-Go)

### 6.1 Happy-path test cases
- [ ] Successful one-time charge applies exact 10% fee
- [ ] Successful subscription invoice applies exact 10% fee
- [ ] Notifications fire on `invoice.paid`

### 6.2 Failure-path test cases
- [ ] Failed payment triggers retry + alert flow
- [ ] SCA-required flow handled correctly
- [ ] Refund adjusts ledger and payout schedule
- [ ] Dispute triggers reserve logic and alerting

### 6.3 Webhook reliability tests
- [ ] Duplicate event replay does not double-book entries
- [ ] Signature validation blocks invalid requests
- [ ] Dead-letter queue receives malformed payloads

### 6.4 Reconciliation tests
- [ ] Daily recon detects forced mismatches
- [ ] Exceptions can be resolved and re-verified
- [ ] Month-end report totals match Stripe dashboard totals

---

## 7) Production Cutover Checklist

- [ ] Confirm all test-mode cases pass
- [ ] Complete security review and key rotation checks
- [ ] Complete finance sign-off on ledger reports
- [ ] Switch to live API keys and live webhook endpoints
- [ ] Monitor first 72 hours with heightened alerting

---

## 8) Ops Runbook Ownership

- [ ] FinOps owner: fee math, reconciliation, sweep monitoring
- [ ] Ops owner: incident handling and exception triage
- [ ] Web-dev owner: UI hooks for billing status and notification center
- [ ] Weekly review: unresolved billing/compliance exceptions

