# CostLens Legal — Aligned FinOps KPIs (Shared with Ops)

**Date:** May 20, 2026  
**Owners:** FinOps & Licensing Agent, Operations Optimization Agent  
**Use:** Single KPI definition set for shared SaaS overhead reporting.

---

## KPI Field Definitions (Required)

| KPI Field | Definition | Formula | Baseline (May 2026) | Target | Owner | Cadence |
|---|---|---|---:|---:|---|---|
| **Total License Spend** | Annualized run-rate spend for active software contracts | `sum(active_monthly_software_cost * 12)` | $310,200 | $263,640 | FinOps | Monthly |
| **Paid vs Active Seats** | Ratio of active seats to paid seats across monitored tools | `sum(active_seats_30d) / sum(paid_seats)` | 69% (modeled) | >=85% | FinOps + IT + Ops | Weekly |
| **Redundant-Tool Count** | Count of capability areas where >1 paid tool remains active | `count(capability where active_paid_tools > 1)` | 4 | <=2 | FinOps | Monthly |
| **Realized Savings** | Verified annualized savings against locked baseline | `baseline_total_license_spend - current_annualized_spend` | $0 | $46,560 | FinOps + Finance | Monthly |
| **Exception Count** | Number of approved dual-stack users/workflows outside standard tool policy | `count(active_exceptions)` | 0 (reset) | <=15 active exceptions | FinOps + Ops | Weekly |

---

## Expansion KPIs (Underused Resources + CAC)

| KPI Field | Definition | Formula | Baseline | Target | Owner | Cadence |
|---|---|---|---:|---:|---|---|
| **Underused License Cost** | Annualized cost tied to seats in underused/idle tiers | `sum(tool_cost * underused_or_idle_ratio)` | $32,000 (modeled) | <$10,000 | FinOps + Ops | Weekly |
| **Reclaimed Capacity Value** | Annualized value of removed/downgraded/reassigned waste | `sum(validated_reclaimed_cost)` | $0 | >=$20,000 | FinOps | Monthly |
| **Blended CAC** | Fully loaded acquisition cost per newly signed firm | `(sales+marketing+tooling+onboarding)/new_signups` | TBD | <=$8,500 | FinOps + Growth | Weekly |
| **CAC Payback (months)** | Months to recover CAC from monthly gross margin | `CAC / monthly_gross_margin_per_firm` | TBD | <=6 months | FinOps + Growth | Monthly |
| **LTV:CAC Ratio** | Lifetime gross margin relative to CAC | `lifetime_gross_margin / CAC` | TBD | >=3.0x | FinOps + Growth | Monthly |

---

## Data Sources

- Vendor admin exports (seat activity and assignment)
- AP invoices / contract repository
- Exception register (approved by Ops + FinOps)
- Finance monthly close reconciliation

---

## Governance Rules

1. Baseline is locked for the cycle; changes require FinOps + Ops + Finance signoff.
2. Savings count as “realized” only after finance reconciliation.
3. Exception records must include owner, reason, and end date.
4. No double-counting software savings in overhead totals.

---

## Reporting Dates

- Weekly KPI pulse: every Monday starting **May 25, 2026**
- First month-end rollup: **June 30, 2026**
- Consolidation checkpoint: **August 20, 2026**

