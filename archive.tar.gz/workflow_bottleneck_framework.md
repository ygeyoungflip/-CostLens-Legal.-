# Workflow Bottleneck Detection Framework

## Identifying, Measuring & Resolving Process Constraints in Legal Case Processing

**Prepared by:** Operations Optimization Agent  
**Date:** May 20, 2026  
**Alignment:** Supports PRD Capabilities #7 (Detect workflow bottlenecks), #8 (Highlight wasted admin time), PRD Design Principle #1 (Simple enough for firms without advanced technical systems)

---

## 1. Framework Overview

This framework provides a systematic way to detect bottlenecks across the complete legal case lifecycle — from intake through billing to payment. Each bottleneck is defined by:
- **Metric** — What to measure (quantitative)
- **Threshold** — When it becomes a bottleneck
- **Alert Level** — Green (healthy) / Yellow (watch) / Red (critical)
- **Detection Method** — How to identify it (manual for now, automated in future)
- **Root Causes** — Why it happens
- **Resolution Playbook** — What to do about it

---

## 2. Complete Bottleneck Detection Matrix

### Phase 1: Intake & Conflict Check

| # | Bottleneck | Metric | Green | Yellow | Red | Detection Method |
|---|-----------|--------|-------|--------|-----|-----------------|
| B1 | **Slow conflict check** | Hours from intake → conflict cleared | <2 hrs | 2–8 hrs | >8 hrs | Manual: Track in PMS timestamp fields |
| B2 | **Engagement letter lag** | Days from conflict cleared → letter sent | <1 day | 1–2 days | >2 days | Manual: Track email send dates vs. conflict clear |
| B3 | **Intake form abandonment** | % of started intakes not completed | <10% | 10–20% | >20% | Manual: Count portal starts vs. completes |
| B4 | **Duplicate data entry** | # of systems data re-entered | 0 (integrated) | 1–2 | 3+ | Manual audit: Map data flow across systems |

**Threshold Reference**: Industry average for conflict check is 1–2 business days. >8 hours indicates missing tool integration.

### Phase 2: Discovery & Evidence Gathering

| # | Bottleneck | Metric | Green | Yellow | Red | Detection Method |
|---|-----------|--------|-------|--------|-----|-----------------|
| B5 | **Document review stall** | Days in discovery phase relative to case complexity | On track | +20% over plan | >+50% over plan | Manual: Compare actual days vs. case-type baseline |
| B6 | **Linear review drag** | Docs reviewed per hour per reviewer | >75/hr | 40–75/hr | <40/hr | Manual time tracking |
| B7 | **Discovery budget overrun** | % of case budget consumed by discovery | <25% | 25–35% | >35% | Manual: Track discovery invoices vs. budget |
| B8 | **Expert witness sourcing delay** | Days from request → engagement | <7 days | 7–14 days | >14 days | Manual: Track sourcing start → signed engagement |
| B9 | **Deposition scheduling loop** | # of reschedules per deposition | 0–1 | 2–3 | >3 | Manual: Track calendar changes per deposition |

**Threshold Reference**: Discovery phase should not exceed 50% of total case timeline. If it does, it's a structural bottleneck.

### Phase 3: Legal Analysis & Strategy

| # | Bottleneck | Metric | Green | Yellow | Red | Detection Method |
|---|-----------|--------|-------|--------|-----|-----------------|
| B10 | **Research over-runs** | Hours spent on research vs. task budget | <100% | 100–130% | >130% | Manual: Compare actual research hours vs. estimate |
| B11 | **Motion drafting cycle time** | Days from assignment → draft complete | <3 days | 3–7 days | >7 days | Manual: Track assignment → first draft |
| B12 | **Partner review bottleneck** | Days from draft → partner review complete | <1 day | 1–3 days | >3 days | Manual: Track submission → approval timestamps |
| B13 | **Strategy session overrun** | Hours in strategy meetings vs. case phase | <2 hrs/wk | 2–4 hrs/wk | >4 hrs/wk | Manual: Calendar audit |
| B14 | **Partner-heavy delegation failure** | % of total case hours logged by partner | <50% | 50–80% | >80% | Manual: PMS time entry report by role |

**Threshold Reference**: Aligns with Cost Agent's "Associate-Heavy Alert" — cases with >80% Partner hours indicate failure to delegate effectively. See `/home/team/shared/early_alert_framework.md`

### Phase 4: Billing & Close

| # | Bottleneck | Metric | Green | Yellow | Red | Detection Method |
|---|-----------|--------|-------|--------|-----|-----------------|
| B15 | **Time entry delay** | Days between work done → time logged | <1 day | 1–3 days | >3 days | Manual: Compare calendar/task dates vs. entry dates |
| B16 | **Time write-down rate** | % of total billable value written down | <5% | 5–15% | >15% | Manual: Compare entered time vs. billed time |
| B17 | **Invoice generation lag** | Days from time close → invoice sent | <1 day | 1–3 days | >3 days | Manual: Track time close → invoice date |
| B18 | **Partner invoice approval queue** | # of invoices awaiting partner approval | <3 | 3–10 | >10 | Manual: Count pending approvals in PMS |
| B19 | **Client invoice review lag** | Days from invoice sent → client feedback | <7 days | 7–15 days | >15 days | Manual: Track send → feedback/response date |
| B20 | **Dispute resolution cycle** | Days from dispute raised → resolved | <3 days | 3–10 days | >10 days | Manual: Track dispute open → close dates |
| B21 | **Payment delay / DSO spike** | Days Sales Outstanding (DSO) | <35 days | 35–52 days | >52 days | Manual: Account aging report |

**Threshold Reference**: DSO of 52 days is the CostLens baseline, 35 days is the stretch target from the billing cycle optimization plan.

---

## 3. Bottleneck Severity Scoring Matrix

Use this scoring to prioritize which bottlenecks to fix first. Score = (Frequency × Impact × Controllability).

| Factor | 1 (Low) | 2 (Medium) | 3 (High) |
|--------|---------|------------|---------|
| **Frequency** | <1x per month | 1–4x per month | Weekly+ |
| **Impact (cost per occurrence)** | <$500 | $500–$5,000 | >$5,000 |
| **Controllability** | External factors dominate | Shared control | Firm fully controls |

**Priority Tiers:**
- **Critical (Score 18–27)**: Immediate action required
- **High (Score 12–17)**: Address within 30 days
- **Medium (Score 7–11)**: Address within 90 days
- **Low (Score 3–6)**: Monitor, plan for next cycle

### Priority Ranking of All 21 Bottlenecks

| Rank | Bottleneck | Frequency | Impact | Control | Score | Priority |
|------|-----------|-----------|--------|---------|-------|----------|
| 1 | B5 — Document review stall | 3 | 3 | 3 | **27** | 🔴 Critical |
| 2 | B15 — Time entry delay | 3 | 3 | 3 | **27** | 🔴 Critical |
| 3 | B17 — Invoice generation lag | 3 | 2 | 3 | **18** | 🔴 Critical |
| 4 | B21 — Payment delay / DSO | 3 | 3 | 2 | **18** | 🔴 Critical |
| 5 | B16 — Time write-down rate | 3 | 3 | 3 | **27** | 🔴 Critical |
| 6 | B6 — Linear review drag | 3 | 3 | 2 | **18** | 🔴 Critical |
| 7 | B18 — Partner approval queue | 3 | 2 | 3 | **18** | 🔴 Critical |
| 8 | B7 — Discovery budget overrun | 2 | 3 | 2 | **12** | 🟡 High |
| 9 | B1 — Slow conflict check | 2 | 2 | 3 | **12** | 🟡 High |
| 10 | B14 — Partner-heavy delegation | 3 | 2 | 2 | **12** | 🟡 High |
| 11 | B19 — Client review lag | 3 | 2 | 1 | **6** | 🟢 Medium |
| 12 | B10 — Research over-runs | 2 | 2 | 2 | **8** | 🟢 Medium |
| 13 | B12 — Partner review bottleneck | 3 | 1 | 3 | **9** | 🟢 Medium |
| 14 | B11 — Motion drafting cycle | 2 | 2 | 2 | **8** | 🟢 Medium |
| 15 | B20 — Dispute resolution cycle | 1 | 2 | 2 | **4** | ⚪ Low |
| 16 | B9 — Deposition scheduling | 2 | 1 | 2 | **4** | ⚪ Low |
| 17 | B8 — Expert witness sourcing | 1 | 2 | 2 | **4** | ⚪ Low |
| 18 | B4 — Duplicate data entry | 3 | 2 | 3 | **18** | 🔴 Critical* |
| 19 | B2 — Engagement letter lag | 2 | 1 | 3 | **6** | 🟢 Medium |
| 20 | B3 — Intake form abandonment | 1 | 2 | 2 | **4** | ⚪ Low |
| 21 | B13 — Strategy session overrun | 2 | 1 | 2 | **4** | ⚪ Low |

*\*B4 scored Critical because although per-occurrence cost is medium, frequency is high and control is total.*

---

## 4. Detection Implementation Guide

### Manual Detection (For firms without integrated systems — aligns with PRD Design Principle #3)

| Data Needed | Where to Find It | How Often to Check |
|-------------|------------------|-------------------|
| Conflict check timestamps | PMS task records | Weekly |
| Discovery phase duration | Case timeline in PMS | End of phase |
| Hourly review rate | Time entries by task code | Monthly |
| Research hours vs. budget | Case budget tracker | Weekly during active cases |
| Time entry delay | Compare work logs to entry dates | Weekly |
| Write-down rate | Billed vs. entered time report | Monthly |
| Invoice approval queue | PMS billing module | Daily |
| DSO | Accounts receivable aging | Monthly |
| Partner % of case hours | Time report by role | Monthly |

### Simple Reporting Format (for non-technical firms)

Create a weekly "Bottleneck Dashboard" checklist:

```
WEEK BOTTLENECK CHECK:
☐ Any case in discovery >10 days over plan? → Flag as B5
☐ Any time entries >3 days old? → Flag as B15
☐ Partner approval queue >10? → Flag as B18
☐ Any invoice >15 days without client response? → Flag as B19
☐ Write-down rate >5% this month? → Flag as B16
☐ DSO >45 days? → Flag as B21
☐ Any case with >80% partner hours? → Flag as B14
```

---

## 5. Automated Detection (Future State — Once PMS Integration Exists)

Once the platform integrates with Practice Management Systems, automate:

```python
# Pseudocode for automated bottleneck detection rules engine

BOTTLENECK_RULES = [
    {
        "id": "B5",
        "condition": "discovery_days > (case_type_baseline_days * 1.5)",
        "alert": "RED",
        "action": "Flag case for discovery audit; notify matter partner"
    },
    {
        "id": "B15",
        "condition": "time_entry_lag_days > 3",
        "alert": "RED",
        "action": "Auto-reminder to responsible attorney; notify billing manager if >5 days"
    },
    {
        "id": "B18",
        "condition": "pending_invoice_approvals > 10",
        "alert": "YELLOW",
        "action": "Escalate to practice group leader; auto-escalate to managing partner at >20"
    },
    {
        "id": "B21",
        "condition": "current_dso > 45",
        "alert": "YELLOW",
        "action": "Generate AR aging report; flag top 5 overdue accounts"
    },
    {
        "id": "B14",
        "condition": "partner_hours_pct > 0.80",
        "alert": "YELLOW",
        "action": "Alert practice lead; recommend delegation review"
    },
    {
        "id": "B16",
        "condition": "write_down_rate > 0.15",
        "alert": "RED",
        "action": "Notify managing partner; review time entry accuracy training needs"
    }
]
```

---

## 6. Coordination with Cost Agent's Early Alert Framework

The Cost Agent's Early Alert Framework (see `/home/team/shared/early_alert_framework.md`) focuses on **budget-based alerts** (e.g., 50% budget at <30% completion). This Bottleneck Framework focuses on **process-flow-based alerts** (e.g., stuck in discovery, time entry delays). The two frameworks are complementary:

| Aspect | Early Alert Framework (Cost Agent) | Bottleneck Framework (Ops Agent) |
|--------|-----------------------------------|----------------------------------|
| **Focus** | Budget burn rate, cost overruns | Process flow, cycle times |
| **Triggers** | % of budget vs. % of case complete | Days elapsed vs. baseline, queue sizes |
| **Resolution** | Re-forecast, rate optimization | Process re-engineering, automation |
| **Relationship** | If budget is burning too fast → check for bottlenecks | If bottlenecks exist → budget will likely overrun |

**Combined Alert Examples:**
- 🟡 **Watch**: B5+Y1 → Discovery running long AND over budget → Audit e-discovery vendor and review scope
- 🔴 **Critical**: B15+B16+R1 → Time entry delays AND high write-downs AND budget overrun → Full case financial review
- 🟡 **Watch**: B14+Y2 → Partner-heavy delegation AND associate-heavy cost structure → Workload rebalancing needed

---

## 7. Resolution Playbooks by Bottleneck Priority

### Critical (Score 18–27) — Immediate Resolution Required

| Bottleneck | Immediate Actions | Initiative Reference |
|-----------|------------------|---------------------|
| **B5** — Document review stall | Deploy TAR/AI-assisted review; bring in contract reviewers | AI-Assisted Document Review (case_processing_audit.md) |
| **B15** — Time entry delay | Deploy real-time mobile time capture; set daily reminder policy | Real-Time Time Capture (billing_cycle_optimization.md) |
| **B16** — Write-down rate | Deploy AI-narrative suggestions; improve entry accuracy; daily capture | AI Narratives (billing_cycle_optimization.md) |
| **B17** — Invoice lag | Auto-generate invoices; remove manual format steps | Auto Invoice Generation (billing_cycle_optimization.md) |
| **B18** — Partner approval queue | Delegate to billing manager; rule-based auto-approve | Delegated Invoice Review (billing_cycle_optimization.md) |
| **B4** — Duplicate data entry | Integrate PMS with other systems; auto-populate fields | Integrated PMS (case_processing_audit.md) |
| **B21** — Payment delay/DSO | Auto-payment reminders; early payment discount | Payment Reminders + Discount (billing_cycle_optimization.md) |
| **B6** — Linear review drag | Implement TAR/predictive coding; tier documents by relevance | AI Document Review (case_processing_audit.md) |

### High (Score 12–17) — Address Within 30 Days

| Bottleneck | Recommended Actions |
|-----------|-------------------|
| **B7** — Discovery budget overrun | Set discovery budget at case opening; vendor rate negotiation |
| **B1** — Slow conflict check | Implement API-based conflict checking across systems |
| **B14** — Partner-heavy delegation | Set delegation policy: >80% partner hours triggers review |

### Medium (Score 7–11) — Address Within 90 Days

| Bottleneck | Recommended Actions |
|-----------|-------------------|
| **B19** — Client review lag | Client billing portal for faster invoice review |
| **B10** — Research over-runs | Research time budgets per task; AI-assisted research tools |
| **B12** — Partner review slow | Calendar-block review time; delegation thresholds |
| **B11** — Motion drafting slow | Template library; AI-assisted drafting |
| **B2** — Engagement letter lag | Auto-generated engagement letters from PMS data |

### Low (Score 3–6) — Monitor, Plan for Next Cycle

| Bottleneck | Recommended Actions |
|-----------|-------------------|
| **B20** — Dispute resolution | Standardize dispute resolution process; tracked in portal |
| **B9** — Deposition scheduling | Self-scheduling tools; paralegal ownership |
| **B8** — Expert witness sourcing | Preferred provider list; pre-negotiated rates |
| **B3** — Intake form abandonment | Simplify form; add progress indicators; reduce required fields |
| **B13** — Strategy overrun | Set meeting time budgets; async status updates |

---

## 8. Sample Weekly Bottleneck Report

```
CostLens Legal — Weekly Bottleneck Report
Week of: May 20, 2026

🔴 CRITICAL (8):
  B5 — 3 cases in discovery >50% over baseline: Case #402, #511, #309
  B15 — 7 attorneys with time entries >5 days late
  B16 — Write-down rate at 15% (target: <5%)
  B17 — 5 invoices pending >3 days since time close
  B18 — 12 invoices in partner approval queue
  B4 — 3 systems requiring duplicate data entry
  B21 — DSO at 48 days (target: <35)
  B6 — Avg review rate at 42 docs/hr (target: >75)

🟡 HIGH (3):
  B7 — 2 cases exceeding discovery budget: #402 (115%), #511 (110%)
  B1 — Average conflict check: 5.2 hours
  B14 — 2 cases >80% partner hours

🟢 MEDIUM (5):
  B19 — 3 invoices outstanding >15 days
  B10 — Research 15% over budget on Case #402
  B12 — Avg partner review: 2.1 days
  B11 — Avg motion drafting: 4.5 days
  B2 — Engagement letter delay on 1 new matter

⚪ LOW (5): On track — no action needed this week

TOP PRIORITY ACTION ITEMS:
1. Deploy real-time time capture for 7 flagged attorneys
2. Schedule discovery audit for Cases #402 and #511
3. Clear partner approval queue (12 invoices)
```

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: PRD Capabilities #7 (bottleneck detection), #8 (admin waste), #9 (profitability by case type)*