# Tier Upgrade Proposal (For Existing Partners)

## Context
These firms signed up during our beta phase. We are now transitioning them to our official tiered pricing model. We lead with the value they are already seeing and show them the path to higher ROI.

---

### Upgrade Template: From Growth to Enterprise (e.g., Fox Rothschild)
**Subject:** Next Steps: Scaling CostLens at [Firm Name]

Hi [Partner Name],

Now that [Firm Name] is verified and active on the platform, we want to ensure you have the right suite of tools to meet your scale.

Based on our current rollout, we recommend transitioning [Firm Name] to our **Enterprise Tier ($10,000/mo)**. 

**Why Enterprise?**
While you've seen great results with our core cost driver identification, the Enterprise tier unlocks:
1. **Full Verification Suite:** Automated screening for all your co-counsel and vendors.
2. **Compliance Reporting:** Ready-to-use ROI and compliance exports for your corporate clients.
3. **API Access:** Integrate CostLens data directly into your firm's existing management systems.

Our models show that for a firm of your size, these features drive an additional **15% recovery in administrative efficiency**.

Would you like to hop on a 5-minute call this Thursday to discuss the transition and the new ROI projections?

Best,

[My Name]
Growth & Sales Lead, CostLens Legal

---

### Upgrade Template: From Solo to Growth (e.g., Boutique scale-up)
**Subject:** Expanding [Firm Name]'s Profitability Engine

Hi [Partner Name],

It's been great seeing [Firm Name] leverage CostLens for case benchmarking. As you look to grow your high-volume litigation practice, we'd like to propose moving you to our **Growth Tier ($7,000/mo)**.

**What changes?**
You'll move beyond simple benchmarking to **Profitability by Case Type** and **Bottleneck Detection**. We'll show you exactly which workflows are dragging your margins and how to recover **20% of your billable capacity**.

Are you available for a brief strategy session next week to look at the new efficiency dashboards?

Best,

[My Name]
Growth & Sales Lead, CostLens Legal
