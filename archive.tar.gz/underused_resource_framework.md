# CostLens Legal — Underused Resource Framework

**Owner:** FinOps & Licensing Agent  
**Date:** May 20, 2026  
**PRD Alignment:** Capability #12 — "Surface underused resources or unnecessary software expenses"

---

## 1) Objective

Create a proactive detection system for underused resources so waste is flagged before renewal cycles and converted into measurable, finance-validated savings.

---

## 2) In-Scope Resources

1. SaaS licenses (users, add-ons, premium modules)
2. Over-provisioned tiers (enterprise plans with low usage)
3. Paid features with low adoption
4. Duplicate tools with overlapping capabilities
5. Vendor retainers / committed service blocks

---

## 3) Utilization Thresholds (Standard)

### License/feature utilization (trailing 30 days)
- **Healthy:** >=80%
- **Watch:** 60–79%
- **Underused:** **<60%**
- **Idle/Cut candidate:** <30%

### Over-provisioning threshold
- Current tier considered over-provisioned when actual usage is **<70% of tier capacity** for 2 consecutive months.

### Low-adoption feature threshold
- Feature flagged for removal when adoption is **<25% of eligible users** for 2 consecutive months.

### Duplicate-tool threshold
- Capability flagged as redundant when **2+ paid tools** serve same core function and one has <50% adoption.

---

## 4) Detection Logic

For each resource, calculate:

- `utilization_pct = active_users_or_usage / paid_users_or_capacity`
- `waste_cost_usd = annual_cost_usd * (1 - utilization_pct)`
- `priority_score = waste_cost_usd * business_criticality_weight`

Priority ranking:
1. High waste + low criticality
2. High waste + medium criticality
3. Low waste + high criticality (monitor only)

---

## 5) Alert Rules (Proactive)

Trigger alerts when any of the following occurs:
1. Utilization drops below 60%
2. Utilization drops >15 percentage points month-over-month
3. Idle waste exceeds $1,000/month per tool
4. Exceptions (approved dual-stack users) exceed target limit

Escalation path:
- Week 1: tool owner alert
- Week 2 unresolved: FinOps + Ops review
- Week 3 unresolved: leadership escalation

---

## 6) Action Playbook

When flagged, apply one or more:
- Remove idle seats
- Downgrade plan tier
- Reassign seats to active teams
- Decommission low-adoption features
- Consolidate duplicate tools
- Renegotiate committed volume/retainer minimums

---

## 7) KPI Set

- Underused License Cost (annualized)
- Idle Seat Count
- Over-provisioned Tier Count
- Low-Adoption Feature Count
- Reclaimed Capacity Value (validated)
- Exception Count + Aging

---

## 8) ROI Tie-In (Required)

Each action must be logged using `/home/team/shared/roi_calculation_template.md`:
- Baseline annual cost
- Expected reclaim %
- Implementation cost
- Net annual savings
- Payback period
- Net ROI

Core formulas:
- `gross_savings = baseline_cost * reclaim_pct`
- `net_savings = gross_savings - ongoing_cost`
- `payback_months = implementation_cost / (net_savings/12)`

---

## 9) Reporting Cadence

- Weekly: underused watchlist refresh
- Monthly: finance-reconciled realized savings
- Quarterly: renewal strategy updates based on recurring waste patterns

