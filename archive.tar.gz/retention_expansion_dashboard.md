# CostLens Legal — Retention & Expansion Dashboard (Design + Targets)

**Owner:** FinOps & Licensing Agent  
**Date:** May 27, 2026  
**Context:** `/home/team/shared/retention_scaling_playbook.md` initiative #5

---

## 1) Required Metrics (Definitions)

| Metric | Definition | Formula |
|---|---|---|
| **MRR** | Monthly recurring revenue at month-end | `sum(active_subscription_mrr)` |
| **ARR** | Annualized recurring revenue | `MRR * 12` |
| **Churn Rate (logo)** | % of starting customers lost in period | `churned_customers / customers_start` |
| **GRR** | Revenue retained excluding expansion | `(starting_mrr - churn_mrr - contraction_mrr) / starting_mrr` |
| **NRR** | Revenue retained including expansion | `(starting_mrr - churn_mrr - contraction_mrr + expansion_mrr) / starting_mrr` |
| **Expansion Revenue** | Upsell/cross-sell/overage MRR gain | `upsell_mrr + add_on_mrr + overage_mrr` |

---

## 2) Baseline Snapshot (Current Confirmed)

From current confirmed pipeline data (7 confirmed firms):
- **MRR baseline:** **$58,000**
- **ARR baseline:** **$696,000**
- Tier mix: 5 Enterprise, 1 Growth, 1 Solo

---

## 3) 90-Day Targets (Dashboard Targets)

| KPI | Current Baseline | 90-Day Target |
|---|---:|---:|
| MRR | $58,000 | $250,000+ |
| ARR | $696,000 | $3,000,000+ |
| Churn Rate (monthly) | N/A early-stage | <=2.0% |
| GRR | N/A early-stage | >=92% |
| NRR | N/A early-stage | >=110% |
| Expansion Revenue (monthly) | $0 baseline | >=$15,000 |

> Note: NRR/GRR become statistically meaningful after at least 2 full monthly cohorts.

---

## 4) Dashboard Mockup (Wireframe)

## Row A — Executive Tiles
- Tile 1: **MRR** (current vs target)
- Tile 2: **ARR** (annualized)
- Tile 3: **NRR %**
- Tile 4: **GRR %**
- Tile 5: **Churn Rate %**
- Tile 6: **Expansion Revenue ($)**

## Row B — Revenue Waterfall (month-over-month)
`Starting MRR + New MRR + Expansion - Contraction - Churn = Ending MRR`

## Row C — Cohort Retention Heatmap
- Cohorts by signup month
- Logo retention and revenue retention by month 1/2/3

## Row D — Expansion Detail
- Expansion MRR by source:
  - Tier upgrades
  - Add-on modules
  - Verification overages

## Row E — Risk Monitor
- At-risk accounts (usage drop, unpaid invoices, unresolved support)
- Upcoming renewals (next 60/90 days)

---

## 5) Data Model for Dashboard

### `revenue_monthly`
- month
- firm_id
- tier_start
- tier_end
- starting_mrr
- new_mrr
- expansion_mrr
- contraction_mrr
- churn_mrr
- ending_mrr

### `customer_health`
- month
- firm_id
- product_usage_score
- support_risk_score
- payment_risk_score
- churn_risk_flag

### `expansion_events`
- event_date
- firm_id
- event_type (upgrade/addon/overage)
- mrr_delta
- owner

---

## 6) Alert Rules

- Churn rate >2.0% monthly -> red alert
- GRR <90% in any month -> red alert
- NRR <100% for 2 consecutive months -> escalation
- Expansion revenue below monthly target for 2 months -> growth/CS intervention

---

## 7) Operating Cadence

- Weekly: churn-risk review and expansion pipeline review
- Monthly close: publish MRR/ARR/NRR/GRR report
- Quarterly: retention and expansion strategy recalibration

