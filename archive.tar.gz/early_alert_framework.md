# Early Cost Alert Framework

This framework defines the thresholds and triggers for early cost warnings to prevent case budget overruns and identify inefficient cost drivers early.

## 1. Alert Thresholds (Budget-Based)
| Alert Level | Trigger Condition | Action Required |
| :--- | :--- | :--- |
| **Yellow (Watch)** | Case spend reaches 50% of budget while case stage is <30% complete. | Review time entries for senior vs. junior attorney mix. |
| **Orange (Action)** | Discovery costs exceed 110% of the allocated Discovery budget. | Audit E-Discovery software usage and vendor invoices. |
| **Red (Critical)** | Total case cost reaches 90% of budget with significant work remaining. | Mandatory partner review and client budget renegotiation. |

## 2. Structural Cost Triggers
These alerts fire when structural inefficiencies are detected, regardless of the total budget.
*   **The "Associate-Heavy" Alert:** If more than 80% of a case's billable hours are Partner-level work (suggests failure to delegate).
*   **The "Admin-Drag" Alert:** If administrative tasks (billing, filing, scheduling) by attorneys exceed 15% of their total logged hours.
*   **The "E-Discovery Bloat" Alert:** If monthly data hosting fees increase by more than 25% without a corresponding increase in document production.

## 3. Communication Protocol
1.  **Weekly Dashboard:** Automated email to Matter Partner highlighting "Red" and "Orange" cases.
2.  **Monthly Finance Sync:** Review of all "Red" alerts with the Ops Agent to identify firm-wide patterns.
3.  **Client Notification:** If an alert suggests a budget overrun of >15%, the client should be notified proactively to manage ROI expectations.

## 4. ROI Metrics for Reductions
*   **Reduction Goal:** 15% reduction in average case processing cost.
*   **Measurement:** (Baseline Case Cost - Current Case Cost) / Baseline Case Cost.
*   **ROI Calculation:** (Total Savings from Cost Reductions - Cost of Implementation) / Cost of Implementation.

## 5. Marketplace & Verification Alerts
*   **Non-Verified Vendor Alert:** Triggers if a case expense is logged for a vendor not in the Verified Network (potential compliance risk).
*   **Marketplace Optimization Alert:** Triggers when a high-frequency expense category (e.g., Expert Witness) is being filled by non-Marketplace vendors, indicating missed efficiency gains.
*   **Verification Stale-Date Warning:** Triggers 30 days before a vendor’s insurance validation or professional license standing expires within the system.
