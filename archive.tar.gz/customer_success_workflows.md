# Customer Success Workflows — Proactive Retention & Health Monitoring

## Touchpoint Schedule, Health Scoring, Escalation Triggers & Churn Prevention

**Prepared by:** Operations Optimization Agent  
**Date:** May 27, 2026  
**Context:** Part of Retention & Scaling Playbook (initiatives 2, 5, 6). Builds on tiered onboarding playbooks.

---

## 1. Proactive Touchpoint Schedule

### Timeline (All Tiers)

| Timing | Touchpoint | Tier | Owner | Content | Trigger | Duration |
|--------|-----------|------|-------|--------|---------|----------|
| **Day 1** | Welcome + verification | All | Growth Lead | Welcome email; verification link | Signup | 5 min |
| **Day 7** | First ROI Check-in | All | Ops Agent / Growth Lead | "How's it going? 3 quick wins identified?" | Auto 7d post go-live | 15 min call |
| **Day 30** | 30-Day Success Review | All | Ops Agent / Growth Lead | First cost savings tracked? Dashboard adoption? | Auto 30d post go-live | 30 min call |
| **Day 60** | 60-Day Optimization | Growth+ | Ops Agent | Bottleneck review; automation recommendations; alert tuning | Auto 60d post go-live | 30 min call |
| **Day 90** | Quarter 1 Business Review | All | Ops Agent + Cost Agent | Full ROI analysis; benchmark refresh; Q2 action plan | Quarterly | 60 min |
| **Day 180** | Half-Year Strategic Review | Enterprise+ | Ops Agent + Cost Agent | Expansion roadmap; upgrade assessment; integration roadmap | Semi-annual | 60 min |
| **Annual** | Annual Partnership Review | Ultra-Premium | Full team | Strategic partnership review; custom roadmap; SLA refresh | Annual | 90 min |

### Touchpoint Content Details

#### Day 7 — First ROI Check-in
```
CHECK: Is firm logging in? Are they running reports?
AGENDA:
1. How are you using the platform so far? (5 min)
2. Walk through the 3 quick wins identified during onboarding (5 min)
3. Any questions or blockers? (5 min)
OUTCOME: Firm confirms they're getting value; blockers identified
```

#### Day 30 — 30-Day Success Review
```
CHECK: Login frequency, feature adoption, data freshness
AGENDA:
1. Review cost savings tracked to date (10 min)
2. Dashboard adoption: which reports are they using? (5 min)
3. Identify any feature gaps or training needs (10 min)
4. Set goals for next 30 days (5 min)
OUTCOME: At least 1 cost reduction action in progress
```

#### Day 60 — 60-Day Optimization
```
CHECK: Bottleneck detection alerts, admin overhead trends
AGENDA:
1. Review bottleneck detection results (10 min)
2. Automation recommendations — which have been implemented? (10 min)
3. Tune early alert thresholds based on 60 days of data (5 min)
4. Review admin-to-billable ratio improvement (5 min)
OUTCOME: At least 1 automation recommendation in progress
```

#### Day 90 — Quarter 1 Business Review (QBR)
```
CHECK: Full ROI analysis against baseline
AGENDA:
1. Executive Summary — ROI-to-date (5 min)
2. Cost Performance — case cost trends, top drivers, benchmarks (15 min)
3. Operational Efficiency — admin ratio, DSO, bottlenecks (10 min)
4. Automation & ROI — hours reclaimed, software savings (10 min)
5. Next Quarter Plan — priority initiatives, upgrade opportunities (15 min)
6. Open Discussion — feedback, requests, concerns (5 min)
OUTCOME: Q2 action plan agreed; health score recalculated
```

---

## 2. Customer Health Scoring Model

### Score Components

| Component | Weight | Source | Scoring Logic |
|-----------|--------|--------|---------------|
| **Login frequency** | 25% | Platform analytics | Daily=100, Weekly=75, Biweekly=50, Monthly=25, Never=0 |
| **Feature adoption** | 25% | Feature usage logs | % of assigned features used / total available (per tier) |
| **Data freshness** | 20% | Last data upload date | <7 days=100, 7–30=75, 30–60=50, 60–90=25, >90=0 |
| **Support interactions** | 15% | Ticket system | No tickets=100, 1–3 resolved=75, >3 open=25, Escalated=0 |
| **ROI realization** | 15% | Cost tracking dashboard | >15% savings=100, 5–15%=75, 0–5%=50, Negative=0 |

### Health Score Formula
```
HEALTH = (LOGIN_SCORE × 0.25) + (FEATURES_SCORE × 0.25) 
       + (FRESHNESS_SCORE × 0.20) + (SUPPORT_SCORE × 0.15) 
       + (ROI_SCORE × 0.15)
```

### Score Tiers & Actions

| Score | Classification | Color | Meaning | Action Required | Response Time |
|-------|---------------|-------|---------|----------------|---------------|
| **80–100** | Healthy | 🟢 Green | Firm is engaged and seeing value | Monitor only — quarterly check-in | N/A |
| **50–79** | At Risk | 🟡 Yellow | Engagement dropping — early signal | Proactive outreach with supportive guidance | Within 7 days |
| **25–49** | Critical | 🟠 Orange | Significant disengagement | Immediate phone call + action plan development | Within 24 hours |
| **0–24** | Churning | 🔴 Red | Firm likely to cancel | Executive intervention + retention offer | Immediate |

### Health Score Calculation Example
```
Gibson Dunn — Month 2
Login: Weekly → 75 × 0.25 = 18.75
Features: 6 of 8 features used → 75 × 0.25 = 18.75
Freshness: Data uploaded 10 days ago → 75 × 0.20 = 15.00
Support: 2 resolved tickets → 75 × 0.15 = 11.25
ROI: 12% savings → 75 × 0.15 = 11.25

HEALTH SCORE = 18.75 + 18.75 + 15.00 + 11.25 + 11.25 = 75.00 → 🟢 Healthy
```

---

## 3. Escalation Triggers

### Trigger Matrix

| Trigger ID | Condition | Classification | Response Time | Action | Escalates To |
|-----------|-----------|---------------|---------------|--------|-------------|
| **ES-01** | No login >14 days | 🟡 Yellow | 24 hours | Send re-engagement email with personalized insight | Growth Lead |
| **ES-02** | No login >30 days | 🟠 Orange | 48 hours | Personal call from account manager | Ops Agent |
| **ES-03** | Feature usage drops >50% in 30 days | 🟡 Yellow | 48 hours | Proactive training session offer | Ops Agent |
| **ES-04** | No data upload >60 days | 🟠 Orange | 48 hours | Data refresh campaign + check-in call | Cost Agent |
| **ES-05** | >5 unresolved support tickets | 🟠 Orange | 24 hours | Account review with support team | Ops Agent |
| **ES-06** | Costs increased >5% since baseline | 🔴 Red | Immediate | Full cost audit + remediation plan | Ops Agent + Cost Agent |
| **ES-07** | Firm mentions canceling or leaving | 🔴 Red | Immediate | Executive outreach + retention offer | Growth Lead + Ops Agent |
| **ES-08** | Payment failure or downgrade request | 🔴 Red | 4 hours | Resolve billing issue + understand reason | FinOps Agent |
| **ES-09** | Health score drops to 🟠 Critical (25–49) | 🟠 Orange | 24 hours | Root cause analysis + action plan | Ops Agent |
| **ES-10** | Health score drops to 🔴 Churning (0–24) | 🔴 Red | Immediate | Executive intervention + retention package | Full team |

### Escalation Workflow
```
Trigger Fires
     │
     ▼
┌──────────────┐
│ Assess       │
│ Severity     │
├── Yellow ─────→ Auto-email + log (24–48h)
├── Orange ─────→ Manual outreach + action plan (24–48h)
└── Red ────────→ Immediate escalation + executive alert (0–4h)
     │
     ▼
┌──────────────┐
│ Resolve      │
├── Issue fixed ──→ Log resolution + recalculate health score (48h)
├── Escalate ──────→ Next tier (Growth Lead → Ops Agent → Executive)
└── Firm lost ────→ Exit interview + learn + re-engage in 6 months
     │
     ▼
┌──────────────┐
│ Monitor      │
│ (72 hours)   │
└──────────────┘
```

---

## 4. Churn Prevention Playbook

### Early Warning Signals

| Signal | Severity | Lead Time | Typical Root Cause | Intervention |
|--------|----------|-----------|-------------------|-------------|
| Login frequency drops >50% | 🟡 Medium | 2–4 weeks | Not seeing value; too busy | Re-engagement email with personalized insight + check-in call |
| No data upload >60 days | 🟠 High | 4–8 weeks | Data entry friction; no process owner | Data refresh campaign + ROI re-demonstration |
| Support tickets spike + negative sentiment | 🟠 High | 1–3 weeks | Feature broken; training gap; unmet expectations | Account review + executive outreach |
| Feature usage drops to <30% | 🟡 Medium | 2–4 weeks | Unaware of features; don't understand value | Retraining session + new feature showcase |
| Competitor mentions | 🔴 Critical | 1–2 weeks | Competitive pressure; price sensitivity | Value re-demonstration + differentiation discussion |
| Billing downgrade or non-payment | 🔴 Critical | Immediate | Budget cuts; dissatisfaction | Financial review + retention offer |

### Churn Intervention Flow
```
CHURN SIGNAL DETECTED
         │
    ┌────▼────────────────────────┐
    │ What's the health score?    │
    ├── 50–79 (🟡 At Risk) ────────→ Proactive outreach within 7 days
    │                                   Identify blockers
    │                                   Offer help (training, data refresh)
    │
    ├── 25–49 (🟠 Critical) ───────→ Immediate call within 24 hours
    │                                   Root cause analysis
    │                                   Action plan with timeline
    │                                   Consider temporary discount
    │
    └── 0–24 (🔴 Churning) ────────→ Executive intervention (immediate)
                                        CEO/COO outreach
                                        Retention offer
                                        Root cause investigation
         │
         ▼
    ┌──────────────┐
    │ Root Cause   │
    ├── Not seeing ROI ────→ Re-demonstrate value; adjust metrics; share case studies
    ├── Too complex ───────→ Simplify; retrain; assign dedicated support
    ├── Competitor ────────→ Differentiate; offer incentive; highlight unique features
    └── Budget cut ────────→ Downgrade tier; reduce scope; stay engaged for re-expansion
         │
         ▼
    ┌──────────────┐
    │ Outcome      │
    ├── Retained ───────────→ Strengthened engagement plan; increase touchpoints
    │                           Recalculate health score in 30 days
    │
    └── Lost ───────────────→ Exit interview (within 7 days)
                                Document learnings
                                Tag for re-engagement in 6 months
                                Remove from active pipeline
```

### Retention Offer Framework

| Scenario | Offer | Conditions | Success Rate (Est.) |
|----------|-------|------------|---------------------|
| Budget constraints | Downgrade to lower tier for 3 months | Must schedule re-evaluation call | 60% |
| Not seeing ROI | Free 2-month ROI audit + dedicated analyst | Must provide data access | 70% |
| Competitor pricing | Match competitor price for 12 months | Must sign annual contract | 50% |
| Feature gap | Priority roadmap inclusion (90-day delivery) | Must remain active during development | 65% |
| Training/usage gap | Free 4-week accelerated onboarding program | Must assign internal champion | 80% |

---

## 5. Tier Upgrade Paths

| Current Tier | Upgrade Path | Trigger Signals | Upgrade Process |
|-------------|-------------|----------------|-----------------|
| **Solo → Growth** | $1K → $7K/mo | Adds 3+ attorneys; outgrowing basic reports; asks for profitability by case type | Upgrade call + feature training + new report setup |
| **Growth → Enterprise** | $7K → $10K/mo | Needs compliance reporting; document management; API access; partner verification | Executive review + security assessment + custom integration |
| **Enterprise → Ultra-Premium** | $10K → $100K+/mo | Is AmLaw 100/200; needs white-glove service; custom SLAs | Partnership proposal + executive briefing + 4-week onboarding |

### Upgrade Timing Recommendations

| Scenario | Timing | Approach |
|----------|--------|----------|
| Natural expansion (firm growing) | At QBR | Present data showing ROI from higher tier exceeds additional cost |
| Feature need (firm needs specific feature) | Within 30 days of request | Offer 14-day trial of higher tier feature |
| Usage threshold (firm hitting tier limits) | Immediate | Proactive outreach before firm feels friction |
| Annual renewal | At renewal | Bundle upgrade with renewal for pricing incentive |

---

## 6. Success Metrics & KPIs

| KPI | Target | Measurement | Frequency |
|-----|--------|-------------|-----------|
| **Time to first value** | <7 days (Solo), <14 days (Enterprise) | Signup → first report delivered | Per firm |
| **Onboarding completion rate** | >90% | Started vs. completed onboarding | Monthly |
| **30-day activation rate** | >80% | Firms logging in ≥5x in first 30 days | Monthly |
| **90-day retention** | >95% | Firms still active at 90 days | Quarterly |
| **Net Revenue Retention (NRR)** | >120% | Revenue from existing firms including upgrades | Monthly |
| **Average Health Score** | >75 | Composite health score across all firms | Weekly |
| **QBR completion rate** | 100% for Enterprise+ | Scheduled vs. completed QBRs | Quarterly |
| **Churn rate** | <5% annually | Firms canceling / total firms | Monthly |
| **Net Promoter Score (NPS)** | >50 | Survey at 30/90/365 days | Per milestone |
| **Critical escalation response** | <24 hours | Ticket open → resolved | Continuous |
| **Upgrade conversion rate** | >20% of eligible firms | Upgrade offer → accepted | Quarterly |

---

## 7. Cross-Team Coordination

| Teammate | Role in Customer Success | Key Responsibilities |
|----------|--------------------------|---------------------|
| **Growth & Sales Lead** | Solo tier CS; upgrade campaigns; re-engagement emails | Day 1 welcome, Day 7/30 check-ins for Solo, upgrade proposals |
| **Cost Agent** | Data freshness monitoring; ROI recalculation; QBR cost analysis | Quarterly benchmark refresh, health score ROI component |
| **Ops Agent** | Enterprise CS lead; QBR facilitation; escalation management; retention intervention | Day 30/60/90 touchpoints for Growth+, escalations, churn prevention |
| **FinOps Agent** | Billing health monitoring; payment issue resolution; expansion revenue tracking | Payment failure alerts, upgrade billing setup |
| **Web-Dev** | Technical support escalations; integration maintenance | Tier 2/3 technical issue resolution |

---

*Document prepared by Operations Optimization Agent | CostLens Legal*
*Aligns with: Retention & Scaling Playbook (Initiatives #2, #5, #6)*