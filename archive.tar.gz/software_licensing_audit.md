# CostLens Legal — Software Licensing Audit (Baseline + Consolidation Opportunities)

**Owner:** FinOps & Licensing Agent  
**Date:** May 20, 2026  
**Objective:** Reduce software licensing cost by **>=10%** while preserving legal delivery quality and supporting growth to 50 firm sign-ups in 3 months.

---

## 1) Audit Scope & Method

This audit covers software categories that materially affect case-delivery and operating overhead:
- Practice/case management
- E-signature
- Document management/collaboration
- Document review and e-discovery platforms
- Communication and meeting tools
- Billing, time tracking, and accounting
- Business intelligence/reporting
- Workflow automation/integration
- CRM and sales tooling

Assessment criteria per tool:
1. Annual spend (license + add-ons)
2. Seat count and utilization
3. Overlap/redundancy with other tools
4. Business criticality (mission-critical vs replaceable)
5. Consolidation opportunity and migration complexity

---

## 2) Current Licensing Catalog (Working Baseline)

> Use this baseline as a planning model. Replace with actual contract values from procurement/AP exports before execution.

| Category | Tool | Seats | Utilization | Annual Cost (USD) | Overlap Risk | Notes |
|---|---|---:|---:|---:|---|---|
| Practice Mgmt | Clio Manage | 45 | 85% | 64,800 | Low | Core system of record |
| E-signature | DocuSign Business Pro | 35 | 42% | 18,900 | High | Overlaps with Adobe Sign capability |
| Document/PDF | Adobe Acrobat Pro | 40 | 70% | 14,400 | Medium | Includes e-sign module not used systematically |
| Internal Comms | Slack Pro | 55 | 78% | 49,500 | Medium | Potential partial overlap with Teams chat |
| Meetings | Zoom Business | 50 | 46% | 24,000 | High | Overlap with Teams meetings |
| M365 Suite | Microsoft 365 Business Premium | 60 | 88% | 43,200 | Low | Includes Teams + OneDrive/SharePoint |
| Time/Billing | TimeSolv | 30 | 76% | 15,600 | Medium | Billing exports duplicated in accounting stack |
| Accounting | QuickBooks Advanced | 12 | 81% | 21,600 | Low | Necessary for finance close |
| BI/Reporting | Power BI Pro | 20 | 55% | 4,800 | Medium | Underused, no standard dashboard governance |
| Automation | Zapier Team | 8 | 62% | 8,388 | Medium | Multiple low-value zaps |
| CRM/Sales | HubSpot Sales Pro | 10 | 67% | 27,600 | Medium | Some pipeline data duplicated in PM system |
| Research AI | Legal Research Add-ons | 25 | 59% | 17,412 | Low | Important but some idle seats |

**Estimated current annual software spend (fixed-seat baseline):** **$310,200**

### 2A) Additional Legal-Tech Variable Spend (Catalog Completeness)

These tools are usage/matter-based and tracked separately from fixed-seat baseline in this model.

| Category | Tool | Billing Model | Estimated Annual Spend (USD) | Overlap Risk | Notes |
|---|---|---|---:|---|---|
| E-discovery | RelativityOne | Consumption + workspace | 42,000 | Medium | Heavy on complex litigation matters |
| Document Review | Everlaw | User + data volume | 24,000 | High | Overlaps with Relativity for mid-complexity matters |

**Estimated variable legal-tech spend (not included in $310,200 baseline):** **$66,000**

---

## 3) Top Cost Drivers (Licensing)

1. **Collaboration stack duplication** (Slack + Zoom + Teams via M365)  
2. **E-signature overlap** (DocuSign + Adobe e-sign capability)  
3. **Idle/underutilized specialist seats** (Power BI, research add-ons, automation seats)

These three drivers are responsible for the largest avoidable fixed-seat spend without reducing core legal capability. A secondary variable-spend driver is dual-platform e-discovery usage (RelativityOne + Everlaw on overlapping matter profiles).

---

## 4) Consolidation & Optimization Opportunities

| Opportunity | Baseline Cost | Action | Estimated Annual Savings | Confidence |
|---|---:|---|---:|---|
| A. Meeting stack consolidation | $24,000 (Zoom) | Move standard internal/external meetings to Teams; keep 10 Zoom host licenses for external client preference use-cases | $19,200 | High |
| B. E-signature consolidation | $18,900 (DocuSign) | Transition routine signatures to Adobe Sign (already licensed via Adobe); keep limited DocuSign envelope package only if needed | $13,230 | Medium-High |
| C. Seat-rightsizing (BI, research, automation) | $30,600 (selected tools) | Remove or reassign idle seats using 60-day utilization policy | $9,180 | High |
| D. Slack license tier optimization | $49,500 | Move low-activity users to free/guest pattern where possible; retain paid seats for client-facing and active matter teams | $4,950 | Medium |
| E. E-discovery vendor rationalization *(incremental)* | $66,000 (variable spend) | Set default platform by matter tier and negotiate volume tiers to reduce dual-platform usage | $9,900 | Medium |

**Total estimated annual savings (fixed-seat baseline):** **$46,560**  
**Projected post-optimization fixed-seat spend:** **$263,640**  
**Projected fixed-seat reduction:** **15.0%** of current fixed-seat licensing spend  
**Incremental variable-spend upside (not in baseline reduction %):** **$9,900**

---

## 5) Risks & Controls

| Risk | Impact | Mitigation |
|---|---|---|
| Workflow disruption during migration | Medium | Pilot with one practice group for 2 weeks before full rollout |
| Client tool preference mismatch | Medium | Keep limited dual-tool exceptions with approval process |
| Data migration or retention gaps | High | Require vendor export validation and legal hold checks |
| User adoption resistance | Medium | Role-based enablement + quick-reference SOPs |

---

## 6) 90-Day Execution Checkpoints

- **Days 1–15:** Validate invoice-level baseline, finalize target-state architecture, secure leadership sign-off
- **Days 16–45:** Run Teams/Adobe pilot + seat utilization cleanup wave 1
- **Days 46–75:** Full migration for selected teams + contract adjustment negotiation
- **Days 76–90:** Cleanup wave 2, lock recurring dashboards, report realized savings and ROI

---

## 7) KPI Pack for Tracking

- Total licensing spend (monthly and annualized)
- Cost per active user
- Utilization rate per product
- Redundant tool count (same capability category)
- Savings realized vs plan
- Exception count (approved dual-stack users)

