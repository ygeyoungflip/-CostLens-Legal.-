# CostLens Legal — KPI Alignment Document

**Purpose:** Standardize metric definitions and tracking ownership across the team (Cost, Ops, FinOps) to ensure unified dashboard reporting.

## 1. Primary Strategic KPIs

| KPI | Definition | Target | Owner |
| :--- | :--- | :--- | :--- |
| **Average Cost per Case** | Total case-specific costs (internal labor + direct expenses) divided by number of cases. | -15% reduction | Cost Agent |
| **Overhead % of Revenue** | Total non-case-specific operating expenses divided by total firm revenue. | -10% reduction (max 36%) | Ops Agent |
| **Days Sales Outstanding (DSO)** | Average number of days to collect payment after an invoice is issued. | -20% (Target: 35 days) | Ops Agent |
| **Admin-to-Billable Ratio** | Total admin hours logged vs. total billable hours logged. | 28:72 ratio (replaces 43:57) | Ops Agent |
| **Software Spend Reduction** | Annualized software licensing spend vs. original baseline ($310,200). | -10% reduction | FinOps Agent |

## 2. ROI & Efficiency KPIs

| KPI | Definition | Target | Owner |
| :--- | :--- | :--- | :--- |
| **Portfolio ROI (%)** | (Total Year 1 Net Benefit / Total Implementation Costs) * 100. | >300% | All (Standardized) |
| **Payback Period** | Total Implementation Cost / Monthly Net Savings. | <4 months | All (Standardized) |
| **Effective Hourly Rate (EHR)** | Total Revenue / Total Hours (Billable + Admin). | >$400/hr (Firm Avg) | All |
| **Automation Coverage Ratio** | # of Routine Tasks Automated / Total # of Routine Tasks. | >75% | Ops Agent |
| **Workflow Velocity Score** | Actual Stage Completion Time vs. Standard Baseline. | >1.0x (Ahead of Sched) | Ops Agent |
| **License Utilization %** | (Active Users / Total Paid Seats). | >90% | FinOps Agent |
| **Idle Seat Cost** | Total Annual Cost * (1 - Utilization %). | Minimize to <$5k/yr | FinOps Agent |

## 3. Early Warning Indicators (Early Alert Framework)

| Indicator | Threshold for Warning | Action |
| :--- | :--- | :--- |
| **Budget Burn Rate** | >50% budget consumed at <30% case completion. | Case Audit |
| **Discovery Overrun** | >110% of allocated Discovery budget. | E-Discovery Review |
| **Partner Drag** | Partner hours >80% of total case hours. | Delegation Review |

## 4. Reporting Cadence
*   **Real-time:** Dashboard updates from practice management and accounting software syncs.
*   **Weekly:** Operational review of Early Alerts and DSO.
*   **Monthly:** Full Executive Dashboard review with ROI updates.
*   **Quarterly:** Benchmarking against industry averages (ILTA/Thomson Reuters).
