# CostLens Legal — Vendor Negotiation Briefs (Top 3 Consolidation Opportunities)

**Owner:** FinOps & Licensing Agent  
**Date:** May 20, 2026  
**Purpose:** Execute high-impact software consolidation aligned to Ops overhead category **Software Subscriptions & IT**.

---

## 1) Alignment to Ops Overhead Categories

From `/home/team/shared/overhead_reduction_plan.md`, the relevant shared category is:
- **Software subscriptions & IT** (current annual spend: **$350,000**, target reduction: **15%**, estimated savings: **$52,500**)

This negotiation pack addresses the three overlap areas identified jointly with Ops:
1. **Zoom + Teams** overlap (meetings/collaboration)
2. **DocuSign + Adobe eSign** overlap (signature workflows)
3. **BI tool seat waste** (Power BI underutilization / license right-sizing)

---

## 2) Quick Negotiation Matrix (Current Spend, Alternatives, Target Price, Leverage)

| Opportunity | Current Spend (Annual) | Alternative Options | Target Price / Spend | Key Leverage Points |
|---|---:|---|---:|---|
| Zoom + Teams overlap | $24,000 (Zoom) + Teams already in M365 | Teams-first; keep exception-only Zoom hosts | **$4,800 annual Zoom run-rate** (80% down) | Existing M365 entitlement, measurable low host utilization, competitive displacement risk |
| DocuSign + Adobe eSign overlap | $18,900 (DocuSign) + Adobe seat base already paid | Adobe Sign default; capped DocuSign exception plan | **$5,670 annual DocuSign run-rate** (~70% down) | Internal signatures can migrate quickly, envelope caps, renewal timing pressure |
| BI tool seat right-sizing (Power BI) | $4,800 (Power BI Pro) | Analyst-only BI seats; viewer access via shared reports | **$2,880 annual BI run-rate** (40% down) | Underutilized seats, clear active/inactive telemetry, role-based entitlement policy |

**Modeled savings from top 3:** **$34,350/year**

---

## 3) Brief A — Zoom + Teams Consolidation

### Current State
- Broad Zoom paid host footprint while Microsoft Teams is already licensed in M365.
- Utilization patterns indicate many low-activity hosts.

### Commercial Ask
1. True-down host licenses to exception-only pool.
2. Co-term to fiscal renewal cycle.
3. Waive downgrade penalties during migration.
4. Include migration/admin support credits.

### Target Commercial Outcome
- Zoom annual spend: **$24,000 → $4,800**.
- Lock 12-month price protection on reduced footprint.

### Leverage Points
- Teams is already paid; Zoom is incremental.
- Clear host-level usage evidence for right-sizing.
- Willingness to keep only business-critical exceptions.

### BATNA
- Migrate all standard meetings to Teams and keep minimal Zoom for mandated client cases.

---

## 4) Brief B — DocuSign + Adobe eSign Consolidation

### Current State
- DocuSign licenses overlap with Adobe eSign capability in existing Adobe footprint.
- Routine internal and standard agreements can move to Adobe workflows.

### Commercial Ask
1. Move to minimal DocuSign SKU/envelope package.
2. Block automatic seat expansion.
3. Obtain migration/template conversion support.
4. Confirm enterprise audit/compliance requirements in target setup.

### Target Commercial Outcome
- DocuSign annual spend: **$18,900 → $5,670**.
- Keep capped exception plan only.

### Leverage Points
- High portion of signatures are routinized and migratable.
- Existing Adobe spend gives immediate substitution path.
- Envelope caps can be policy-enforced.

### BATNA
- Keep dual-stack temporarily but enforce strict monthly envelope ceiling and mandatory Adobe-first routing.

---

## 5) Brief C — BI License Right-Sizing (Power BI)

### Current State
- Power BI seats are underutilized relative to paid allocation.
- Many consumers can use shared outputs without full creator licenses.

### Commercial Ask
1. Reduce paid Pro seats to core analyst cohort.
2. Secure flexibility for quarterly true-down.
3. Request pooled licensing or enterprise alternatives if future scale changes.

### Target Commercial Outcome
- BI annual spend: **$4,800 → $2,880** (40% reduction).

### Leverage Points
- Usage telemetry supports immediate seat reduction.
- Defined report publisher vs viewer roles reduce license need.
- Can defer non-essential BI seat growth until ROI is proven.

### BATNA
- Freeze BI expansion and reassign dormant seats monthly; route light users to exported dashboards.

---

## 6) Time-Bound Execution Plan

- **By May 24, 2026:** finalize seat-level telemetry snapshots (Zoom, DocuSign, BI)
- **By May 31, 2026:** complete internal approval on target-state exceptions
- **June 1–June 20, 2026:** run vendor negotiation rounds
- **By July 10, 2026:** legal/commercial redlines complete
- **By August 20, 2026:** contracts amended and savings run-rate locked

