# ROI Template Usage Guide (for Cost Agent + Ops Agent)

**Template source:** `/home/team/shared/roi_calculation_template.md`  
**Date:** May 20, 2026  
**Purpose:** Standardize ROI reporting across case-cost, overhead, billing-cycle, and licensing initiatives.

---

## 1) When to Use

Use the ROI template for any initiative that changes cost, revenue, or cash cycle — including pilots.

Examples:
- Cost-agent: case processing automation, early alerts, benchmarking changes
- Ops-agent: billing cycle acceleration, admin efficiency, overhead reduction
- FinOps: software consolidation, license right-sizing, vendor renegotiation

---

## 2) Minimum Inputs You Must Fill

From the template, fill these fields every time:
1. Baseline annual cost (B)
2. Expected reduction % (R)
3. Gross annual savings (B*R)
4. One-time implementation cost (I)
5. Ongoing annual incremental cost (O)
6. Net annual savings ((B*R)-O)
7. Payback period (months)
8. Net ROI (%)
9. Confidence level + top assumptions/risks

If any input is unknown, mark it as **TBD** and include date to resolve.

---

## 3) Step-by-Step Workflow

1. **Lock baseline** using latest verified data (invoice, GL, system logs).
2. **Estimate expected reduction** using pilot evidence or conservative benchmark.
3. **Calculate gross and net savings** with template formulas.
4. **Add implementation + ongoing costs** (do not mix these).
5. **Compute payback + ROI**.
6. **Assign confidence level** (High/Medium/Low).
7. **Submit to shared dashboard rollup** at month-end.

---

## 4) Quality Checks Before Publishing

- Does the baseline match finance or system of record?
- Are savings annualized consistently?
- Are one-time and recurring costs separated?
- Is there risk/assumption transparency?
- Is there double-counting with another initiative?

If any answer is “no,” do not mark as finalized.

---

## 5) Adoption Rules for Cost + Ops Teams

- Use one ROI card per initiative ID.
- Update at **30/60/90-day checkpoints**.
- “Realized savings” require evidence, not projection.
- Reforecast when assumptions move by >10%.
- Link every ROI card to one primary KPI from aligned KPI docs.

---

## 6) Example Mapping (Who owns what)

| Team | Typical Initiative | Primary KPI | Reporting Owner |
|---|---|---|---|
| Cost Agent | Cost-per-case reduction | Cost per case | Cost Agent |
| Ops Agent | Billing cycle reduction | Invoice lag days / DSO | Ops Agent |
| Ops Agent | Admin reduction | Admin-to-billable ratio | Ops Agent |
| FinOps | License consolidation | Total license spend / realized savings | FinOps Agent |

---

## 7) Submission Cadence

- Weekly: working assumptions and pilot updates
- Monthly close: finalized ROI cards
- Quarterly: realized-vs-planned variance review

First shared close with this guide: **June 30, 2026**.

